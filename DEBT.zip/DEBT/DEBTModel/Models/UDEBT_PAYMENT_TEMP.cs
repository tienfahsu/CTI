﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace DEBTModel.Models
{
    public class UDEBT_PAYMENT_TEMP
    {
        [DisplayName("流水號")]
        public int SEQNO { get; set; }

        [DisplayName("文件編號")]
        public Guid DOCGUID { get; set; }

        [DisplayName("TABLENAME")]
        public string TABLENAME { get; set; }

        [DisplayName("資料轉檔日期")]
        public DateTime? MIS_DATE { get; set; }

        [DisplayName("卡號/帳號")]
        public string ACCTNMBR { get; set; }

        [DisplayName("卡號/帳號")]
        public string CARDNMBR { get; set; }

        [DisplayName("ALS欄位")]
        public string REPORT { get; set; }

        [DisplayName("REPORTTYPE")]
        public string REPORTTYPE { get; set; }

        [DisplayName("繳款日期")]
        public DateTime? POSTDATE { get; set; }

        [DisplayName("交易日期")]
        public DateTime? TXDATE { get; set; }

        [DisplayName("交易代碼")]
        public string TXCODE { get; set; }

        public string TRANCODE { get; set; }

        [DisplayName("繳款金額")]
        public decimal TXAMT { get; set; }

        [DisplayName("本金(ALS)")]
        public decimal PRINCIPAL { get; set; }

        [DisplayName("費用(ALS)")]
        public decimal FEE { get; set; }

        [DisplayName("違約金(ALS)")]
        public decimal LATECHARGE { get; set; }

        [DisplayName("其他費用(ALS)")]
        public decimal OTHERS { get; set; }

        [DisplayName("借/貸")]
        public string CD { get; set; }

        [DisplayName("備註(異動)")]
        public string NOTE { get; set; }

        [DisplayName("異動別")]
        public string ACTIONTYPE { get; set; }

        [DisplayName("MAKER_ID")]
        public string MAKER_ID { get; set; }

        [DisplayName("MAKER_NAME")]
        public string MAKER_NAME { get; set; }

        [DisplayName("MAKE_DT")]
        public DateTime? MAKE_DT { get; set; }

        [DisplayName("CHECKER_ID")]
        public string CHECKER_ID { get; set; }

        [DisplayName("CHECKER_NAME")]
        public string CHECKER_NAME { get; set; }

        [DisplayName("CHECK_DT")]
        public DateTime? CHECK_DT { get; set; }

        [DisplayName("文件建立者Account")]
        public string CREATEDBYID { get; set; }

        [DisplayName("文件建立者姓名")]
        public string CREATEDBYNAME { get; set; }

        [DisplayName("文件建立時間")]
        public DateTime CREATEDDT { get; set; }

        [DisplayName("文件更新者Account")]
        public string LASTUPDATEDBYID { get; set; }

        [DisplayName("文件更新者姓名")]
        public string LASTUPDATEDBYNAME { get; set; }

        [DisplayName("文件更新時間")]
        public DateTime LASTUPDATEDDT { get; set; }

               
    }
}
