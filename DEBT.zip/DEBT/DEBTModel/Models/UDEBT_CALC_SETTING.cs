﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace DEBTModel.Models
{
    
    public class UDEBT_CALC_SETTING
    {
        [DisplayName("流水號")]
        public int SEQNO { get; set; }

        [DisplayName("文件編號")]
        public Guid DOCGUID { get; set; }

        [DisplayName("TABLENAME")]
        public string TABLENAME { get; set; }

        [DisplayName("卡號/帳號")]
        public string ACCTNMBR { get; set; }

        [DisplayName("卡號/帳號")]
        public string CARDNMBR { get; set; }

        [DisplayName("客戶ID(身份證號)")]
        public string CUSTID { get; set; }

        [DisplayName("客戶姓名")]
        public string CUSTNAME { get; set; }

        [DisplayName("產品別")]
        public string LOCATION { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("BUSINESS")]
        public string BUSINESS { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("WO Date")]
        public DateTime? WODATE { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("利息起算日")]
        public DateTime? N_INT_DATE { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("計算基準日")]
        public DateTime? BASE_DATE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#0.00%}")]
        [DisplayName("利率%")]
        public decimal RATE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("本金")]
        public decimal WO_P { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("已結算利息")]
        public decimal WO_I { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("已結算費用")]
        public decimal WO_FEE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("法務費")]
        public decimal LEGAL_FEE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("程序/裁判費")]
        public decimal PROC_AMNT { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("執行費")]
        public decimal EXEC_AMNT { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("手續費")]
        public decimal SERV_CHRGE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("違約金")]
        public decimal LATE_CHRGE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("費用")]
        public decimal MBRZP_FEE { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,##0}")]
        [DisplayName("費用")]
        public decimal RCVRY_FEE { get; set; }

        [DisplayName("是否為日後債金條件")]
        public string IF_RECORD { get; set; }

        [DisplayName("XXWO Account")]
        public string IF_XXWO { get; set; }

        [DisplayName("Pre-WO BP Account")]
        public string IF_PREWO { get; set; }

        [DisplayName("備註")]
        public string REMARK { get; set; }

        [DisplayName("資料來源(Application)")]
        public string SOURCE_AP { get; set; }

        [DisplayName("IF_ECMS")]
        public bool IF_ECMS { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("CLOSE_D")]
        public DateTime? CLOSE_D { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [DisplayName("SCREEN_D")]
        public DateTime? SCREEN_D { get; set; }
                
        [DisplayName("修改人員")]
        public string MAKER_ID { get; set; }

        [DisplayName("申請人員")]
        public string MAKER_NAME { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm:ss}")]
        [DisplayName("修改日期")]
        public DateTime? MAKE_DT { get; set; }

        
        [DisplayName("核准人員")]
        public string CHECKER_ID { get; set; }

        [DisplayName("核准人員")]
        public string CHECKER_NAME { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm:ss}")]
        [DisplayName("核准日期")]
        public DateTime? CHECK_DT { get; set; }

        [DisplayName("文件建立者Account")]
        public string CREATEDBYID { get; set; }

        [DisplayName("文件建立者姓名")]
        public string CREATEDBYNAME { get; set; }

        [DisplayName("文件建立時間")]
        public DateTime? CREATEDDT { get; set; }

        [DisplayName("文件更新者Account")]
        public string LASTUPDATEDBYID { get; set; }

        [DisplayName("文件更新者姓名")]
        public string LASTUPDATEDBYNAME { get; set; }

        [DisplayName("文件更新時間")]
        public DateTime? LASTUPDATEDDT { get; set; }
        
    }
}