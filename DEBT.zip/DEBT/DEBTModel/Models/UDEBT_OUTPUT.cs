﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace DEBTModel.Models
{
    public class UDEBT_OUTPUT
    {
        [DisplayName("SEQNO")]
        public int SEQNO { get; set; }

        [DisplayName("貸編/帳卡號")]
        public string ACCTNMBR { get; set; }

        [DisplayName("卡號/帳號")]
        public string CARDNMBR { get; set; }

        [DisplayName("客戶姓名")]
        public string CUST_NAME { get; set; }

        [DisplayName("交易日期")]
        public DateTime? POST_D { get; set; }

        [DisplayName("PROD")]
        public string PROD { get; set; }

        [DisplayName("本金合計")]
        public decimal CURR_P { get; set; }

        [DisplayName("請求金額")]
        public decimal CURR_P1 { get; set; }

        [DisplayName("利率")]
        public decimal APR { get; set; }

        [DisplayName("程序/裁判費")]
        public decimal EXEC_AMT { get; set; }

        [DisplayName("執行費")]
        public decimal PROC_AMT { get; set; }

        [DisplayName("利息")]
        public decimal INT { get; set; }

        [DisplayName("利息累計")]
        public decimal TTL_INT { get; set; }

        [DisplayName("扣抵本金")]
        public decimal PAID_P { get; set; }

        [DisplayName("SUBTTL_AMT")]
        public decimal SUBTTL_AMT { get; set; }

        [DisplayName("違約金")]
        public decimal FINE { get; set; }

        [DisplayName("累計違約金")]
        public decimal TTL_FINE { get; set; }

        [DisplayName("餘額")]
        public decimal SUM_AMT { get; set; }

        [DisplayName("扣抵利息")]
        public decimal PAID_I { get; set; }

        [DisplayName("扣抵不計息請求金額")]
        public decimal PAID_FEE { get; set; }

        [DisplayName("扣抵違約金")]
        public decimal PAID_FINE { get; set; }

        [DisplayName("利息起算日")]
        public DateTime? INT_DATE { get; set; }

        [DisplayName("違約金起算日")]
        public DateTime? FINE_DATE { get; set; }

        [DisplayName("ECS_BLANCE")]
        public decimal ECS_BLANCE { get; set; }

        [DisplayName("TTL_BLANCE")]
        public decimal TTL_BLANCE { get; set; }

        [DisplayName("SERIAL_NO")]
        public int SERIAL_NO { get; set; }

        [DisplayName("付款金額")]
        public decimal TXN_AMT { get; set; }

        [DisplayName("總付款金額")]
        public decimal TTL_TXN_AMT { get; set; }

        [DisplayName("不計息請求金額")]
        public decimal FEE { get; set; }

        [DisplayName("累計不計息請求金額")]
        public decimal TTL_FEE { get; set; }

        [DisplayName("法務費")]
        public decimal LEGAL_FEE { get; set; }

        [DisplayName("累計法務費")]
        public decimal TTL_LEGAL_FEE { get; set; }

        [DisplayName("扣抵法務費")]
        public decimal PAID_LEGAL_FEE { get; set; }

        [DisplayName("是否為EDRP案子, Default:('N')")]
        public string IS_EDRP { get; set; }

        [DisplayName("需要輸出的MESSAGE")]
        public string MESSAGE_TEXT { get; set; }

        [DisplayName("預設檔名")]
        public string FILENAME { get; set; }

        [DisplayName("LIQUIDATE_DATE")]
        public DateTime? LIQUIDATE_DATE { get; set; }

        [DisplayName("執行人員")]
        public string CREATORID { get; set; }

        [DisplayName("執行日期, Default:(getdate())")]
        public DateTime? CREATEDDT { get; set; }


    }
}
