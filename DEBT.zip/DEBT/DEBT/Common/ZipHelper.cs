﻿using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

//'/************************************************************************
//' *  模組名稱:EPBKS.Common.ZipHelper
//' *  功用: zip 功能
//' *  版本: 2.0.1.0
//' *  適用範圍:Zip 函數
//' *  作者:Henry Tsai
//' *  創建日期:2013/12/11
//' *  修改日期:2015/11/23
//' *************************************************************************/

public class ZipHelper
{

    /// <summary>
    /// 壓縮檔案
    /// </summary>
    /// <param name="SourceFiles">要壓縮的檔案s(完整路徑)</param>
    /// <param name="TargetFile">要產生的Zip檔案(完整路徑檔名)</param>
    /// <param name="Password">密碼</param>
    /// <param name="BackupOldFile">遇到重複檔名是否備份舊檔案</param>
    public static void ZipFiles(string[] SourceFiles, string TargetFile, string Password, bool BackupOldFile)
    {
        try
        {
            //if (SourceFiles == null || SourceFiles.Length <= 0)
            //{
            //    throw new Exception("並未傳入檔案完整路徑");
            //}

            for (int i = 0; i < SourceFiles.Length; i++)
            {
                if (File.Exists(SourceFiles[i]) == false)
                {
                    throw new Exception("要壓縮的檔案【" + SourceFiles[i] + "】不存在");
                }
            }

            if (BackupOldFile == true)
            {
                //判斷要產生的ZIP檔案是否存在
                if (File.Exists(TargetFile) == true)
                {
                    //原本的檔案存在，把他ReName
                    File.Copy(TargetFile, TargetFile + "-" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".back");
                    File.Delete(TargetFile);
                }
            }

            ZipOutputStream zs = new ZipOutputStream(File.Create(TargetFile));
            zs.SetLevel(9); //壓縮比
            if (Password != "")
            {
                zs.Password = Password;
            }

            for (int i = 0; i < SourceFiles.Length; i++)
            {
                FileStream s = File.OpenRead(SourceFiles[i]);
                byte[] buffer = new byte[s.Length];
                s.Read(buffer, 0, buffer.Length);
                ZipEntry Entry = new ZipEntry(Path.GetFileName(SourceFiles[i]));
                Entry.DateTime = DateTime.Now;
                Entry.Size = s.Length;
                s.Close();
                zs.PutNextEntry(Entry);
                zs.Write(buffer, 0, buffer.Length);
            }
            zs.Finish();
            zs.Close();
        }
        catch
        {
            throw;
        }
    }

    /// <summary>
    /// 解壓縮
    /// </summary>
    /// <param name="SourceFile">要解壓縮的Zip檔案(完整路徑檔名) </param>
    /// <param name="TargetDir">解壓縮後存放的資料夾路徑(完整路徑) </param>
    /// <param name="Password">密碼</param>
    public static void ExtractZip(string SourceFile, string TargetDir, string Password)
    {
        FastZip oZip = new FastZip();
        try
        {
            //判斷ZIP檔案是否存在
            if (File.Exists(SourceFile) == false)
            {
                throw new Exception("要解壓縮的檔案【" + SourceFile + "】不存在，無法執行");
            }
            if (!string.IsNullOrWhiteSpace(Password))
            {
                oZip.Password = Password;
            }

            oZip.ExtractZip(SourceFile, TargetDir, "");
        }
        catch
        {
            throw;
        }
    }
}
 