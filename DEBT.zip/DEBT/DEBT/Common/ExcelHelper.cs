﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.POIFS.FileSystem;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NPOI.SS.Util;

namespace DEBT.Common
{
    public static class ExcelHelper
    {
        /// <summary>
        /// 根據副檔名new一個工作簿
        /// IWorkbook workbook=ExcelHelper.CreateWorkbook(file);
        /// IWorkbook workbook=file.CreateWorkbook();
        /// </summary>
        /// <param name="file">FileStream</param>
        /// <returns>工作簿</returns>
        public static IWorkbook CreateWorkbook(this FileStream file)
        {
            IWorkbook wb = null;
            if (Path.GetExtension(file.Name) == ".xls")
            {
                //POIFSFileSystem fileSystem = new POIFSFileSystem(file);
                //wb = new HSSFWorkbook(fileSystem);
                wb = new HSSFWorkbook((Stream)file);
            }
            else if (Path.GetExtension(file.Name) == ".xlsx")
            {
                //wb = new XSSFWorkbook(file.Name);
                wb = new XSSFWorkbook((Stream)file);
            }
            return wb;
        }
        /// <summary>
        /// 使用方法:
        /// workbook.EvaluateAllFormulaCells();
        /// </summary>
        /// <param name="workbook">workbook</param>
        /// <returns>workbook</returns>
        public static IWorkbook EvaluateAllFormulaCells(this IWorkbook workbook)
        {//重新整理整個工作簿的公式
            if (workbook is XSSFWorkbook)
            {
                XSSFFormulaEvaluator.EvaluateAllFormulaCells(workbook);
            }
            else if (workbook is HSSFWorkbook)
            {
                HSSFFormulaEvaluator.EvaluateAllFormulaCells(workbook);
            }
            return workbook;
        }
        /// <summary>
        /// 新增或是取得工作表
        /// ISheet worksheet=workbook.GetOrCreateSheet("工作表的名稱");
        /// </summary>
        /// <param name="workbook">工作簿</param>
        /// <param name="sheetName">工作表的名稱</param>
        /// <returns>工作表</returns>
        public static ISheet GetOrCreateSheet(this IWorkbook workbook, string sheetName)
        {
            if (workbook.GetSheet(sheetName) == null)
            {
                workbook.CreateSheet(sheetName);
            }
            return workbook.GetSheet(sheetName);
        }
        /// <summary>
        /// 取得工作表最後一行的數字,從1開始
        /// 使用方法:
        /// int lastRow=sheet.GetLastRowNum();
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <returns>int</returns>
        public static int GetLastRowNum(this ISheet sheet)
        {
            return sheet.LastRowNum + 1;
        }
        public static dynamic GetCellValue(this ICell cell)
        {
            if (cell.CellType != CellType.Blank)
            {
                switch (cell.CellType)
                {
                    case CellType.Numeric:
                        if (DateUtil.IsCellDateFormatted(cell))
                        {
                            return cell.DateCellValue;
                        }
                        else
                        {
                            return cell.NumericCellValue;
                        }
                        //break;
                    case CellType.Boolean:
                        return cell.BooleanCellValue;
                        //break;
                    case CellType.Formula:
                        return cell.CellFormula;
                        //break;
                    case CellType.String:
                        return cell.StringCellValue;
                        //break;
                }
            }
            return null;
        }
        /// <summary>
        /// 使用方法:
        /// sheet.AddMergedRegion_1(1,1,1,1));
        /// </summary>
        /// <param name="sheet">worksheets</param>
        /// <param name="firstRow">開始合併的row,從1開始</param>
        /// <param name="lastRow">結束合併的row,從1開始</param>
        /// <param name="firstCol">開始合併的column,從1開始</param>
        /// <param name="lastCol">結束合併的column,從1開始</param>
        /// <returns>sheet</returns>
        public static ISheet AddMergedRegion_1(this ISheet sheet, int firstRow, int lastRow, int firstCol, int lastCol)
        {
            firstRow--;
            lastRow--;
            firstCol--;
            lastCol--;
            sheet.AddMergedRegion(new CellRangeAddress(firstRow, lastRow, firstCol, lastCol));
            return sheet;
        }
        /// <summary>
        /// 工作表的幾行幾列
        /// worksheet.GetOrCreateCell(0,0).SetCellValue(值);
        /// </summary>
        /// <param name="sheet">工作表</param>
        /// <param name="row">橫的,從0開始</param>
        /// <param name="cell">直的,從0開始</param>
        /// <returns>顯示工作表裡幾行(row+1)幾列(cell+1)的那一格</returns>
        public static ICell GetOrCreateCell(this ISheet sheet, int row, int cell)
        {
            if (sheet.GetRow(row) == null)
            {
                sheet.CreateRow(row);
            }
            if (sheet.GetRow(row).GetCell(cell) == null)
            {
                sheet.GetRow(row).CreateCell(cell);
            }
            return sheet.GetRow(row).GetCell(cell);
        }
        /// <summary>
        /// 工作表的幾行幾列
        /// worksheet.GetOrCreateCell_1(1,1).SetCellValue(值);
        /// </summary>
        /// <param name="sheet">工作表</param>
        /// <param name="row">橫的,從1開始</param>
        /// <param name="column">直的,從1開始</param>
        /// <returns>顯示工作表裡的幾行幾列的那一格</returns>
        public static ICell GetOrCreateCell_1(this ISheet sheet, int row, int column)
        {
            row--;//在程式裡的工作表是從0開始, 將數字減一, 讓其數字跟顯示的一樣
            column--;
            if (sheet.GetRow(row) == null)
            {
                sheet.CreateRow(row);
            }
            if (sheet.GetRow(row).GetCell(column) == null)
            {
                sheet.GetRow(row).CreateCell(column);
            }
            return sheet.GetRow(row).GetCell(column);
        }
        /// <summary>
        /// 使用方法:
        /// sheet.GetOrCreateCell(row,column).SetCellValue(value);
        /// </summary>
        /// <param name="cell">ICell</param>
        /// <param name="value">int value</param>
        /// <returns>ICell</returns>
        public static ICell SetCellValue(this ICell cell, int? value)
        {
            if (value.HasValue)
            {
                cell.SetCellValue(Convert.ToDouble(value));
            }
            return cell;
        }
        /// <summary>
        /// 使用方法:
        /// sheet.GetOrCreateCell(row,column).SetCellValue(value);
        /// </summary>
        /// <param name="cell">ICell</param>
        /// <param name="value">int value</param>
        /// <returns>ICell</returns>
        public static ICell SetCellValue(this ICell cell, int value)
        {
            cell.SetCellValue(Convert.ToDouble(value));
            return cell;
        }
        /// <summary>
        /// 使用方法: 
        /// sheet.GetOrCreateCell(row,column).SetCellValue(value);
        /// </summary>
        /// <param name="cell">ICell</param>
        /// <param name="value">decimal? value</param>
        /// <returns>ICell</returns>
        public static ICell SetCellValue(this ICell cell, decimal? value)
        {
            if (value.HasValue)
            {
                cell.SetCellValue(Convert.ToDouble(value));
            }
            return cell;
        }
        /// <summary>
        /// 使用方法:
        /// sheet.GetOrCreateCell(row,column).SetCellValue(value,"yyyy/MM/dd");
        /// </summary>
        /// <param name="cell">ICell</param>
        /// <param name="value">DateTime? value</param>
        /// <returns>ICell</returns>
        public static ICell SetCellValue(this ICell cell, DateTime? value, string format)
        {
            if (value.HasValue)
            {
                DateTime date = Convert.ToDateTime(value);
                cell.SetCellValue(Convert.ToDateTime(date.ToString(format)));
            }
            return cell;
        }
        /*
        public static ICell SetCellValue(this ICell cell, string value) {
            if (!string.IsNullOrEmpty(value)) {
                cell.SetCellValue(value);
            }
            return cell;
        }
        */
        /// <summary>
        /// 使用方法:
        /// sheet.GetOrCreateCell(row,column).SetCellValue(value).SetCellType(CellType.Numeric)
        /// </summary>
        /// <param name="cell">ICell</param>
        /// <param name="cellType">CellType</param>
        /// <returns>ICell</returns>
        public static ICell SetCellType(this ICell cell, CellType cellType)
        {
            cell.SetCellType(cellType);
            return cell;
        }
        /// <summary>
        /// 將欄位A複製到目的欄位B
        /// 使用方法:
        /// CellA.CopyCellTo(CellB);
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="targetCell"></param>
        /// <returns></returns>
        public static ICell CopyCellTo(this ICell cell, ref ICell targetCell)
        {
            if (cell.CellComment != null)
            {
                targetCell.CellComment = cell.CellComment;
            }
            if (cell.CellStyle != null)
            {
                targetCell.CellStyle = cell.CellStyle;
            }
            if (cell.Hyperlink != null)
            {
                targetCell.Hyperlink = cell.Hyperlink;
            }
            targetCell.SetCellType(cell.CellType);
            switch (cell.CellType)
            {
                case CellType.Blank:
                    targetCell.SetCellValue(cell.StringCellValue);
                    break;
                case CellType.Boolean:
                    targetCell.SetCellValue(cell.BooleanCellValue);
                    break;
                case CellType.Error:
                    targetCell.SetCellErrorValue(cell.ErrorCellValue);
                    break;
                case CellType.Formula:
                    targetCell.SetCellFormula(cell.CellFormula);
                    break;
                case CellType.Numeric:
                    targetCell.SetCellValue(cell.NumericCellValue);
                    break;
                case CellType.String:
                    targetCell.SetCellValue(cell.RichStringCellValue);
                    break;
            }
            return targetCell;
        }
        public static ICell GetOrCreateCellAndSetCellValue<T>(this ISheet sheet, int row, int column, T value)
        {
            ICell cell = sheet.GetOrCreateCell(row, column);
            cell.SetCellValue(value.ToString());
            return cell;
        }
    }
}
