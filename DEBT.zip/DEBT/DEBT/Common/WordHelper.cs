﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GTICommon.Message;
using DocumentFormat.OpenXml.Packaging;

namespace DEBT.Common
{
    public static class WordHelper
    {
        //
        // GET: /WordHelper/
        /// <summary>
        /// 使用方法:
        /// MessageStatus = ModifyWord(path,fileName,dictionary);
        /// </summary>
        /// <param name="path">路徑 不包含(檔名.docx)</param>
        /// <param name="fileName">檔名.docx</param>
        /// <param name="dictionary">Key存放舊字串,Value存放新字串</param>
        /// <returns>MessageStatus</returns>
        public static MessageStatus ModifyWord(string path,string fileName,Dictionary<string,string> dictionary) {
            MessageStatus messageStatus = new MessageStatus();
            messageStatus.Status = true;
            messageStatus.Message = string.Empty;
            WordprocessingDocument doc= WordprocessingDocument.Open(string.Format("{0}{1}",path,fileName), true);
            string temp;
            try
            {
                using (StreamReader read = new StreamReader(doc.MainDocumentPart.GetStream(FileMode.OpenOrCreate,FileAccess.Read))) { temp = read.ReadToEnd(); }
                foreach (var current in dictionary) {
                    temp = temp.Replace(current.Key, current.Value);
                }
                using (StreamWriter write = new StreamWriter(doc.MainDocumentPart.GetStream(FileMode.OpenOrCreate, FileAccess.Write))) { write.Write(temp); }
                //messageStatus.File.Add(new URLFile { title = fileName, url = path });
            }
            catch (Exception e) {
                messageStatus.Status = false;
                messageStatus.Message = e.Message;
            }
            finally
            {
                doc.Dispose();//結束前Dispose
            }
            return messageStatus;
        }
    }
}
