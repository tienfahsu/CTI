﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Common
{
    public static class StringHelper
    {
        // GET: StringHelper
        //public ActionResult Index()
        //{
        //    return View();
        //}
        public static string SubstringFromRight(this string s, int takeLength)
        {
            if (s == null) { return null; }
            if (takeLength > s.Length) { takeLength = s.Length; }
            return s.Substring(s.Length - takeLength);
        }
        public static string SubstringCutLastOne(this string s)
        {
            if (s == null) { return null; }
            return s.Substring(0, s.Length - 1);
        }
        public static bool IsZero(this string s)
        {
            for (var i = 0; i < s.Length; i++)
            {
                if (s.Substring(i, 1) != "0")
                {
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// 使用方法:
        /// "1234".StringNumberToUpperCaseChineseNumber();
        /// stringValue.StringNumberToUpperCaseChineseNumber();
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string StringNumberToUpperCaseChineseNumber(this string source)
        {
            string[] eachNum = new string[10] { "零", "壹", "貳", "參", "肆", "伍", "陸", "柒", "捌", "玖" };
            string[] unit3 = new string[4] { "", "拾", "佰", "仟" };
            string[] unit4 = new string[11] { "萬", "億", "兆", "京", "垓", "秭", "穰", "溝", "澗", "正", "載" };
            string[] unit04 = new string[10] { "億零萬", "兆零億", "京零兆", "垓零京", "秭零垓", "穰零秭", "溝零穰", "澗零溝", "正零澗", "載零正" };
            string[] unit040 = new string[11] { "零萬零", "零億零", "零兆零", "零京零", "零垓零", "零秭零", "零穰零", "零溝零", "零澗零", "零正零", "零載零" };
            string[] unit48 = new string[48] { "", "拾", "佰", "仟","萬",
                "拾", "佰", "仟","億",
                "拾", "佰", "仟","兆",
                "拾", "佰", "仟","京",
                "拾", "佰", "仟","垓",
                "拾", "佰", "仟","秭",
                "拾", "佰", "仟","穰",
                "拾", "佰", "仟","溝",
                "拾", "佰", "仟","澗",
                "拾", "佰", "仟","正",
                "拾", "佰", "仟","載",
                "拾", "佰", "仟"};
            if (string.IsNullOrEmpty(source)) { return string.Empty; }
            if (source.IsZero()) { return eachNum[0]; }
            source = source.TrimStart('0');//去開頭為0
            string temp = source;
            //bool[] unitOK = new bool[11] { false, false, false, false, false, false, false, false, false, false, false };
            //int a=int.Parse(temp.SubstringFromRight(1));
            string result = "";
            bool b;
            //bool detectZero = false;//unit4 true
            if (temp.Length > 48) { return string.Empty; }//上限48位數
            //
            //for start 單位
            for (int i = 0; i < source.Length; i++)
            {
                b = int.TryParse(temp.SubstringFromRight(1), out int num);//取最後一位將文字轉成字串
                temp = temp.SubstringCutLastOne();//去除最後一位 暫時存起來
                if (b)
                {
                    if (eachNum[num] == eachNum[0])
                    {
                        //if for單位in unit 11 then result=eachNum[num]+"for單位"+ result
                        //else result = eachNum[num] + result;
                        if (i == 0)
                        {
                            //個位數為0 要是出現0元呢 
                            result = eachNum[num] + result;
                        }
                        else if (unit4.Contains(unit48[i]))
                        {
                            result = unit48[i] + result;//這個重要單位 至少要加
                        }
                        else
                        {
                            result = eachNum[num] + result;//當為數字為0 不加單位
                        }
                    }
                    else
                    {
                        result = eachNum[num] + unit48[i] + result;//值+單位+之前保存的字串 從個位數開始往上加
                    }
                }
                else
                {
                    break;//無法轉成數字
                }
            }
            //for end
            while (result.Contains(eachNum[0] + eachNum[0]))
            {
                result = result.Replace(eachNum[0] + eachNum[0], eachNum[0]);
            }

            //最後一圈用正則轉成判斷 零萬 零億... replace 不用正則 直接REPLACE
            for (int checkUnit = 0; checkUnit < unit04.Length; checkUnit++)
            {
                result = result.Replace(unit04[checkUnit], unit04[checkUnit].Substring(0, 1));
            }
            //trim end 0
            if (result.Length!=1)
            {
                result = result.TrimEnd(eachNum[0].ToCharArray());
            }

            return result;
        }
    }
}
