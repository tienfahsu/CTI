﻿using DEBT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        /// <summary>
        /// 載入
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public ActionResult DEBT105000(DEBT105000ViewModel.Filter filter)
        {
            DEBT105000Repository _repo = new DEBT105000Repository();
            DEBT105000ViewModel model = _repo.init(filter, PersonInfo.PersonMaster.PersonKey);

            ModelState.Clear();
            TempData["AltMsg"] = null;
            if (!string.IsNullOrEmpty(model.msg.Message))
            {
                TempData["AltMsg"] = model.msg.Message;
            }

            return View(model);
        }
    }
}
