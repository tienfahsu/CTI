﻿using DEBT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using GTICommon.Message;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="pFilter"></param>
        /// <returns></returns>
        public ActionResult DEBT103000(DEBT103000ViewModel.Filter filter,string SOEID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            MessageStatus ResultMessage = new MessageStatus();
            DEBT103000ViewModel model = _repo.Query(filter, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);

            ModelState.Clear();
            if (!string.IsNullOrEmpty(model.resultMessage.Message))
            {
                TempData["AltMsg"] = model.resultMessage.Message;
            }         
            
            return View(model);
        }

        /// <summary>
        /// refresh modiried grid 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public ActionResult queryTemp(string ACCTNMBR)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            MessageStatus ResultMessage = new MessageStatus();
            DEBT103000ViewModel model = _repo.queryTemp(ACCTNMBR, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);

            return View("DEBT103001", model.lstUDEBT_PAYMENT_TEMP);
        }

        public ActionResult DEBT103003(DEBT103000ViewModel.Filter filter, string ACCTNMBR, string SOEID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            MessageStatus ResultMessage = new MessageStatus();
            DEBT103000ViewModel model = _repo.Re(filter,ACCTNMBR, PersonInfo.PersonMaster.PersonKey);

            ModelState.Clear();
            if (!string.IsNullOrEmpty(model.resultMessage.Message))
            {
                TempData["AltMsg"] = model.resultMessage.Message;
            }
    
            return View(model);
        }
        /// <summary>
        /// R0 載入畫面
        /// </summary>
        /// <param name="DOCGUID"></param>
        /// <returns></returns>
        public ActionResult DEBT1030R0(string DOCGUID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            MessageStatus ResultMessage = new MessageStatus();         
            DEBT103000ViewModel model = _repo.Query_R0(DOCGUID,PersonInfo.PersonMaster.PersonKey);

            ModelState.Clear();
            if (!string.IsNullOrEmpty(model.resultMessage.Message))
            {
                TempData["AltMsg"] = model.resultMessage.Message;
            }

            return View(model);
        }
        /// <summary>
        /// 送出
        /// </summary>
        /// <returns></returns>
        public ActionResult Submit(string ACCTNMBR, string CHECKER)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            DEBT103000ViewModel model = _repo.Submit(ACCTNMBR, CHECKER, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);

            return Json(model.resultMessage);
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <returns></returns>
        public ActionResult Exit(string ACCTNMBR)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            message = _repo.Exit(ACCTNMBR, PersonInfo.PersonMaster.PersonKey);

            return Json(message);
        }
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="Acctnmbr"></param>
        /// <param name="TXDATE"></param>
        /// <param name="TXAMT"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public ActionResult addPayment(string ACCTNMBR, string TXDATE, string TXAMT, string SOEID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            DEBT103000ViewModel model = _repo.addPayment(ACCTNMBR, TXDATE, TXAMT, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);

            return Json(model.resultMessage);
        }
        /// <summary>
        /// 刪除
        /// </summary>
        /// <param name="Acctnmbr"></param>
        /// <param name="TXDATE"></param>
        /// <param name="TXAMT"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public ActionResult delPayment(string ACCTNMBR, int SEQNO, string PName, string SOEID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            DEBT103000ViewModel model = _repo.delPayment(ACCTNMBR, SEQNO, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);
            return Json(model.resultMessage);
        }
        /// <summary>
        /// 取消異動
        /// </summary>
        /// <param name="Acctnmbr"></param>
        /// <param name="TXDATE"></param>
        /// <param name="TXAMT"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public ActionResult Cancel(string ACCTNMBR, string ACTIONTYPE, DateTime LASTUPDATEDDT,int SEQNO, string PName, string SOEID)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            DEBT103000ViewModel model = _repo.Cancel(ACCTNMBR, ACTIONTYPE, LASTUPDATEDDT,SEQNO, PersonInfo.PersonMaster.PName, PersonInfo.PersonMaster.PersonKey);

            return Json(model.resultMessage);
        }

        /// <summary>
        /// 重新整理
        /// </summary>
        /// <param name="Acctnmbr"></param>
        /// <param name="TXDATE"></param>
        /// <param name="TXAMT"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public ActionResult Re(DEBT103000ViewModel.Filter filter,string ACCTNMBR)
        {
            DEBT103000Repository _repo = new DEBT103000Repository();
            DEBT103000ViewModel model = _repo.Re(filter,ACCTNMBR, PersonInfo.PersonMaster.PersonKey);

            return Json(model.resultMessage);
        }


    }
}
