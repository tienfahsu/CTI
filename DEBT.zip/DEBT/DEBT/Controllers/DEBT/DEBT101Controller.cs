﻿using DEBT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using GTIMVC.Models;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        /// <summary>
        /// 對外債金計算
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT101000()
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel model = _repo.init();
            return View(model);
        }

        [HttpPost]
        public ActionResult DEBT101000(DEBT101000ViewModel.Filter pFilter)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel model = _repo.init(pFilter);
            if (!string.IsNullOrEmpty(model.TempMsg))
            {
                TempData["AltMsg"] = model.TempMsg;
            }
            return View(model);
        }

        #region DEBT101D01 Data 1 人工設定(第一部分)

        /// <summary>
        /// 人工設定，新增至主表
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="BASE_DATE"></param>
        /// <param name="FINE_DATE">空</param>
        /// <param name="INT_AMNT"></param>
        /// <param name="FEE_AMNT"></param>
        /// <param name="EXEC_AMNT"></param>
        /// <param name="PROC_AMNT"></param>
        /// <param name="FINE_TYPE">空</param>
        /// <param name="FINE_AMT">空</param>
        /// <param name="FINE_AMT2">空</param>
        /// <param name="FINERATE_A">空</param>
        /// <param name="FINERATE_B">空</param>
        /// <param name="FINE_RATE">空</param>
        /// <returns></returns>
        public ActionResult DEBT101A00(string HACCTNMBR, string ACCTNMBR, string BASE_DATE, string FINE_DATE,
            string INT_AMNT, string FEE_AMNT, string EXEC_AMNT, string PROC_AMNT, string FINE_TYPE,
            string FINE_AMT, string FINE_AMT2, string FINERATE_A, string FINERATE_B, string FINE_RATE)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Add(HACCTNMBR, ACCTNMBR, BASE_DATE, FINE_DATE,
            INT_AMNT, FEE_AMNT, EXEC_AMNT, PROC_AMNT, FINE_TYPE, FINE_AMT,
            FINE_AMT2, FINERATE_A, FINERATE_B, FINE_RATE, PersonInfo.PersonMaster.PersonKey);

            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 取消設定為日後債金計算條件
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D00Cancel(string SOURCE, string HACCTNMBR, string ACCTNMBR)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Cancel(SOURCE, HACCTNMBR, ACCTNMBR, PersonInfo.PersonMaster.PersonKey);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 回復備份的人工設定
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="ISFIRSTTIME"></param>
        /// <param name="ISCONTINUE"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D00Restore(string HACCTNMBR, string ACCTNMBR, bool ISFIRSTTIME, bool ISCONTINUE)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Restore(HACCTNMBR,ACCTNMBR, ISFIRSTTIME, ISCONTINUE);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 回復備份的人工設定
        /// </summary>
        /// <param name="HACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="ISFIRSTTIME"></param>
        /// <param name="ISCONTINUE"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D00Backup(string HACCTNMBR, string ACCTNMBR, bool ISFIRSTTIME, bool ISCONTINUE)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Backup(HACCTNMBR, ACCTNMBR, ISFIRSTTIME, ISCONTINUE);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 設定為日後債金計算條件
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="HACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D00Setting(string SOURCE, string HACCTNMBR, string ACCTNMBR)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            string UPDATE_P = string.Format("",ComputerIP,PersonInfo.PersonMaster.PersonKey);
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Setting(SOURCE, HACCTNMBR, ACCTNMBR, UPDATE_P);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 債金更新
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="H_ACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="BASE_DATE"></param>
        /// <param name="INT_AMNT"></param>
        /// <param name="FEE_AMNT"></param>
        /// <param name="EXEC_AMNT"></param>
        /// <param name="PROC_AMNT"></param>
        /// <param name="M_N_INT_DATE"></param>
        /// <param name="M_WO_P"></param>
        /// <param name="M_WO_I"></param>
        /// <param name="M_RATE"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D00Update(string SOURCE, string H_ACCTNMBR, string ACCTNMBR, string BASE_DATE,
            string INT_AMNT, string FEE_AMNT, string EXEC_AMNT, string PROC_AMNT, string M_N_INT_DATE,
            string M_WO_P, string M_WO_I, string M_RATE ,string REMARK
            )
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            string UPDATE_P = string.Format("{0} #{1}" ,this.ComputerIP,PersonInfo.PersonMaster.PersonKey);
            DEBT101000ViewModel.MessageControl mc = _repo.T1_Update( SOURCE,  H_ACCTNMBR,  ACCTNMBR,  BASE_DATE,
             INT_AMNT,  FEE_AMNT,  EXEC_AMNT,  PROC_AMNT,  M_N_INT_DATE,
             M_WO_P, M_WO_I, M_RATE, UPDATE_P, REMARK);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="CUTDATE"></param>
        /// <param name="CALTYPE">AP:人工,Batch:系統</param>
        /// <returns></returns>
        public ActionResult DEBT101D00Calc(string ACCTNMBR, string CUTDATE,string CALTYPE )
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            //int iCount = 0;
            MemoryStream ms = new MemoryStream();
            //string strFileName = "";
            string strTemplateFile = Server.MapPath(@"~/Files/Template/debt_detail_template.xls");
            string filepath = Server.MapPath(string.Format("{0}{1}", WebConfig.getAppSeting("ExportExcel"),"DEBT"));
            //message = _repo.T1_Calc(ACCTNMBR, CUTDATE, "AP", PersonInfo.PersonMaster.PersonKey,strTemplateFile ,out ms, out iCount, out strFileName);
            message = _repo.T1_Calc(ACCTNMBR, CUTDATE, CALTYPE, PersonInfo.PersonMaster.PersonKey, strTemplateFile, filepath);
            

            //if (message.Status)
            //{
            //    if (iCount > 0)
            //    {
            //        if ( strFileName.ToUpper().IndexOf(".XLSX") >10)
            //            strFileName = string.Format("{0}.xlsx", strFileName);
            //        MemoryStreamToFile("ExportExcel", "DEBT", strFileName, ms);

            //    }
            //    else
            //    {
            //        message.Message = "執行完成：無資料匯出!";
                    
            //    }
            //}
            if (message.Status &&  message.File != null)
            {
                message.File[0].url = Url.Content(message.File[0].url);
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region DEBT101D02 Data 2 相關 (人工設定，第二部分。For Grid)

        /// <summary>
        /// 人工設定，新增至 Grid。
        /// 現已取消違約金類型，故 js 傳回 FINE_TYPE 為空值
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="STMT_YM"></param>
        /// <param name="APR"></param>
        /// <param name="N_INT_DATE"></param>
        /// <param name="PRI_AMNT"></param>
        /// <param name="BAL_TYPE"></param>
        /// <param name="FINE_TYPE"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101A01(string ACCTNMBR, string STMT_YM, string APR, string N_INT_DATE, string PRI_AMNT, string BAL_TYPE, string FINE_TYPE)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T2_Add(ACCTNMBR, STMT_YM, APR, N_INT_DATE, PRI_AMNT, BAL_TYPE, FINE_TYPE, PersonInfo.PersonMaster.PersonKey);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 批次刪除 人工設定 Grid 資料。
        /// Grid 傳入List資料，欄位包括 SOURCE , ACCTNMBR , STMT_YM , APR , BAL_TYPE。
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101D01(List<DEBT101000ViewModel.T2_DELETE> list)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T2_Del(list, PersonInfo.PersonMaster.PersonKey);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 人工設定 - Grid 更新選取資料。
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="STMT_YM"></param>
        /// <param name="APR"></param>
        /// <param name="N_INT_DATE"></param>
        /// <param name="PRI_AMNT"></param>
        /// <param name="BAL_TYPE"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DEBT101U01(string SOURCE, string ACCTNMBR, string STMT_YM, string APR, string N_INT_DATE, string PRI_AMNT, string BAL_TYPE)
        {
            DEBT101000Repository _repo = new DEBT101000Repository();
            DEBT101000ViewModel.MessageControl mc = _repo.T2_Update(SOURCE, ACCTNMBR, STMT_YM, APR, N_INT_DATE, PRI_AMNT, BAL_TYPE, PersonInfo.PersonMaster.PersonKey);
            return Json(mc, JsonRequestBehavior.AllowGet);
        }


        #endregion
    }
}
