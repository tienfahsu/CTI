﻿using DEBT.Models;
using GTICommon.Message; 
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using GTIMVC.Models;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        //
        // GET: /DEBT106/

        public ActionResult DEBT106000()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadFile(FormCollection form)
        {

            message = new GTICommon.Message.MessageStatus();
            DEBT106000Repository imodel = new DEBT106000Repository();
            string strTemplateFile = Server.MapPath(@"~/Files/Template/debt_detail_template.xls");
            string filepath = Server.MapPath(string.Format("{0}{1}", WebConfig.getAppSeting("ExportExcel"), "DEBT"));
            #region 取得web.config 相關資料

           // int FileSize = 4;
            string fileSavedPath = WebConfigurationManager.AppSettings["UploadPath"];
            //int.TryParse(WebConfigurationManager.AppSettings["FileSize"], out FileSize);
            string path = "";
            #endregion

            if (Request.Files.Count > 0)
            {
                HttpPostedFileBase file = Request.Files[0];


                // 附檔上傳到不同Server
                if (fileSavedPath.IndexOf('~') == 0)
                {
                    path = Server.MapPath(fileSavedPath);
                }
                else
                {
                    path = fileSavedPath;
                }

                string fileName = Path.GetFileName(file.FileName);

                //   上傳
                try
                {                 
                    // 檢查副檔名
                    var extension = Path.GetExtension(fileName).ToLower();
                    if (extension != ".xls")
                    {
                        throw new Exception("此副檔名非.xls");
                    }
                    else if (extension == ".xls")
                    {
                        string fullFilePath = Path.Combine(path, "DEBT", fileName);

                        if (!Directory.Exists(Path.Combine(path, "DEBT")))
                        {
                            Directory.CreateDirectory(Path.Combine(path, "DEBT"));
                        }
                        file.SaveAs(fullFilePath);
                        List<MSFile> msOutFiles = new List<MSFile>();
                         message = imodel.batchCalc(fullFilePath, PersonInfo.PersonMaster.PEName, PersonInfo.PersonMaster.PersonKey, strTemplateFile, filepath,out msOutFiles);
                        if (msOutFiles.Count > 0)
                        {
                            message = ZipCompress_WithZipName(msOutFiles, "DEBT_BATCH");
                           
                        }
                    }
                }
                catch (Exception ee)
                {
                    //  message.Message =StepMessage+ ee.Message;
                    message.Message = ee.Message;
                    message.Status = false;
                }
                finally
                {
               
                }
            }
            else
            {

                message = new GTICommon.Message.MessageStatus { Status = false, Message = "請上傳檔案!" };


            }
            if (message.Status && message.File != null)
            {
                message.File[0].url = Url.Content(message.File[0].url);
            }
           // message.File[0].url = Url.Content(message.File[0].url);
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult base64Zip(string base64zip)
        {
            MessageStatus message = new MessageStatus();
            MemoryStream ms = new MemoryStream();
            string SOEID = PersonInfo.PersonMaster.PersonKey;
            try
            {
                var downloadDir = Server.MapPath(string.Format("{0}{1}", WebConfig.getAppSeting("ExportExcel"), "DEBT"));
                string ZipName = string.Format("DEBT_BATCH_{0}_{1}.zip", SOEID, DateTime.Now.ToString("yyyyMMddHHmmss"));
                string ExcelPath = Path.Combine(downloadDir, ZipName);

                base64zip = Regex.Unescape(base64zip as string);
                if (base64zip.IndexOf("\"") >= 0)
                    base64zip = base64zip.Replace("\"", "");


                byte[] ExcelBytes = Convert.FromBase64String(base64zip);
                System.IO.File.WriteAllBytes(ExcelPath, ExcelBytes);

                message.Status = true;
                message.Message = "執行完成";
                message.File.Add(new URLFile { title = ZipName, url = Url.Content(string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", ZipName)) });
              
            }
            catch (Exception ex)
            {
                message.Status = false;
                message.Message = ex.Message;
            }
            return Json(message);
        
        }
    }
}
