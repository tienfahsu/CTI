﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        public ActionResult DocButton()
        {
            return View();

        }

        //public JsonResult GetDocButton(string DocGuid, string Mode, string ProgramFileHead)
        //{
        //    try
        //    {
        //        ButtonRepository _btnRepo = new ButtonRepository();
        //        List<F_DocButtonView> model;
        //        model = _btnRepo.getDocButton(Mode, DocGuid, PersonInfo.PersonMaster.PersonKey, ProgramFileHead);

        //        //return View();
        //        return Json(model, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (System.Exception ex)
        //    {
        //        return Json("");
        //    }
        //}

        ///// <summary>
        ///// 透過Ajax傳回對應的Navigator Button
        ///// </summary>
        ///// <returns></returns>
        //public JsonResult GetFlowInfo(string DocGuid, string ProgramFileHead)
        //{
        //    try
        //    {
        //        F_DocSignerVW doclist = null;
        //        FlowRepository FR = new FlowRepository();

        //        doclist = FR.getFlowInfo(DocGuid, PersonInfo.PersonMaster.PersonKey, ProgramFileHead);
        //        //doclist = FR.getFlowInfo(DocGuid, "jacky", ProgramFileHead);

        //        return Json(doclist);
        //    }
        //    catch (System.Exception ex)
        //    {
        //        return Json("");
        //    }
        //}

    }
}
