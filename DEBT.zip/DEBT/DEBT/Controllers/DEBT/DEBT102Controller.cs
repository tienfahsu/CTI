﻿using DEBT.Models;
using DEBTModel.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        //public ActionResult GetDocButton()
        //{
        //    return View();

        //}




        #region 各頁面初始化
        /// <summary>
        /// 主頁 Init
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT102000()
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            TempData["AltMsg"] = null;
            return View(model);
        }

        /// <summary>
        /// 搜尋
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT10200F()
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            return View(model.filter);
            
        }

        /// <summary>
        /// GridView頁面
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT102001()
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            return View(model.lstCALC_SETTING);
        }

        /// <summary>
        /// Detail頁面
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT102002()
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            return View(model.CALC_SETTING_FLOW);
        }

        /// <summary>
        /// R0頁面
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT1020R0(string DOCGUID)
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            DEBT102000Repository repo = new DEBT102000Repository();
            string SOEID = PersonInfo.PersonMaster.PersonKey;
            model.flowData = repo.queryFlowData(DOCGUID, SOEID);

            return View(model.flowData);
        }
        #endregion

        /// <summary>
        /// 搜尋資料 to GridView
        /// </summary>
        /// <returns></returns>
        //[HttpPost]
        public ActionResult Query(DEBT102000ViewModel.Filter _filter)
        {
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            DEBT102000Repository repo = new DEBT102000Repository();
            //Frank 預設的三個參數，若後續有權限控制需求時，可以使用。(有對應SP)
            string SOEID = PersonInfo.PersonMaster.PersonKey;
            string UNAME = PersonInfo.PersonMaster.PName;
            string LEVEL = "";

            model = repo.getGridViewData(_filter, SOEID, UNAME, LEVEL);

            #region 錯誤訊息與IS_FLOW處理
            //當有錯誤訊息...
            ModelState.Clear();
            TempData["AltMsg"] = null;
            if (!string.IsNullOrEmpty(model.msg.Message))
            {
                TempData["AltMsg"] = model.msg.Message;
            }
            else
            {
                TempData["AltMsg"] = "";
            }

            //當訊息是空的，且 STATUS 為 TRUE...
            if (model.msg.Status)
            {
                if (model.filter.IS_FLOW)//借來傳遞 IS_FLOW 控制 (寫在DEBT102001.cshtml)
                {
                    TempData["IS_FLOW"] = "True";
                }
                else
                {
                    TempData["IS_FLOW"] = "False";
                }
            }
            else
            {
                return Json(model.msg,JsonRequestBehavior.AllowGet);
            }
            #endregion

            return View("DEBT102001", model.lstCALC_SETTING);
        }

        /// <summary>
        /// 設定為日後債金計算條件
        /// </summary>
        /// <returns></returns>
        //[HttpPost]
        public ActionResult setDEBT(DEBT102000ViewModel.DeptSetting data)
        { 
            DEBT102000ViewModel model = new DEBT102000ViewModel();
            DEBT102000Repository repo = new DEBT102000Repository();
            string pkey = PersonInfo.PersonMaster.PersonKey;
            string pname = PersonInfo.PersonMaster.PName;
            model = repo.setDebtCondition(data, pkey, pname);

            return Json(model.msg, JsonRequestBehavior.AllowGet);
        }
        
        /// <summary>
        /// 債金計算
        /// </summary>
        /// <returns></returns>
        //[HttpPost]
        public ActionResult calcDEBT(UDEBT_CALC_SETTING_TEMP form_data)
        {
            #region for excel
            string templatePath = Server.MapPath("~/Files/Template/");
            string exportPath = Server.MapPath("~/Files/Excel/DEBT/");
            string fileName = "debt_detail_template.xls";
            #endregion

            DEBT102000ViewModel model = new DEBT102000ViewModel();
            DEBT102000Repository repo = new DEBT102000Repository();
            #region 寫入 CREATED 相關資料
            form_data.CREATEDBYID = PersonInfo.PersonMaster.PersonKey;
            form_data.CREATEDBYNAME = PersonInfo.PersonMaster.PName;
            form_data.CREATEDDT = DateTime.Now;
            #endregion
            model = repo.debtCalculation(form_data, templatePath, exportPath, fileName);
            for (int i = 0; i < model.msg.File.Count; i++)
            {
                model.msg.File[i].url = Url.Content(model.msg.File[i].url);
            }
            return Json(model.msg, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 取得 Checker 清單
        /// </summary>
        /// <returns></returns>
        public ActionResult getCheckerList()
        {
            DEBT102000Repository repo = new DEBT102000Repository();
            List<SelectListItem> lstSLItem = new List<SelectListItem>();
            string SOEID = PersonInfo.PersonMaster.PersonKey;
            lstSLItem = repo.getCheckerList(SOEID);//(目前使用此方法會掛掉=  w=...4/27)

            //debug
            //lstSLItem.Add(new SelectListItem() { Text = "Iris Lin(IL12345)" , Value = "IL12345", Selected = true });
            //lstSLItem.Add(new SelectListItem() { Text = "Dylan Yen(DY12345)", Value = "DY12345", Selected = true });
            //lstSLItem.Add(new SelectListItem() { Text = "Frank Shu(FS12345)", Value = "FS12345", Selected = true });

            return Json(lstSLItem, JsonRequestBehavior.AllowGet);
        }

    }
}
