﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DEBT.Models;
using GTIWF.Models.DataModel;

namespace DEBT.Controllers
{
    public partial class DEBTController : BaseController
    {
        /// <summary>
        /// 頁面初始化，直接帶入GridView資料
        /// </summary>
        /// <returns></returns>
        public ActionResult DEBT104000()
        {
            DEBT104000ViewModel model = new DEBT104000ViewModel();
            DEBT104000Repository repo = new DEBT104000Repository();
            model.filter.SignerID = PersonInfo.PersonMaster.PersonKey;
            model = repo.Init(model.filter.SignerID);

            ModelState.Clear();
            if (!string.IsNullOrEmpty(model.msg.Message))
            {
                TempData["AltMsg"] = model.msg.Message;
            }    

            return View(model);
        }


        /// <summary>
        /// 檢視明細
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Detial(F_SIGNBOX_DEBT data)
        {
            DEBT104000ViewModel model = new DEBT104000ViewModel();
            DEBT104000Repository repo = new DEBT104000Repository();

            
            return View("DEBT1020R0", model);
        }
    }
}
