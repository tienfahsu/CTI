﻿using GTIMVC.Models.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Controllers
{
    public class HomeController : Controller
    {
        public IFormsAuthenticationService FormsService { get; set; }
        public ActionResult Index()
        {
            try
            {
                if (FormsService == null) { FormsService = new FormsAuthenticationService(); }
                string userId;
                userId = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_SM_USER"];


                //userId = "GO96021";
                #if DEBUG
                Session["User"] = "AC95575";
                userId = Session["User"].ToString();
                
                #else
                if (string.IsNullOrWhiteSpace(Request.QueryString["ticket"]))
                {
                    return Content(string.Format("<html><script>window.top.location.href='{0}';</script></html>", "/UPortal/Account/UtilityInvalid"));
                }   
                #endif
                if (userId != null && userId != "")
                {
                    Session["User"] = userId;
                    
                    FormsService.SignIn(userId, true);
                    //Response.Write("LOGINOK" + Convert.ToBase64String(Encoding.Default.GetBytes(userId)));
                }
                else
                {
                    userId = "";
                    
                    throw (new Exception("fail: It can't get User login ID"));
                    
                    //Response.Write("LOGINFAILED");
                }
            }
            catch (Exception ex)
            {
                Console.Error.Write("ERROR " + ex.Message);
                //GTIMVC.Models.Log.LogRepository.wrActivityLog("COG", PersonInfo.PersonMaster.PersonKey, HttpContext.Request.UserHostAddress, @"Home\index", "Login", ex.Message);
            }
            //return RedirectToAction("Index", "Home");
            return View();
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
