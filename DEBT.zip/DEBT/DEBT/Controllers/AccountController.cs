﻿using GTIMVC.Models.Account;
using GTIMVC.Models.Authentication;
using GTIMVC.Models.Person;
using Microsoft.Web.WebPages.OAuth;
using System;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace DEBT.Controllers
{
    public class AccountController : Controller
    {

        public IFormsAuthenticationService FormsService { get; set; }
        // public IMembershipService MembershipService { get; set; }

        private PersonModel _PersonInfo;

        public ActionResult InvalidID()
        {
            return View();
        }
        public ActionResult InactiveID()
        {
            return View();
        }
        protected override void Initialize(RequestContext requestContext)
        {
            if (FormsService == null) { FormsService = new FormsAuthenticationService(); }
            // if (MembershipService == null) { MembershipService = new AccountMembershipService(); }

            base.Initialize(requestContext);
        }

        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Account/Login


        [HttpGet]
        public ActionResult Login(string SOEID)
        {
            //Session["User"] = SOEID;
            //return Redirect(Url.Content("~/"));
            try
            {
                string userId = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_SM_USER"];
                if (string.IsNullOrWhiteSpace(userId)) userId = SOEID;

                if (userId != null && userId != "")
                {
                    Session["User"] = userId;
                    Response.Write("LOGINOK" + Convert.ToBase64String(Encoding.Default.GetBytes(userId)));
                }
                else
                {
                    userId = "";
                    Response.Write("LOGINFAILED");
                }
            }
            catch (Exception ex)
            {
                Response.Write("ERROR " + ex.Message);
            }
            return RedirectToAction("Index", "Home");
        }
        //
        // Post: /Account/Login

        [HttpPost]
        //public ActionResult Login(string username, string userpass, string returnUrl)
        public ActionResult Login(AccountModel model, string returnUrl)
        {
            ViewData["Tip"] = "";
            LDAPAuthentication LdapAuth = new LDAPAuthentication(GTIUtility.Utility.getAppSeting("ADService"));
            //string[] identity = model.username.Split(new char[1] { '\\' });
            string Domain = model.domain;
            string UserName = model.username;
            string DomainName = GTIUtility.Utility.getAppSeting("DomainName");
            AccountDDL ddl = new AccountDDL();
            ViewData["ddlDomain"] = new SelectList(ddl.genDomainList(DomainName), "Value", "Text", model.domain);

            if (UserAuthentication.VerifyUser(UserName) &&
                LdapAuth.IsAuthenticated(Domain, UserName, model.userpass)
                )
            {

                // username = @"CECDM\CEC1179";//username;
                FormsService.SignIn(model.username, true);
                //创建身份验证票证，即转换为“已登录状态”
                // FormsAuthentication.SetAuthCookie(username, true);

                //存入Session
                Session["User"] = model.username;


                //如果是跳转过来的，则返回上一页面ReturnUrl                

            }
            returnUrl = Url.Content("~/");
            return Redirect(returnUrl);
        }



        //
        // GET: /Account/Logout

        [HttpGet]
        public ActionResult Logout()
        {
            //取消Session会话
            Session.Abandon();

            //删除Forms验证票证
            FormsAuthentication.SignOut();

            return RedirectToAction("Login", "Account");
        }

        #region Helper
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
        }

        internal class ExternalLoginResult : ActionResult
        {
            public ExternalLoginResult(string provider, string returnUrl)
            {
                Provider = provider;
                ReturnUrl = returnUrl;
            }

            public string Provider { get; private set; }
            public string ReturnUrl { get; private set; }

            public override void ExecuteResult(ControllerContext context)
            {
                OAuthWebSecurity.RequestAuthentication(Provider, ReturnUrl);
            }
        }

        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // 請參閱 http://go.microsoft.com/fwlink/?LinkID=177550 了解
            // 狀態碼的完整清單。
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "使用者名稱已經存在。請輸入不同的使用者名稱。";

                case MembershipCreateStatus.DuplicateEmail:
                    return "該電子郵件地址的使用者名稱已經存在。請輸入不同的電子郵件地址。";

                case MembershipCreateStatus.InvalidPassword:
                    return "所提供的密碼無效。請輸入有效的密碼值。";

                case MembershipCreateStatus.InvalidEmail:
                    return "所提供的電子郵件地址無效。請檢查這項值，然後再試一次。";

                case MembershipCreateStatus.InvalidAnswer:
                    return "所提供的密碼擷取解答無效。請檢查這項值，然後再試一次。";

                case MembershipCreateStatus.InvalidQuestion:
                    return "所提供的密碼擷取問題無效。請檢查這項值，然後再試一次。";

                case MembershipCreateStatus.InvalidUserName:
                    return "所提供的使用者名稱無效。請檢查這項值，然後再試一次。";

                case MembershipCreateStatus.ProviderError:
                    return "驗證提供者傳回錯誤。請確認您的輸入，然後再試一次。如果問題仍然存在，請聯繫您的系統管理員。";

                case MembershipCreateStatus.UserRejected:
                    return "使用者建立要求已取消。請確認您的輸入，然後再試一次。如果問題仍然存在，請聯繫您的系統管理員。";

                default:
                    return "發生未知的錯誤。請確認您的輸入，然後再試一次。如果問題仍然存在，請聯繫您的系統管理員。";
            }
        }
        #endregion
    }
}
