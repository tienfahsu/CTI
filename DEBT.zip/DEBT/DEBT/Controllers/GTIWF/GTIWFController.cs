﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GTIWF.Models;
using GTIWF.Models.SignBox;

using DEBT.Models;
using DEBTModel.Models;
using System.Reflection;
using GTIWF.Models.Flow;
using GTIWF.Models.DataModel;
using GTIWF.Models.Button;
using GTICommon.Message;


namespace DEBT.Controllers
{
    public partial class GTIWFController : BaseController
    {
        public ActionResult GetDocButton()
        {
            return View();

        }
        [HttpPost]
        public JsonResult GetDocButton(string DocGuid, string Mode, string ProgramFileHead)
        {
            try
            {
                ButtonRepository _btnRepo = new ButtonRepository();
                List<F_DocButtonView> model;
                model = _btnRepo.getDocButton(Mode, DocGuid, PersonInfo.PersonMaster.PersonKey, ProgramFileHead);

                //return View();
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch// (System.Exception ex)
            {               
                return Json("");
            }
        }

        /// <summary>
        /// 透過Ajax傳回對應的Navigator Button
        /// </summary>
        /// <returns></returns>
        public JsonResult GetFlowInfo(string DocGuid, string ProgramFileHead)
        {
            try
            {
                F_DocSignerVW doclist = null;
                FlowRepository FR = new FlowRepository();

                doclist = FR.getFlowInfo(DocGuid, PersonInfo.PersonMaster.PersonKey, ProgramFileHead);
                //doclist = FR.getFlowInfo(DocGuid, "jacky", ProgramFileHead);

                return Json(doclist);
            }
            catch (System.Exception ex)
            {
                return Json(string.Format("Error:{0}", ex.Message));
            }
        }


        #region EventLog

        public ActionResult EventLog(string DocGuid, string ProgramFileHead)
        {
            try
            {
                Guid gDocGuid = new Guid(DocGuid);
                FlowRepository FR = new FlowRepository();
                List<DocFlowInfo> docWorkFlowVW = FR.getDocFlowInfo(DocGuid);

                //if (!string.IsNullOrWhiteSpace(Org))
                //    ViewBag.OrgCodeCSS = Org;

                ViewData["WorkFlowCStation"] = "";
                ViewData["DocOwnerCName"] = "";
                if (docWorkFlowVW != null && docWorkFlowVW.Count > 0)
                {
                    foreach (var docFlowInfo in docWorkFlowVW)
                    {
                        ViewData["WorkFlowCStation"] = docFlowInfo.CStation;
                        ViewData["DocOwnerCName"] = ViewData["DocOwnerCName"].ToString() + "," + docFlowInfo.OwnerName;
                    }
                    ViewData["DocOwnerCName"] = ViewData["DocOwnerCName"].ToString().Substring(1);
                }
                else
                {
                    ViewData["WorkFlowCStation"] = "新文件";
                    ViewData["DocOwnerCName"] = "";
                }

                if (string.IsNullOrWhiteSpace(DocGuid))
                {
                    throw new Exception("無法讀取 DocGuid");
                }

                //if (string.IsNullOrWhiteSpace(ProgramFileHead))
                //{
                //    throw new Exception("無法讀取 ProgramFileHead");
                //}

                GTIWF.Models.EventLog.EventLogRepository iEventLog = new GTIWF.Models.EventLog.EventLogRepository();
                List<GTIWF.Models.DataModel.FLOW_EventLogTB> docs = iEventLog.getEventLog(DocGuid);

                //History history = new History("MyHRConnectionString");
                //IEnumerable<GWF.Models.EventLogTB> docs = history.GetEventLog(DocGuid).OrderBy(x => x.CreatedDT);



                return View(docs);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region SignBox
        public ActionResult SignBox(string DocGuid, string SignAction, string ProcessID, string FlowID)
        {
            //ControlCenterDataContext context = new ControlCenterDataContext();
            string dtNow = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
            SignAction = Server.UrlDecode(SignAction);
            ProcessID = Server.UrlDecode(ProcessID);
            FlowID = Server.UrlDecode(FlowID);
            DocGuid = Server.UrlDecode(DocGuid);
            ViewData["Comment"] = "";
            ViewData["DocGuid"] = DocGuid;
            ViewData["SignAction"] = SignAction;
            ViewData["ProcessID"] = ProcessID;
            ViewData["FlowID"] = FlowID;
            return View();
        }

        [HttpPost]

        public ActionResult SignBox(string SignAction, FormCollection form)
        {
            try
            {
                SignAction = Server.UrlDecode(SignAction);
                ViewData["DocGuid"] = form["DocGuid"];
                ViewData["Name"] = PersonInfo.PersonMaster.PName;
                ViewData["SignAction"] = SignAction;
                ViewData["Date"] = DateTime.Now.ToString("yyyy/MM/dd hh:mm");
              //  string strRetuenMsg = "";


                #region 流程

                FlowRepository FR = new FlowRepository();
                FR.FlowData.ProcessID = form["F_ProcessID"].ToString();
                FR.FlowData.FlowID = form["F_FlowID"].ToString();
                FR.FlowData.SignerID = PersonInfo.PersonMaster.PersonKey;
                FR.FlowData.DocGuid = new Guid(form["F_DocGuid"].ToString());
                FR.FlowData.Action = SignAction;
                FR.FlowData.Variant = form["F_Variant"].ToString();
                FR.FlowData.DocFC = form;
                FR.FlowData.Comment = form["F_Comment"].ToString();
                if (FR.SetEditDoc())
                    return Json(new MessageStatus { Message = FR.Msg, Status = true });
                //return Json(ModelState.SetSuccessDataJavascript(FR.Msg, "closeWin();"));
                else
                    return Json(new MessageStatus { Message = FR.ErrorMsg, Status = true });
                //return Json(ModelState.GetErrorMessage(FR.ErrorMsg));

                #endregion

              //  return Json(new MessageStatus { Message = "文件已送出\r\n" + strRetuenMsg, Status = true });
                //return Json(ModelState.SetSuccessDataJavascript("文件已送出\r\n" + strRetuenMsg, "closeWin();"));
            }
            catch (Exception ee)
            {
                return Json(new MessageStatus { Message = ee.Message, Status = false });
            }
        }
        #endregion

        #region AssignSignBox - EmailSurvey 分派
        public ActionResult AssignSignBox(string DocGuid, string SignAction, string ProcessID, string FlowID)
        {
            string dtNow = DateTime.Now.ToString("yyyy/MM/dd hh:mm");
            SignAction = Server.UrlDecode(SignAction);
            ProcessID = Server.UrlDecode(ProcessID);
            FlowID = Server.UrlDecode(FlowID);
            DocGuid = Server.UrlDecode(DocGuid);
            var doc = ProcessID;// (from m in context.F_DocStationVW where m.DocGuid == new Guid(DocGuid) select m).FirstOrDefault();
            if (doc != null)
            {
                ViewData["DocGuid"] = DocGuid;
                ViewData["ProcessID"] = ProcessID;
                ViewData["FlowID"] = FlowID;
                ViewData["SignAction"] = SignAction;

                return View("AssignSignBox");
            }
            else
            {
                return Content("<script>alert('查無 Doc Station 文件');window.close()</script>");
            }
        }
        #endregion

        [HttpPost]
        public ActionResult DocSend(FormCollection form)
        {

            #region 流程
            string strRetuenMsg = "";
            FlowRepository FR = new FlowRepository();
            FR.FlowData.ProcessID = form["F_ProcessID"].ToString();
            FR.FlowData.FlowID = form["F_FlowID"].ToString();
            FR.FlowData.SignerID = PersonInfo.PersonMaster.PersonKey;
            FR.FlowData.DocGuid = new Guid(form["F_DocGuid"].ToString());
            FR.FlowData.DocFC = form;
            FR.FlowData.Variant = form["F_Variant"].ToString();


            bool blExec = false;
            F_ProcessVW P = FR.getProcess();
            try
            {
                if (P != null && !string.IsNullOrWhiteSpace(P.BeforeFlowFunc))
                {
                    if (!Execute(P.BeforeFlowFunc, ref blExec, ref strRetuenMsg, form["F_DocGuid"].ToString(), false, "", PersonInfo.PersonMaster.PersonKey))
                        //throw (new Exception("流程執行前發生錯誤：\r\n" + strRetuenMsg));
                        throw (new Exception(strRetuenMsg));
                    if (!blExec)
                    {
                        //throw (new Exception("流程執行前檢查：\r\n" + strRetuenMsg));
                        throw (new Exception(strRetuenMsg));
                    }
                }

                if (FR.SetEditDoc())
                {
                    if (P != null && !string.IsNullOrWhiteSpace(P.AfterFlowFunc))
                    {
                        if (!Execute(P.AfterFlowFunc, ref blExec, ref strRetuenMsg, form["F_DocGuid"].ToString(), false, "", PersonInfo.PersonMaster.PersonKey))
                            //throw (new Exception("流程執行後發生錯誤：\r\n" + strRetuenMsg));
                            throw (new Exception(strRetuenMsg));
                    }
                    if (string.IsNullOrWhiteSpace(strRetuenMsg))
                    {
                        //TempData["FLOWRESULT"] = new MessageStatus { Message = strRetuenMsg + "\r\n" + FR.Msg, Status = false };
                        //return Json(ModelState.SetSuccessDataJavascript(FR.Msg, "closeWin();"));
                        return Json(new MessageStatus { Message = FR.Msg, Status = true });
                    }
                    else
                    {
                        //TempData["FLOWRESULT"] = new MessageStatus { Message = strRetuenMsg + "\r\n" + FR.Msg, Status = false };
                        return Json(new MessageStatus { Message = strRetuenMsg + "\r\n" + FR.Msg, Status = false });
                    }
                    //return Json(ModelState.SetSuccessDataJavascript(strRetuenMsg + "\r\n" + FR.Msg, "closeWin();"));
                }
                else
                {
                    //return Json(ModelState.GetErrorMessage(FR.ErrorMsg));
                    //TempData["FLOWRESULT"] = new MessageStatus { Message = FR.Msg, Status = false };
                    return Json(new MessageStatus { Message = FR.ErrorMsg, Status = false });

                }
            }
            catch (Exception ee)
            {
               // TempData["FLOWRESULT"] = new MessageStatus { Message = ee.Message, Status = false };
                return Json(new MessageStatus { Message = ee.Message, Status = false });
            }
            #endregion
        }


        /// <summary>
        /// 回傳Function是否執行成功
        /// </summary>
        /// <param name="FuncName"></param>
        /// <param name="blExec">邏輯、判斷的結果</param>
        /// <param name="strReturnMsg">回傳字串(Function失敗、邏輯、判斷結果要輸出的字串</param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static bool Execute(string FuncName, ref bool blExec, ref string strReturnMsg, params object[] args)
        {
            Type type = typeof(GTIWFController);
            object reflectobj = Activator.CreateInstance(type);

            MethodInfo methodInfo = type.GetMethod(FuncName);
            bool blRet = true;
            object objReturn = methodInfo.Invoke(reflectobj, args);
            if (objReturn != null)
            { //&& bool.TryParse(objReturn.ToString(), out blRet))
                switch (objReturn.GetType().Name.ToLower())
                {
                    case "string":
                    case "boolean":
                        bool.TryParse(objReturn.ToString(), out blRet);
                        break;
                    case "null":
                        blRet = false;
                        break;
                    default:
                        break;
                }
            }
            // if (!blRet)
            blExec = Convert.ToBoolean(args[1]);
            strReturnMsg = args[2].ToString();
            return blRet;
        }

        #region Calc Setting
        /// <summary>
        /// Reassign Checker
        /// </summary>
        /// <param name="strDocGuid"></param>
        /// <param name="blExec"></param>
        /// <param name="strReturnMsg"></param>
        /// <param name="PersonKey"></param>
        /// <returns></returns>
        public bool F_UDEBT_REASSIGN_CHECKER(string strDocGuid, ref bool blExec, ref string strReturnMsg, string PersonKey)
        {
            MessageStatus execResult;
            DEBT.Models.DEBT102000Repository _repo = new DEBT102000Repository();
            try
            {
                execResult = _repo.F_UDEBT_REASSIGN_CHECKER(strDocGuid);

            }
            catch (Exception ee)
            {
                execResult = new MessageStatus
                {
                    Message = ee.Message,
                    Status = false
                };
            }

            strReturnMsg = execResult.Message;
            blExec = execResult.Status;
            return execResult.Status;
        }

        public bool F_UDEBT_APPROVE(string strDocGuid, ref bool blExec, ref string strReturnMsg, string PersonKey)
        {
            MessageStatus execResult;
            DEBT.Models.DEBT102000Repository _repo = new DEBT102000Repository();
            try
            {
                execResult = _repo.F_UDEBT_APPROVE(strDocGuid);

            }
            catch (Exception ee)
            {
                execResult = new MessageStatus
                {
                    Message = ee.Message,
                    Status = false
                };
            }

            strReturnMsg = execResult.Message;
            blExec = execResult.Status;
            return execResult.Status;
        }
        #endregion


    }
}
