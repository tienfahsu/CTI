﻿
using DEBT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Controllers
{
    public class MessageController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetMessages()
        {
            MessageRepository _messageRepository = new MessageRepository();
            return Json(_messageRepository.GetAllMessages(),JsonRequestBehavior.AllowGet);
        }
    }
}
