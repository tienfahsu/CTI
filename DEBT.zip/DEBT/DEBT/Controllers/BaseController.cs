﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using GTIMVC.Models.Person;
using System.ComponentModel;
using System.Reflection;
using GTIMVC.Models.Authentication;
using GTICommon.API;
using GTICommon.Message;

namespace DEBT.Controllers
{
    public class BaseController : Controller
    {
        //public static ZIP ZIPcom = new ZIP();

        public PersonModel PersonInfo { get { getPersonInfo(); return _PersonInfo; } private set { _PersonInfo = value; } }

        public MessageStatus message { get; set; }

        public bool IsAuthorize { get; private set; }

        private PersonModel _PersonInfo;

        private string LoginSOEID = "";

        private MessageStatus _msg;

        private UtilityInfo _utilityInfo;

        protected string ActionName { get; set; }
        protected string ControllerName { get; set; }
        protected string ComputerIP { get; set; }

        protected string ComputerName { get; set; }

        public BaseController()
        {

        }

        public bool getPersonInfo()
        {
            bool blRet = false;

            if (HttpContext != null)
            {
                _PersonInfo = (PersonModel)Session["PersonInfo"];
                if (_PersonInfo != null)
                    blRet = true;
            }
            return blRet;
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            GTIMVC.Models.Log.LogRepository iLog;
            iLog = new GTIMVC.Models.Log.LogRepository();
            string userId = string.IsNullOrWhiteSpace(System.Web.HttpContext.Current.Request.ServerVariables["HTTP_SM_USER"]) ? null : System.Web.HttpContext.Current.Request.ServerVariables["HTTP_SM_USER"].ToUpper();

            _msg = new MessageStatus();
           
            ActionName = filterContext.RouteData.Values["action"].ToString();
            ControllerName = filterContext.RouteData.Values["controller"].ToString();
            string strTicket = string.IsNullOrWhiteSpace(filterContext.HttpContext.Request.QueryString["ticket"]) ? "" : filterContext.HttpContext.Request.QueryString["ticket"].ToString();
            string strUtility = string.IsNullOrWhiteSpace(filterContext.HttpContext.Request.QueryString["Utility"]) ? "" : filterContext.HttpContext.Request.QueryString["Utility"].ToString();

            ComputerIP = filterContext.HttpContext.Request.UserHostAddress;
            ComputerName = filterContext.HttpContext.Request.UserHostName;

            //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, filterContext.RequestContext.HttpContext.Request.UserHostAddress, @"BaseController\OnActionExecuting", "HTTP_SM_USER : " + userId, "get");

            //userId = "Iris";

            if (Session["UtilityInfo"] == null
                || ((UtilityInfo)Session["UtilityInfo"]).Ticket.ToString().Equals("00000000-0000-0000-0000-000000000000")
                || (!string.IsNullOrWhiteSpace(strTicket) && !((UtilityInfo)Session["UtilityInfo"]).Ticket.ToString().Equals(strTicket))
                )
            {
                _utilityInfo = new UtilityInfo();

                _utilityInfo.Ticket = string.IsNullOrWhiteSpace(strTicket) ? new Guid() : new Guid(strTicket);
                _utilityInfo.Utility = string.IsNullOrWhiteSpace(strUtility) ? "" : strUtility;
                Session["UtilityInfo"] = _utilityInfo;
            }
            else
            {
                _utilityInfo = (UtilityInfo)Session["UtilityInfo"];
                strTicket = _utilityInfo.Ticket.ToString();
                strUtility = _utilityInfo.Utility;
            }


            if (!string.IsNullOrWhiteSpace(userId))
                Session["User"] = userId;


            if (Session["User"] != null)
                LoginSOEID = !string.IsNullOrWhiteSpace(Session["User"].ToString()) ? Session["User"].ToString() : "";//jl30419
            else
                LoginSOEID = "";//GO96021 jl30419 //hs56991 VF00671

            //LoginSOEID = "JC29893";
            //Session["User"] = LoginSOEID;
            //userId = LoginSOEID; 
#if DEBUG
            LoginSOEID = "JL20060";
            Session["User"] = LoginSOEID;
            userId = LoginSOEID;
#endif

            //if (userid == "")
            //{
            //    //FormsAuthentication.SignOut();
            //    //filterContext.Result = new RedirectResult("~/Account/Login");
            //    return;
            //}
            //else
            //{
            var user = filterContext.Controller.ControllerContext.RequestContext.HttpContext.User;
            // do whatever you need to do
            // Debug change Login User
            //
            PersonRepository imodel = new PersonRepository();

            //string a = filterContext.HttpContext.Request.Url.LocalPath.ToUpper();
            //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\OnActionExecuting", @"CheckUtility", "Start");
#if !DEBUG
            if (Session["strTicket"] == null || (bool)Session["strTicket"] == false)
            {
                string errMsg = "";
                Session["PersonInfo"] = null;
                Session["User"] = null;
                if (((!filterContext.HttpContext.Request.Url.LocalPath.ToUpper().Equals("/COGPORTAL/") && (filterContext.HttpContext.Request.Url.LocalPath.ToUpper().StartsWith("/UPORTAL/") && !ControllerName.ToUpper().Equals("UA")))
                          && (!string.IsNullOrWhiteSpace(strTicket) && !UserAuthentication.CheckTicket(strTicket, strUtility, LoginSOEID, ComputerIP, out errMsg)))) //ComputerIP
                {
                    //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\CheckUtility", "Utility Error : " + errMsg, "Exeute");
                    Session["UtilityError"] = errMsg;
                    
                    filterContext.Result = Content(string.Format("<html><script>window.top.location.href='{0}';</script></html>", "/UPortal/Account/UtilityInvalid"));
                    HttpContext.Items["UtilityInfo"] = null;
                    return;
                }
                else if ((!filterContext.HttpContext.Request.Url.LocalPath.ToUpper().Equals("/COGPORTAL")) && (!filterContext.HttpContext.Request.Url.LocalPath.ToUpper().StartsWith("/UPORTAL/") && ControllerName.ToUpper().Equals("HOME") && ActionName.ToUpper().Equals("INDEX")))
                {
                    filterContext.Result = Content(string.Format("<html><script>alert('Please re-execute utility from COGPortal.');window.top.location.href='{0}';</script></html>", "/COGPortal/"));
                    return;
                }
                Session["strTicket"] = true;
                iLog.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\OnActionExecuting", @"CheckUtility", "Pass");
            }
            else
            {
                //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\OnActionExecuting", @"CheckUtility", "ticket had passed");
            }
#endif

            if (Session["PersonInfo"] == null)
            {
                if (imodel.getPersonModelsByPersonKey(LoginSOEID)) //if (imodel.getPersonModelsByWinID(LoginSOEID) || imodel.getPersonModelsByPersonKey(LoginSOEID))
                {
                    Session["PersonInfo"] = imodel.PersonRelateModels;
                    //HttpContext.Items["User"] = imodel.PersonRelateModels.PersonMaster.PersonKey;
                    Session["User"] = imodel.PersonRelateModels.PersonMaster.PersonKey;

                    IsAuthorize = true;
                }
                else
                {
                    Session["PersonInfo"] = null;
                    Session["User"] = null;
                    IsAuthorize = false;
                }
            }

            if (PersonInfo != null && PersonInfo.PersonMaster != null)
            {
                string strOrgCode = "";

                strOrgCode = PersonInfo.PersonMaster.OrgCode;

                ViewBag.OrgCodeCSS = strOrgCode;
                //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\OnActionExecuting", @"PersonInfo", "Duty = " + PersonInfo.PersonMaster.IsDuty);
                //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, ComputerIP, @"BaseController\OnActionExecuting", @"PersonInfo", "Duty = " + imodel.PersonRelateModels.PersonMaster.IsDuty);
                if (PersonInfo.PersonMaster.IsDuty.Equals("N"))
                {
                    //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, filterContext.RequestContext.HttpContext.Request.UserHostAddress, @"BaseController\NoDuty", "Exeute : " + userId, "Exeute");
                    
                    filterContext.Result = Content(string.Format("<html><script>window.top.location.href='{0}';</script></html>", Url.Content("~/Account/InvalidID")));
                }
            }
            else
            {
                //GTIMVC.Models.Log.LogRepository.wrProgramLog(strUtility, userId, filterContext.RequestContext.HttpContext.Request.UserHostAddress, @"BaseController\OnActionExecuting", "Signout : " + userId, "Signout");
                FormsAuthentication.SignOut();
                //filterContext.Result = new RedirectResult("~/Account/InvalidID");

                filterContext.Result = Content(string.Format("<html><script>window.top.location.href='{0}';</script></html>", Url.Content("~/Account/InvalidID")));
                return;
            }
            //}
        }


        public void Flush(ActionResult result)
        {

            //Response.Write(string.Format("<script>alert(\"{0}\");</script>", ViewData["ErrorMessage"]));
            result.ExecuteResult(ControllerContext);
            //Response.Flush();
            //Response.End();
        }

        #region 依照所傳入的 filter，針對文字類型進行解碼

        /// <summary>
        /// 依照所傳入的 class，依序針對所有class中之文字屬性做解碼
        /// </summary>
        /// <typeparam name="T">Class Name</typeparam>
        /// <param name="pObj">回傳物件</param>
        public void genDecodeString<T>(ref T pObj)
        {
            #region 建立 DataTable 的 Columns
            PropertyDescriptorCollection properties = FindProperties<T>();
            Type type = pObj.GetType();
            if (properties.Count > 0)
            {
                for (int i = 0; i < properties.Count; i++)
                {
                    PropertyInfo pInfo = type.GetProperty(properties[i].Name);
                    if (pInfo.PropertyType.Name == "String")
                    {
                        string myValue = pInfo.GetValue(pObj, null) == null ? "" : pInfo.GetValue(pObj, null).ToString();
                        string strDecode = Server.UrlDecode(myValue);
                        pInfo.SetValue(pObj, strDecode, null);
                    }
                }
            }
            #endregion
        }

        private static PropertyDescriptorCollection FindProperties<T>()
        {
            return TypeDescriptor.GetProperties(typeof(T));
        }
        #endregion

        protected MessageStatus ZipCompress_WithZipName(List<MSFile> aryMS, string fileZipName, string PWD = "Qwertyuiop[]\\01234")
        {
            MessageStatus msg= ZipApi.Compress_WithZipName(aryMS, fileZipName, PersonInfo.PersonMaster.PersonKey, PWD, "ExportExcel");
            if (msg.Status && String.IsNullOrEmpty(msg.Message))
                msg.Message = "執行完成";
            return msg;
        }

    }

    public class UtilityInfo
    {
        public Guid Ticket { get; set; }
        public string Utility { get; set; }
    }
}
