﻿using GTIMVC.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Controllers
{

    public class FileController : BaseController
    {
        public ActionResult Download(string folder, string filename)
        {
            string ExportURLPath = folder.IndexOf("~") > -1 ? folder : string.Format("{0}/{1}", WebConfig.getAppSeting("ExportExcel"), folder);
            string path = Server.MapPath(ExportURLPath);

            if (!string.IsNullOrEmpty(path) && System.IO.File.Exists(Path.Combine(path, filename)))
                return File(System.IO.File.ReadAllBytes(Path.Combine(path, filename)),
                 "application/unknown",
                 HttpUtility.UrlEncode(System.IO.Path.GetFileName(Path.Combine(path, filename))));
            else
                return View();
        }


    }
}
