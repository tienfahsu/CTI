﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using GTIWF.Models.DataModel;
using GTICommon.Message;

namespace DEBT.Models
{
    public class DEBT104000ViewModel
    {
        public Filter filter { get; set; }
        public MessageStatus msg { get; set; }
        public List<GridViewClass> lstUDEBT_SIGNBOX { get; set; }

        public class Filter {
            public string SignerID { get; set; }
        }

        public class GridViewClass : F_SIGNBOX_DEBT
        {
            [DisplayName("序號")]//ps.不是Table中的序號
            public int SEQNO { get; set; }
        }

        public DEBT104000ViewModel() {
            filter = new Filter();
            msg = new MessageStatus();
            lstUDEBT_SIGNBOX = new List<GridViewClass>();
        }
    }
}