﻿using GTIMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;
using System.Web.Mvc;
using GTICommon.Message;
using System.Dynamic;
using System.Diagnostics;
using GTICommon.Control;
using System.Transactions;
using System.IO;
using GTIOpenXML;
using System.Data;
using System.Data.SqlClient;


namespace DEBT.Models
{
    public class DEBT103000Repository : BaseRepository
    {
        GTIWF.Models.Flow.FlowRepository _repoFlow;
        DEBT103000ViewModel _model = new DEBT103000ViewModel();

        public DEBT103000ViewModel init()
        {
            _model = new DEBT103000ViewModel();

            return _model;

        }
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="pFilter"></param>
        /// <returns></returns>
        public DEBT103000ViewModel Query(DEBT103000ViewModel.Filter filter, string PName, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_Q00_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = filter.ACCTNMBR,
                    @SYS_NAME = PName,
                    @SYS_SOEID = SOEID,
                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_TEMP = result.Read<DEBT103000ViewModel.Grid>().ToList();
                _model.IS_ADJUST = result.Read<Boolean>().FirstOrDefault();
                _model.IS_FLOW = result.Read<Boolean>().FirstOrDefault();


                //Display ACCTNMBR
                _model.DisACCTNMBR = filter.ACCTNMBR;


            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                List<SelectListItem> lstChecker = GTIWF.Models.SignBox.SignBoxRepository.getCheckerList(SOEID, ref conCOGDB2);
                string _default = lstChecker.Where(x => x.Selected).Select(x => x.Value).SingleOrDefault<string>();
                _model.ddlChecker = new SelectList(lstChecker, "Value", "Text", _default);
                Disconnect(ref conCOGDB2);
            }

            return _model;
        }

        public DEBT103000ViewModel queryTemp(string ACCTNMBR, string PName, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_Q02_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @SYS_NAME = PName,
                    @SYS_SOEID = SOEID,
                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_TEMP = result.Read<DEBT103000ViewModel.Grid>().ToList();
                _model.IS_ADJUST = result.Read<Boolean>().FirstOrDefault();
                _model.IS_FLOW = result.Read<Boolean>().FirstOrDefault();


                //Display ACCTNMBR
                _model.DisACCTNMBR = ACCTNMBR;


            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {   
                Disconnect(ref conCOGDB2);
            }

            return _model;
        }


        /// <summary>
        /// 送出
        /// </summary>
        /// <param name="pFilter"></param>
        /// <returns></returns>
        public DEBT103000ViewModel Submit(string ACCTNMBR, string CHECKER, string PNAME, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            strSQL = "UDEBT_103000_SUBMIT_SP";
            try
            {
                Connect(ref conCOGDB2);



                Guid DOCGUID = Guid.NewGuid();
                SqlTransaction trans = conCOGDB2.ConnObj.BeginTransaction();
                try
                {
                    var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                    {
                        @UI_GUID = DOCGUID,
                        @UI_ACCTNMBR = ACCTNMBR,
                        @UI_CHECKER = CHECKER,
                        @SYS_NAME = PNAME,
                        @SYS_SOEID = SOEID
                    }
                         , commandType: System.Data.CommandType.StoredProcedure, commandTimeout: 600, transaction: trans);
                    _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();

                    if (_model.resultMessage.Status)
                    {
                        _repoFlow = new GTIWF.Models.Flow.FlowRepository(ref conCOGDB2, trans);
                        GTIWF.Models.Flow.NewFlowModel flowDataModel = new GTIWF.Models.Flow.NewFlowModel();

                        flowDataModel.ApplicantID = SOEID;
                        flowDataModel.ApplicantFUC = "";
                        flowDataModel.CreateID = SOEID;
                        flowDataModel.MessageGV = "調整繳款紀錄";
                        flowDataModel.SignerID = CHECKER;
                        flowDataModel.SignerFUC = "";
                        flowDataModel.DocGuid = DOCGUID;
                        flowDataModel.FlowID = "UDEBT_PAYMENT";

                        if (!_repoFlow.SetNewEditDoc(flowDataModel))
                        {
                            throw new Exception(_repoFlow.ErrorMsg);
                        }
                    }
                    else
                    {
                        throw new Exception(_model.resultMessage.Message);
                    }
                    trans.Commit();
                }
                catch
                {
                    trans.Rollback();
                    throw;
                }

            }
            catch (Exception ex)
            {
                _model.resultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {

                Disconnect(ref conCOGDB2);
            }

            return _model;
        }
        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        public MessageStatus Exit(string ACCTNMBR, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            ResultMessage = new MessageStatus { Status = true,Message = ""};
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_EXIT_SP";

                var result = conCOGDB2.ConnObj.Execute(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @SYS_SOEID = SOEID
                }
                     , commandType: System.Data.CommandType.StoredProcedure);

                //if (result > 0)
                //    ResultMessage = new MessageStatus { Status = true, Message = "YES,  視窗關閉...." };
                //else
                //    throw new Exception("SORRY, 視窗關閉失敗, 請再檢查一次....");
            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {

                Disconnect(ref conCOGDB2);
            }

            return ResultMessage;
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        public DEBT103000ViewModel addPayment(string ACCTNMBR, string TXDATE, string TXAMT, string PName, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_I00_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @UI_TXDATE = TXDATE,
                    @UI_TXAMT = TXAMT,
                    @SYS_NAME = PName,
                    @SYS_SOEID = SOEID

                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_TEMP = result.Read<DEBT103000ViewModel.Grid>().ToList();

                //_model.resultMessage.Status = true;
                //_model.resultMessage.Message = "新增成功";
            }
            catch (Exception ex)
            {
                _model.resultMessage.Status = false;
                _model.resultMessage.Message = string.Format("Models error:{0}", ex.Message);

            }
            finally
            {

                Disconnect(ref conCOGDB2);
            }

            return _model;
        }
        /// <summary>
        /// 刪除
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        public DEBT103000ViewModel delPayment(string ACCTNMBR, int SEQNO, string PName, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_D00_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @UI_SEQNO = SEQNO,
                    @SYS_NAME = PName,
                    @SYS_SOEID = SOEID

                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_TEMP = result.Read<DEBT103000ViewModel.Grid>().ToList();

                _model.resultMessage.Status = true;
                _model.resultMessage.Message = "刪除成功";
            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }

            return _model;
        }
        /// <summary>
        /// 取消異動
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <returns></returns>
        public DEBT103000ViewModel Cancel(string ACCTNMBR, string ACTIONTYPE, DateTime LASTUPDATEDDT, int SEQNO, string PName, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {
                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_CANCEL_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @UI_ACTIONTYPE = ACTIONTYPE,
                    @UI_LASTUPDATEDDT = LASTUPDATEDDT,
                    @UI_SEQNO = SEQNO,
                    @SYS_NAME = PName,
                    @SYS_SOEID = SOEID
                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();

                _model.resultMessage.Status = true;
                _model.resultMessage.Message = "取消成功";

            }
            catch (Exception ex)
            {

                _model.resultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {

                Disconnect(ref conCOGDB2);
            }

            return _model;
        }

        public DEBT103000ViewModel Re(DEBT103000ViewModel.Filter filter, string ACCTNMBR, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            try
            {

                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_RE_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = ACCTNMBR,
                    @SYS_SOEID = SOEID
                }
                , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_TEMP = result.Read<DEBT103000ViewModel.Grid>().ToList();
                _model.IS_ADJUST = result.Read<Boolean>().FirstOrDefault();
                _model.IS_FLOW = result.Read<Boolean>().FirstOrDefault();

                _model.DisACCTNMBR = ACCTNMBR;


            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                _model.ddlChecker = new SelectList(GTIWF.Models.SignBox.SignBoxRepository.getCheckerList(SOEID, ref conCOGDB2), "Value", "Text");
                Disconnect(ref conCOGDB2);
            }

            return _model;
        }
        //R0搜尋
        public DEBT103000ViewModel Query_R0(string DOCGUID, string SOEID)
        {
            _model = new DEBT103000ViewModel();
            string CheckerID = "";
            try
            {

                Connect(ref conCOGDB2);

                strSQL = "UDEBT_103000_Q01_SP";

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @DOCGUID = DOCGUID
                }
                , commandType: System.Data.CommandType.StoredProcedure);
                _model.resultMessage = result.Read<MessageStatus>().FirstOrDefault();
                _model.lstUDEBT_PAYMENT_FLOW = result.Read<DEBT103000ViewModel.Grid2>().ToList();
                _model.DocGuid = DOCGUID;
                _model.DisACCTNMBR = _model.lstUDEBT_PAYMENT_FLOW[0].ACCTNMBR;
                CheckerID = GTICommon.Utils.StringUtils.NullToWhiteSpace(_model.lstUDEBT_PAYMENT_FLOW.Where(x => !string.IsNullOrWhiteSpace(x.CHECKER_ID)).Select(x => x.CHECKER_ID).FirstOrDefault());
                
            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                _model.ddlChecker = new SelectList(GTIWF.Models.SignBox.SignBoxRepository.getCheckerList(SOEID, ref conCOGDB2), "Value", "Text", CheckerID);
                Disconnect(ref conCOGDB2);
            }

            return _model;
        }

    }
}