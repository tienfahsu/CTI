﻿using GTICommon.Message;
using GTIMVC.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dapper;
using DEBTModel.Models;
using GTIOpenXML;
using System.IO;
using DEBT.Common;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Script.Serialization;


namespace DEBT.Models
{
    public class DEBT106000Repository : BaseRepository
    {
        DEBT106000ViewModel _model = new DEBT106000ViewModel();

        public DEBT106000ViewModel init()
        {
            _model = new DEBT106000ViewModel();

            return _model;
        }
        public MessageStatus batchCalc(string fullFilePath, string PEName, string SOEID, string templatefile, string filepath)
        {
            _model = new DEBT106000ViewModel();
            ResultMessage = new MessageStatus();
            MemoryStream ms = new MemoryStream();
            List<DEBT106000ViewModel.Filter> lsUp = new List<DEBT106000ViewModel.Filter>();
            List<DEBT106000ViewModel.DEBT_BATCH_REPORT> lsReport = new List<DEBT106000ViewModel.DEBT_BATCH_REPORT>();
            string FilPath = string.Empty;
            List<string> strList = new List<string>();
            List<string> strZip = new List<string>();
            List<string> execReport = new List<string>();
            //For WebApi 用 <--
            List<string> base64List = new List<string>();
            List<string> nameList = new List<string>();
            var jsonDict = new Dictionary<string, object>();
            string base64St = string.Empty;
            byte[] base64by;
            string ExcelName = string.Empty;
            //-->
            DataTable mDT;
            string strFileName = "";
            string ZipName = "";
            #region Declare Excel cell to variable
            string ACCTNMBR;
            DateTime N_INT_DATE = new DateTime();
            DateTime BASE_DATE = new DateTime();
            decimal RATE=0;
            decimal WO_P=0;
            decimal WO_I=0;
            decimal WO_FEE=0;
            decimal PROC_AMNT=0;
            decimal EXEC_AMNT=0;
            DateTime CUT_DATE = new DateTime();
            //decimal CREATEDBYNAME;
            //decimal CREATEDBYID;

            #endregion
            

            DataTable dtExcel = ReadExcelFile("0", fullFilePath, 0);
            try
            {
                conCOGDB2.connect();
                foreach (DataRow wsRow in dtExcel.Rows)
                {
                    ResultMessage = new MessageStatus { Message = "", Status = true };
                    if (dtExcel.Columns.Count == 2 )
                    {
                        #region 使用日後債金計算條件

                        ACCTNMBR = string.IsNullOrWhiteSpace(wsRow[0].ToString()) ? "" : wsRow[0].ToString().Trim();
                        if (string.IsNullOrWhiteSpace(ACCTNMBR))
                        {
                            ResultMessage.Status = false;
                            break;
                        }
                        else
                        {
                            if (!(ACCTNMBR.Length == 16 || ACCTNMBR.Length == 14))
                            {
                                execReport.Add("帳號/卡號(ACCTNMBR)長度有誤");
                                ResultMessage.Status = false;
                            }                           
                            if (string.IsNullOrWhiteSpace(wsRow[1].ToString()) || !DateTime.TryParse(wsRow[1].ToString(), out CUT_DATE)) { execReport.Add("債金計算截止日(CUT_DATE)為空白或格式有誤"); ResultMessage.Status = false; }
                        }

                        if (ResultMessage.Status)
                        {
                            strSQL = "UDEBT_106000_INSERT_FORMAT1_SP";
                            ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                            {
                                @ACCTNMBR = wsRow[0].ToString(),
                                @CREATEDBYID = SOEID,
                                @CREATEDBYNAME = PEName
                            }
                            , commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
                            if (ResultMessage.Status == false)
                            {
                                execReport.Add(ResultMessage.Message);
                                ResultMessage.Status = false;
                            }
                            else //if (ResultMessage.Status)
                            {
                                strSQL = "UDEBT_CALC_DEBT_SP";

                                try
                                {
                                    conCOGDB2.connect();
                                    ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                                    {
                                        @ACCTNMBR = ACCTNMBR,
                                        @CAL_TYPE = "BATCH",
                                        @SOEID = SOEID,
                                        @CUTDATE = CUT_DATE

                                    }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
                                    if (ResultMessage.Status == false)
                                    {
                                        execReport.Add(ResultMessage.Message);
                                    }
                                }
                                catch (Exception ee)
                                {
                                    ResultMessage.Status = false;
                                    ResultMessage.Message = ee.Message;
                                    execReport.Add(ee.Message);
                                }
                            }
                        }
                        
                        #endregion
                    }
                    else if (dtExcel.Columns.Count > 3)
                    {
                        #region 提供債金計算條件
                        #region Check Excel cell format or empty
                        ACCTNMBR = string.IsNullOrWhiteSpace(wsRow[0].ToString()) ? "" : wsRow[0].ToString().Trim();
                        if (string.IsNullOrWhiteSpace(ACCTNMBR))
                        {
                            ResultMessage.Status = false;
                            break;
                        }
                        else
                        {
                            if (!(ACCTNMBR.Length == 16 || ACCTNMBR.Length == 14))
                            {
                                execReport.Add("帳號/卡號(ACCTNMBR)長度有誤");
                                ResultMessage.Status = false;
                            }
                                if (string.IsNullOrWhiteSpace(wsRow[1].ToString()) || !DateTime.TryParse(wsRow[1].ToString(), out N_INT_DATE)) { execReport.Add("利息起算日(N_INT_DATE)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[2].ToString()) || !DateTime.TryParse(wsRow[2].ToString(), out BASE_DATE)) { execReport.Add("計算基準日(BASE_DATE)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[3].ToString()) || !decimal.TryParse(wsRow[3].ToString(), out RATE)) { execReport.Add("利率(RATE)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[4].ToString()) || !decimal.TryParse(wsRow[4].ToString(), out WO_P)) { execReport.Add("本金(WO_P)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[5].ToString()) || !decimal.TryParse(wsRow[5].ToString(), out WO_I)) { execReport.Add("已結算利息(WO_I)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[6].ToString()) || !decimal.TryParse(wsRow[6].ToString(), out WO_FEE)) { execReport.Add("已結算費用(WO_FEE)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[7].ToString()) || !decimal.TryParse(wsRow[7].ToString(), out PROC_AMNT)) { execReport.Add("程序/裁判費(PROC_AMNT)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[8].ToString()) || !decimal.TryParse(wsRow[8].ToString(), out EXEC_AMNT)) { execReport.Add("執行費(EXEC_AMNT)為空白或格式有誤"); ResultMessage.Status = false; }
                            if (string.IsNullOrWhiteSpace(wsRow[9].ToString()) || !DateTime.TryParse(wsRow[9].ToString(), out CUT_DATE)) { execReport.Add("債金計算截止日(CUT_DATE)為空白或格式有誤"); ResultMessage.Status = false; }
                        }


                        #endregion
                        if (ResultMessage.Status)
                        {
                            try
                            {
                                strSQL = "UDEBT_106000_INSERT_FORMAT2_SP";
                                ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                                {
                                    @ACCTNMBR = ACCTNMBR,//wsRow[0].ToString(),
                                    @N_INT_DATE = N_INT_DATE,//wsRow[1].ToString().Trim().Equals("") ? (DateTime?)null : Convert.ToDateTime(wsRow[1].ToString()),
                                    @BASE_DATE = BASE_DATE,//wsRow[2].ToString().Trim().Equals("") ? (DateTime?)null : Convert.ToDateTime(wsRow[2].ToString()),
                                    @RATE = RATE,//wsRow[3].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[3].ToString()) / 100,
                                    @WO_P = WO_P,//wsRow[4].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[4].ToString()),
                                    @WO_I = WO_I,//wsRow[5].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[5].ToString()),
                                    @WO_FEE = WO_FEE,//wsRow[6].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[6].ToString()),
                                    @PROC_AMNT = PROC_AMNT,//wsRow[7].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[7].ToString()),
                                    @EXEC_AMNT = EXEC_AMNT,//wsRow[8].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[8].ToString()),
                                    @CUT_DATE = CUT_DATE,//wsRow[9].ToString().Trim().Equals("") ? DateTime.Now : Convert.ToDateTime(wsRow[9].ToString()),
                                    @CREATEDBYNAME = PEName,
                                    @CREATEDBYID = SOEID,
                                }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
                                if (ResultMessage.Status == false)
                                {
                                    execReport.Add(ResultMessage.Message);
                                }
                            }
                            catch (Exception ea)
                            {
                                ResultMessage.Status = false;
                                ResultMessage.Message = ea.Message;
                                execReport.Add(ea.Message);
                            }
                            strSQL = "UDEBT_CALC_DEBT_SP";
                            if (ResultMessage.Status)
                            {
                                try
                                {
                                    conCOGDB2.connect();
                                    ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                                    {
                                        @ACCTNMBR = wsRow[0].ToString(),
                                        @CAL_TYPE = "BATCH",
                                        @SOEID = SOEID,
                                        @CUTDATE = wsRow[9].ToString().Trim().Equals("") ? (DateTime?)DateTime.Now : Convert.ToDateTime(wsRow[9].ToString())
                                    }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
                                    if (ResultMessage.Status == false)
                                    {
                                        execReport.Add(ResultMessage.Message);
                                    }
                                }
                                catch (Exception ee)
                                {
                                    ResultMessage.Status = false;
                                    ResultMessage.Message = ee.Message;
                                    execReport.Add(ee.Message);
                                }
                            }

                        }
                        #endregion
                    }
                    else
                    {
                        ResultMessage.Status = false;
                        throw new Exception("Excel所提供欄位有誤 請檢查檔案!!");
                    }
                    #region output debt result to excel
                    if (ResultMessage.Status)
                    {
                        strSQL = "SELECT *,dbo.HIDEPI_FN(ACCTNMBR) AS ACCTNMBR_DISP,dbo.HIDEPI_FN(CARDNMBR) AS CARDNMBR_DISP,dbo.HIDEPI2_FN(CUST_NAME) AS CUST_NAME_DISP FROM [COGDB2].[dbo].[UDEBT_OUTPUT] WHERE CARDNMBR = @ACCTNMBR AND CREATORID = @SOEID ORDER BY POST_D";
                        conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@ACCTNMBR", wsRow[0].ToString()));
                        conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@SOEID", SOEID));
                        mDT = conCOGDB2.Query(strSQL);

                        if (mDT == null && !string.IsNullOrWhiteSpace(conCOGDB2.ErrorMessage))
                        {
                            throw (new Exception(conCOGDB2.ErrorMessage));
                        }
                        else
                        {
                            //iCount = mDT.Rows.Count;
                            ////_execlRepo = new DEBTExcelRepository();

                            if (mDT.Rows.Count == 0)
                            {
                                ResultMessage.Status = false;
                                // ResultMessage.Message = "查無此卡號";
                                execReport.Add("查無此卡號");
                            }
                            else
                            {
                                strFileName = mDT.Rows[0]["FILENAME"].ToString();
                                if (strFileName == "")
                                {
                                    ResultMessage.Status = false;
                                    //ResultMessage.Message = "檔名空白檢查資料";
                                    execReport.Add("檔名空白請檢查資料");
                                }
                                else
                                {
                                    if (strFileName.ToUpper().IndexOf(".XLS") < 10)
                                        strFileName = string.Format("{0}.xls", strFileName);

                                    ResultMessage.Status = true;
                                    ResultMessage.Message = mDT.Rows[0]["MESSAGE_TEXT"].ToString();


                                    try
                                    {

                                        if (DEBTExcelRepository.ExportTemplateExcel(mDT, templatefile, System.IO.Path.Combine(filepath, strFileName)))
                                        {

                                            //ResultMessage.File = new List<URLFile>();
                                            //Url.Content(string.Format("~/File/Download?folder={0}&filename={1}","/Files/DEBT" , strFileName))
                                            //ResultMessage.File.Add(new URLFile { title = mDT.Rows[0]["FILENAME"].ToString(), url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
                                            FilPath = Path.Combine(filepath, strFileName);
                                            strList.Add(FilPath);

                                            base64by = System.IO.File.ReadAllBytes(FilPath);
                                            base64St = Convert.ToBase64String(base64by);
                                            base64List.Add(base64St);
                                            ExcelName = Path.GetFileName(strFileName);
                                            nameList.Add(ExcelName);

                                        }
                                    }
                                    catch (Exception ee)
                                    {
                                        ResultMessage.Status = false;
                                        ResultMessage.Message = ee.Message;
                                        execReport.Add(ee.Message);
                                    }
                                }

                            }
                            if (ResultMessage.Status == false && execReport.Count > 0)
                            {
                                lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
                                {
                                    ACCTNMBR = wsRow[0].ToString(),
                                    RESULT = "Fail",
                                    MESSAGE = string.Join(",", execReport)

                                });
                                execReport.Clear();
                            }
                            else
                            {
                                lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
                                {
                                    ACCTNMBR = wsRow[0].ToString(),
                                    RESULT = "Success",
                                    MESSAGE = mDT.Rows[0]["MESSAGE_TEXT"].ToString()//wsRow["MESSAGE_TEXT"].ToString()
                                });
                                execReport.Clear();
                            }
                        }
                    }
                    else
                    {
                        lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
                        {
                            ACCTNMBR = wsRow[0].ToString(),
                            RESULT = "Fail",
                            MESSAGE = string.Join(",", execReport)
                        });
                        execReport.Clear();
                    }
                    #endregion

                }
                if (ResultMessage != null)
                {
                    strFileName = string.Format("DEBT_BATCH_REPORT_{0}_{1}.xls", SOEID, DateTime.Now.ToString("yyyyMMddHHmmss"));
                    ResultMessage = ExportExcel(lsReport, out ms);
                    FilPath = Path.Combine(filepath, strFileName);
                    IoHelper.MsToFile(ms, FilPath);
                    strList.Add(FilPath);

                    //WebApi
                    base64by = System.IO.File.ReadAllBytes(FilPath);
                    base64St = Convert.ToBase64String(base64by);
                    base64List.Add(base64St);
                    ExcelName = Path.GetFileName(strFileName);
                    nameList.Add(ExcelName);

                    jsonDict.Add("ExcelBase64", base64List.ToArray());
                    jsonDict.Add("ExcelName", nameList.ToArray());
                    jsonDict.Add("PWD", "Qwertyuiop[]\\01234");
                    jsonDict.Add("ZipName", "DEBT");
                    jsonDict.Add("SOEID", SOEID);
                    HttpClientHandler handler = new HttpClientHandler();
                    using (HttpClient httpClient = new HttpClient(handler))
                    {
                        HttpResponseMessage response;
                        HttpMethod _Method;
                        HttpContent content;
                        //httpClient.BaseAddress = new Uri("http://APACCITITWAP167.apac.nsroot.net/PROD/WebApiZip/api/Zipc");////****ICSharpZip 
                        httpClient.BaseAddress = new Uri("http://APACCITITWAP167.apac.nsroot.net/PROD/ZipApi/api/Zipc");////****SecureZip

                        httpClient.Timeout = TimeSpan.FromMinutes(10);
                        //httpClient.BaseAddress = new Uri("http://localhost:58311/api/Zipc");
                        JavaScriptSerializer jsJson = new JavaScriptSerializer();
                        jsJson.MaxJsonLength = Int32.MaxValue;

                        var jsonSerial = jsJson.Serialize(jsonDict);
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        content = new StringContent(jsonSerial, Encoding.GetEncoding(65001), "application/json");
                        response = httpClient.PostAsync(httpClient.BaseAddress, content).Result;

                        if (response.IsSuccessStatusCode)
                        {
                            ResultMessage = new MessageStatus { Status = true, Message = response.Content.ReadAsStringAsync().Result };
                            //return ResultMessage;
                           // base64Zip(ResultMessage.Message, SOEID, out ZipName);
                            string base64zip = ResultMessage.Message;

                           // var downloadDir = (string.Format("{0}{1}", GTIUtility.Utility.getAppSeting("ExportExcel"), "DEBT"));
                            ZipName = string.Format("DEBT_BATCH_{0}_{1}.zip", SOEID, DateTime.Now.ToString("yyyyMMddHHmmss"));
                            string ExcelPath = Path.Combine(filepath, ZipName);

                            if (base64zip.IndexOf("\"") >= 0)
                                base64zip = base64zip.Replace("\"", "");


                            byte[] ExcelBytes = Convert.FromBase64String(base64zip);
                            System.IO.File.WriteAllBytes(ExcelPath, ExcelBytes);

                            ResultMessage.Status = true;
                            ResultMessage.Message = "執行完成";
                            ResultMessage.File.Add(new URLFile { title = ZipName, url = (string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", ZipName)) });
                        }
                        else
                        {
                            ResultMessage = new MessageStatus { Status = false, Message = "WebApi Error:" + Convert.ToInt32(response.StatusCode) + ", " + response.Content.ReadAsStringAsync().Result };
                            return ResultMessage;
                        }

                    }


                    //原始程式碼
                    //strFileName = Path.Combine(filepath, "債金計算_" + DateTime.Now.ToString("yyyyMMddHHmm") + ".zip");
                    //ZipHelper.ZipFiles(strList.ToArray(), strFileName, "", false);
                    //FilPath = Path.Combine(filepath, strFileName);
                    //strZip.Add(FilPath);
                    //string zipFileName = string.Format("DEBT_BATCH_{0}_{1}.zip", SOEID, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                    //strFileName = Path.Combine(filepath, zipFileName);
                    //ZipHelper.ZipFiles(strZip.ToArray(), strFileName, "Qwertyuiop[]\\01234", false);
                    //ResultMessage.File.Add(new URLFile { title = zipFileName, url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", zipFileName) });
                    //ResultMessage.Status = true;

                }
            }
            catch (Exception ex)
            {
                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                foreach (string file in strList)
                {
                    if (File.Exists(file))
                    {
                        File.Delete(file);
                    }
                }
                if (conCOGDB2.IsConnected)
                    conCOGDB2.disconnect();
            }
            return ResultMessage;
        }

        //public MessageStatus batchCalc(string fullFilePath,string PEName, string SOEID, string templatefile, string filepath)
        //{
        //    _model = new DEBT106000ViewModel();
        //    ResultMessage = new MessageStatus();
        //    MemoryStream ms = new MemoryStream();
        //    List<DEBT106000ViewModel.Filter> lsUp = new List<DEBT106000ViewModel.Filter>();
        //    List<DEBT106000ViewModel.DEBT_BATCH_REPORT> lsReport = new List<DEBT106000ViewModel.DEBT_BATCH_REPORT>();
        //    string FilPath = string.Empty;
        //    List<string> strList = new List<string>();
        //    List<string> strZip = new List<string>();
        //     DataTable mDT;
        //     string strFileName = "";

        //    DataTable dtExcel = ReadExcelFile("0", fullFilePath, 0);
        //    try
        //    {
        //        #region 使用日後債金計算條件
        //        if (dtExcel.Columns.Count < 3) 
        //    {
        //        //ResultMessage.Status = true;
        //        //ResultMessage.Message = "此為'使用日後債金計算條件'檔案";
        //        foreach (DataRow wsRow in dtExcel.Rows)
        //        {


        //            conCOGDB2.connect();
        //            strSQL = "UDEBT_106000_INSERT_FORMAT1_SP";
        //            ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
        //            {
        //                @ACCTNMBR = _model.filter.ACCTNMBR,
        //                @CREATEDBYID = SOEID,
        //                @CREATEDBYNAME = PEName
        //            }
        //            , commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();


        //            if (ResultMessage != null)
        //            {

        //                strSQL = "SELECT * FROM [COGDB2].[dbo].[UDEBT_OUTPUT] WHERE ACCTNMBR = @ACCTNMBR AND CREATORID = @SOEID ORDER BY POST_D";
        //                conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@ACCTNMBR", wsRow[0].ToString()));
        //                conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@SOEID", SOEID));
        //                mDT = conCOGDB2.Query(strSQL);

        //                if (mDT == null && !string.IsNullOrWhiteSpace(conCOGDB2.ErrorMessage))
        //                {
        //                    throw (new Exception(conCOGDB2.ErrorMessage));
        //                }
        //                else
        //                {
        //                    //iCount = mDT.Rows.Count;
        //                    ////_execlRepo = new DEBTExcelRepository();

        //                    if (mDT.Rows.Count == 0)
        //                    {
        //                        ResultMessage.Status = false;
        //                        ResultMessage.Message = "查無此卡號";
        //                    }
        //                    else
        //                    {
        //                        strFileName = mDT.Rows[0]["FILENAME"].ToString();
        //                        if (strFileName.ToUpper().IndexOf(".XLS") < 10)
        //                            strFileName = string.Format("{0}.xls", strFileName);
        //                        ResultMessage.Status = true;
        //                        ResultMessage.Message = mDT.Rows[0]["MESSAGE_TEXT"].ToString();

        //                        if (DEBTExcelRepository.ExportTemplateExcel(mDT, templatefile, System.IO.Path.Combine(filepath, strFileName)))
        //                        {

        //                            //ResultMessage.File = new List<URLFile>();
        //                            //Url.Content(string.Format("~/File/Download?folder={0}&filename={1}","/Files/DEBT" , strFileName))
        //                            //ResultMessage.File.Add(new URLFile { title = mDT.Rows[0]["FILENAME"].ToString(), url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
        //                            FilPath = Path.Combine(filepath, strFileName);
        //                            strList.Add(FilPath);
        //                        }
        //                    }
        //                    if (ResultMessage.Status == false)
        //                    {
        //                        lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
        //                        {
        //                            ACCTNMBR = wsRow[0].ToString(),
        //                            RESULT = "Fail",
        //                            MESSAGE = ResultMessage.Message
        //                        });
        //                    }
        //                    else
        //                    {
        //                        lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
        //                        {
        //                            ACCTNMBR = wsRow[0].ToString(),
        //                            RESULT = "Success",
        //                            MESSAGE = ""
        //                        });
        //                    }
        //                }
        //            }
        //        }
        //  }
        //        #endregion
        //        #region 提供債金計算條件
        //        else if (dtExcel.Columns.Count > 3)
        //        {
        //            //ResultMessage.Status = true;
        //            //ResultMessage.Message = "此為'提供債金計算條件'檔案";
        //            foreach (DataRow wsRow in dtExcel.Rows)
        //            {

        //                conCOGDB2.connect();
        //                try
        //                {
        //                    strSQL = "UDEBT_106000_INSERT_FORMAT2_SP";
        //                    ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
        //                    {
        //                        @ACCTNMBR = wsRow[0].ToString(),
        //                        @N_INT_DATE = wsRow[1].ToString().Trim().Equals("") ? (DateTime?)null : Convert.ToDateTime(wsRow[1].ToString()),
        //                        @BASE_DATE = wsRow[2].ToString().Trim().Equals("") ? (DateTime?)null : Convert.ToDateTime(wsRow[2].ToString()),
        //                        @RATE = wsRow[3].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[3].ToString()),
        //                        @WO_P = wsRow[4].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[4].ToString()),
        //                        @WO_I = wsRow[5].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[5].ToString()),
        //                        @WO_FEE = wsRow[6].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[6].ToString()),
        //                        @PROC_AMNT = wsRow[7].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[7].ToString()),
        //                        @EXEC_AMNT = wsRow[8].ToString().Trim().Equals("") ? 0 : Convert.ToDecimal(wsRow[8].ToString()),
        //                        @CUT_DATE = wsRow[9].ToString().Trim().Equals("") ? (DateTime?)DateTime.Now : Convert.ToDateTime(wsRow[9].ToString()),
        //                        @CREATEDBYNAME = PEName,
        //                        @CREATEDBYID = SOEID,                                                     
        //                    }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
        //                }
        //                catch (Exception ea)
        //                {
        //                    ResultMessage.Status = false;
        //                    ResultMessage.Message = ea.Message;
        //                }
        //                strSQL = "UDEBT_CALC_DEBT_SP";
        //                try
        //                {
        //                    conCOGDB2.connect();
        //                    ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
        //                    {
        //                        @ACCTNMBR = wsRow[0].ToString(),
        //                        @CAL_TYPE = "BATCH",
        //                        @SOEID = SOEID,
        //                        @CUTDATE = wsRow[9].ToString().Trim().Equals("") ? (DateTime?)DateTime.Now : Convert.ToDateTime(wsRow[9].ToString())

        //                    }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
        //                }
        //                catch (Exception ee)
        //                {
        //                    ResultMessage.Status = false;
        //                    ResultMessage.Message = ee.Message;
        //                }
        //                if (ResultMessage.Status == false)
        //                {
        //                    lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
        //                    {
        //                        ACCTNMBR = wsRow[0].ToString(),
        //                        RESULT = "Fail",
        //                        MESSAGE = ResultMessage.Message
        //                    });
        //                }
        //                else
        //                if (ResultMessage != null)
        //                {

        //                    strSQL = "SELECT * FROM [COGDB2].[dbo].[UDEBT_OUTPUT] WHERE ACCTNMBR = @ACCTNMBR AND CREATORID = @SOEID ORDER BY POST_D";
        //                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@ACCTNMBR", wsRow[0].ToString()));
        //                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@SOEID", SOEID));
        //                    mDT = conCOGDB2.Query(strSQL);

        //                    if (mDT == null && !string.IsNullOrWhiteSpace(conCOGDB2.ErrorMessage))
        //                    {
        //                        throw (new Exception(conCOGDB2.ErrorMessage));
        //                    }
        //                    else
        //                    {
        //                        //iCount = mDT.Rows.Count;
        //                        ////_execlRepo = new DEBTExcelRepository();

        //                        if (mDT.Rows.Count == 0)
        //                        {
        //                            ResultMessage.Status = false;
        //                            ResultMessage.Message = "查無此卡號";
        //                        }
        //                        else
        //                        {
        //                            strFileName = mDT.Rows[0]["FILENAME"].ToString();
        //                            if (strFileName.ToUpper().IndexOf(".XLS") < 10)
        //                                strFileName = string.Format("{0}.xls", strFileName);

        //                            ResultMessage.Message = mDT.Rows[0]["MESSAGE_TEXT"].ToString();

        //                            if (DEBTExcelRepository.ExportTemplateExcel(mDT, templatefile, System.IO.Path.Combine(filepath, strFileName)))
        //                            {

        //                                //ResultMessage.File = new List<URLFile>();
        //                                //Url.Content(string.Format("~/File/Download?folder={0}&filename={1}","/Files/DEBT" , strFileName))
        //                                //ResultMessage.File.Add(new URLFile { title = mDT.Rows[0]["FILENAME"].ToString(), url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
        //                                FilPath = Path.Combine(filepath, strFileName);
        //                                strList.Add(FilPath);
        //                            }
        //                        }
        //                        if (ResultMessage.Status == false)
        //                        {
        //                            lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
        //                            {
        //                                ACCTNMBR = wsRow[0].ToString(),
        //                                RESULT = "Fail",
        //                                MESSAGE = ResultMessage.Message
        //                            });
        //                        }
        //                        else
        //                        {
        //                            lsReport.Add(new DEBT106000ViewModel.DEBT_BATCH_REPORT
        //                            {
        //                                ACCTNMBR = wsRow[0].ToString(),
        //                                RESULT = "Success",
        //                                MESSAGE = ""
        //                            });
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        #endregion
        //        else
        //        {
        //            throw new Exception("Excel 請檢查檔案!!");
        //        }
        //        if (ResultMessage != null)
        //        {

        //                    strFileName = string.Format("DEBT_BATCH_REPORT_{0}_{1}.xls", SOEID, DateTime.Now.ToString("yyyyMMddHHmm"));
        //                    ResultMessage = ExportExcel(lsReport, out ms);
        //                    FilPath = Path.Combine(filepath, strFileName);
        //                    IoHelper.MsToFile(ms, FilPath);
        //                    strList.Add(FilPath);
        //                    strFileName = Path.Combine(filepath, "債金計算_" + DateTime.Now.ToString("yyyyMMddHHmm") + ".zip");
        //                    ZipHelper.ZipFiles(strList.ToArray(), strFileName, "", false);
        //                    FilPath = Path.Combine(filepath, strFileName);
        //                    strZip.Add(FilPath);
        //                    strFileName = Path.Combine(filepath, "TEST密碼12XXX6.zip");
        //                    ZipHelper.ZipFiles(strZip.ToArray(), strFileName, "12XXX6", false);
        //                    ResultMessage.File.Add(new URLFile { title = "TEST密碼123456.zip", url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
        //                    ResultMessage.Status = true;
        //                }                                  
        //    }
        //    catch (Exception ex)
        //    {
        //        ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
        //    }
        //    finally
        //    {
        //        if (conCOGDB2.IsConnected)
        //            conCOGDB2.disconnect();
        //    }
        //    return ResultMessage;
        //}
    }
}
