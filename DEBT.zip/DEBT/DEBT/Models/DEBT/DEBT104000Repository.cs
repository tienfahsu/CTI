﻿using GTICommon.Message;
using GTIMVC.Models;
using GTIWF.Models.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;

namespace DEBT.Models
{
    public class DEBT104000Repository : BaseRepository
    {
        public DEBT104000ViewModel Init(string SignerID)
        {
            DEBT104000ViewModel model = new DEBT104000ViewModel();
            strSQL = "F_SIGNBOX_DEBT_SP";

            try
            {
                Connect(ref conCOGDB2);

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @SIGNERID = SignerID
                }, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: 600);

                model.msg = result.Read<MessageStatus>().FirstOrDefault();
                model.lstUDEBT_SIGNBOX = result.Read<DEBT104000ViewModel.GridViewClass>().ToList();

                #region 測試資料
                //model.lstUDEBT_SIGNBOX = Enumerable.Range(1, 10).Select(x => new DEBT104000ViewModel.GridViewClass
                //{
                //    SEQNO = x,
                //    DOCGUID = new Guid(),
                //    TABLENAME = "UDEBT_CALC_SETTING_FLOW",
                //    FLOWID = "SY12345",
                //    ACCTNMBR = "1111222233334444",
                //    MAKER = "Reven",
                //    MAKER_ID = "RL12345",
                //    MAKER_NAME = "Reven Liu",
                //    MAKE_DT = DateTime.Parse("2018/04/09"),
                //    CHEKCER_ID = "JL20060",
                //    MESSAGEGV = "設定日後債金計算條件",
                //    ACTIONLINK = "~/DEBT/DEBT1020R0/1",
                //}).ToList();
                #endregion
            }
            catch (Exception ex)
            {
                model.msg = new MessageStatus { 
                    Status = false, Message = string.Format("Models error:{0}", ex.Message) 
                };
            }
            finally 
            {
                Disconnect(ref conCOGDB2);
            }

            return model;
        }
    }
}