﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DEBTModel.Models;
using GTICommon.Message;

namespace DEBT.Models
{
    public class DEBT102000ViewModel
    {
        #region 參數區
        public MessageStatus msg { get; set; }//訊息
        public Filter filter { get; set; }//00F
        //public R0_Filter R0_filter { get; set; }//0R0
        public UDEBT_CALC_SETTING_TEMP SettingValues { get; set; }//設定債金條件之參數
        public List<UDEBT_CALC_SETTING_FLOW> lstCALC_SETTING { get; set; }//001
        public UDEBT_CALC_SETTING_FLOW CALC_SETTING_FLOW { get; set; }//002
        public List<UDEBT_OUTPUT> lstEXCEL_REPORT { get; set; }//execl輸出
        public R0_ViewData flowData { get; set; }
        #endregion

        public class Filter
        {
            [DisplayName("帳號/卡號")]
            public string F_ACCTNMBR { get; set; }

            [DisplayName("債金計算截止日")]
            public string CUT_DATE { get; set; }

            //判定是否已在流程當中( True -> 介面按鈕上鎖)
            public bool IS_FLOW { get; set; }
        }


        public class R0_ViewData
        {
            public SelectList ddlChecker { get; set; }
            public string DocGuid { get; set; }
            public UDEBT_CALC_SETTING beforeData { get; set; }
            public UDEBT_CALC_SETTING afterData { get; set; }
        }
        //public class R0_Filter : UDEBT_CALC_SETTING
        //{
        //    public List<SelectListItem> ddlChecker { get; set; }

        //    public string Mode { get; set; }
        //    //public UDEBT_CALC_SETTING R0 { get; set; }
        //}

        //public class GridViewData : UDEBT_CALC_SETTING
        //{
        //    //-------------------------- add by reven --------------------------
        //    [DisplayName("法務費")] public decimal TOTAL_AMNT { get; set; }
        //}

        public class DeptSetting : UDEBT_CALC_SETTING_FLOW
        {
            public string NEW_CHECKER_ID { get; set; }

            public string NEW_CHECKER_NAME { get; set; }
        }

        public DEBT102000ViewModel()
        {
            msg = new MessageStatus();
            filter = new Filter();
            SettingValues = new UDEBT_CALC_SETTING_TEMP();
            CALC_SETTING_FLOW = new UDEBT_CALC_SETTING_FLOW();
            lstCALC_SETTING = new List<UDEBT_CALC_SETTING_FLOW>();
            lstEXCEL_REPORT = new List<UDEBT_OUTPUT>();

            //R0專用
            flowData = new R0_ViewData();
            //flowData.ddlChecker = new List<SelectListItem>();
        }
    }
}
