﻿using GTICommon.Message;
using DEBTModel.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace DEBT.Models
{
    public class DEBT103000ViewModel
    {
        public UDEBT_PAYMENT PAYMENT { get; set; }
        public UDEBT_PAYMENT_TEMP PAYMENT_TEMP { get; set; }
        public Filter pFilter { get; set; }
        public SelectList ddlChecker { get; set; }
        
        public List<UDEBT_PAYMENT> lstUDEBT_PAYMENT { get; set; }
        public List<Grid> lstUDEBT_PAYMENT_TEMP { get; set; }
        public List<Grid2> lstUDEBT_PAYMENT_FLOW { get; set; }
        public MessageStatus resultMessage { get; set; }
        public string SEQNO { get; set; }
        public string ACTIONTYPE { get; set; }
        public string LASTUPDATEDDT { get; set; }
        public string DisACCTNMBR { get; set; }
        public bool IS_FLOW { get; set; }
        public bool IS_ADJUST { get; set; }
        public string DocGuid { get; set; }

        public class Filter
        {
            [DisplayName("帳號/卡號")]
            public string ACCTNMBR { get; set; }

            [DisplayName("Checker")]
            public string CHECKER { get; set; }

            public bool IS_FLOW { get; set; }

            public bool IS_ADJUST { get; set; }
        }

        public class Grid : UDEBT_PAYMENT_TEMP
        {
           
        }
        public class Grid2 : UDEBT_PAYMENT_FLOW
        {

        }

       public DEBT103000ViewModel()
        {
            pFilter = new Filter();
            PAYMENT_TEMP = new UDEBT_PAYMENT_TEMP();
            PAYMENT = new UDEBT_PAYMENT();
            lstUDEBT_PAYMENT_TEMP = new List<Grid>();
            lstUDEBT_PAYMENT_FLOW = new List<Grid2>();
            lstUDEBT_PAYMENT = new List<UDEBT_PAYMENT>();
            resultMessage = new MessageStatus();
        }

    }
}