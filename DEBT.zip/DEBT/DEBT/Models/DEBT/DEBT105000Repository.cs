﻿using GTIMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;
using System.Web.Mvc;
using GTICommon.Message;
using System.Dynamic;
using System.Diagnostics;
using GTICommon.Control;
using System.Transactions;
using System.IO;
using GTIOpenXML;
using System.Data;

namespace DEBT.Models
{
    public class DEBT105000Repository : BaseRepository
    {
        DEBT105000ViewModel model = new DEBT105000ViewModel();
        /// <summary>
        /// 載入並搜尋所有條件
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT105000ViewModel init(DEBT105000ViewModel.Filter filter,string SOEID)
        {
            model = new DEBT105000ViewModel();
            filter.FLOWSTATUS = string.IsNullOrWhiteSpace(filter.FLOWSTATUS) ? "ALL" : filter.FLOWSTATUS;

            try
            {
                Connect(ref conCOGDB2);

                strSQL = "F_APPLICATION_DEBT_SP";
#if DEBUG
                SOEID = "DS13856";
#endif
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @ACCTNMBR = filter.ACCTNMBR,
                    @FLOW_STATUS = filter.FLOWSTATUS,
                    @MAKER_ID = SOEID,
                }
                     , commandType: System.Data.CommandType.StoredProcedure);
                model.msg = result.Read<MessageStatus>().FirstOrDefault();
                model.lstUDEBT_APPLICATION = result.Read<DEBT105000ViewModel.Grid>().ToList();

                model.filter = filter;
                         
            }
            catch (Exception ex)
            {

                ResultMessage = new MessageStatus { Status = false, Message = string.Format("Models error:{0}", ex.Message) };
            }
            finally
            {
                //model.filter.ddlSTATUS = new System.Web.Mvc.SelectList(getCodeTextList("DEBT", "STATUS", "", ListOption.All), "Value", "Text", "");
                model.filter.ddlSTATUS = new System.Web.Mvc.SelectList(GTIWF.Models.Common.CodeRepository.getCodeTextList("STATUS", ref conCOGDB2), "Value", "Text", filter.FLOWSTATUS);
                Disconnect(ref conCOGDB2);
            }
            return model;
        }
    }
}
