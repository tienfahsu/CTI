﻿using GTICommon.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DEBT.Models
{
    public class DEBT106000ViewModel
    {
        public Filter filter { get; set; }
        public MessageStatus Msg { get; set; }
        public class Filter
        {
            public string ACCTNMBR { get; set; }
            public DateTime? N_INT_DATE { get; set; }
            public DateTime? BASE_DATE { get; set; }
            public decimal RATE { get; set; }
            public decimal WO_P { get; set; }
            public decimal WO_I { get; set; }
            public decimal WO_FEE { get; set; }
            public decimal PROC_AMNT { get; set; }
            public decimal EXEC_AMNT { get; set; }
            public string CAL_TYPE { get; set; }
            public string CREATEDBYID { get; set; }
            public DateTime? CUT_DATE { get; set; }
            public string CREATEDBYNAME { get; set; }
            public DateTime? CREATEDDT { get; set; }
        }
        public class DEBT_BATCH_REPORT
        {
            public string ACCTNMBR { get; set; }
            public double REMAIN_BALANCE { get; set; }
            public string CUT_DATE { get; set; }
            public string FILE_NAME { get; set; }
            public string RESULT { get; set; }
            public string MESSAGE { get; set; }       
        }

         public DEBT106000ViewModel()
        {
            filter = new Filter();
           
        }
    }
}
