﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GTIWF.Models.DataModel;
using GTICommon.Message;

namespace DEBT.Models
{
    public class DEBT105000ViewModel
    {
        public Filter filter { get; set; }
        public List<Grid> lstUDEBT_APPLICATION { get; set; }
        public MessageStatus msg { get; set; }
        public F_APPLICATION_DEBT APPLICATION_DEBT { get; set; }
        public string SEQNO { get; set; }
        public class Grid : F_APPLICATION_DEBT
        {
            public string SEQNO { get; set; }
        }
        public class Filter
        {
            public string MAKERID { get; set; }
            public SelectList ddlSTATUS { get; set; }
            public string FLOWSTATUS { get; set; }
            public string ACCTNMBR { get; set; }

        }

          public DEBT105000ViewModel()
        {
            filter = new Filter();
            msg = new MessageStatus();
            lstUDEBT_APPLICATION = new List<Grid>();
        }
    }
}
