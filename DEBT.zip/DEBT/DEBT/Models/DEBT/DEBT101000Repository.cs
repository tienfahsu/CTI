﻿using GTIMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;
using System.Web.Mvc;
using GTICommon.Message;
using System.Dynamic;
using System.Diagnostics;
using GTICommon.Control;
using System.Transactions;
using System.IO;
using GTIOpenXML;
using System.Data;
namespace DEBT.Models
{
    public class DEBT101000Repository : BaseRepository
    {
        private DEBT101000ViewModel _model { get; set; }

        public DEBT101000ViewModel init()
        {
            _model = new DEBT101000ViewModel();
            _model.filter.F_CUTDATE = DateTime.Now;
            #region Build filter
            _model.Data2.ddlT2_BAL_TYPE = getBAL_Type(_model.Data2.T2_BAL_TYPE);
            #endregion
            return _model;
        }

        /// <summary>
        /// query
        /// </summary>
        /// <param name="_filter"></param>
        /// <returns></returns>
        public DEBT101000ViewModel init(DEBT101000ViewModel.Filter _filter)
        {
            _model = new DEBT101000ViewModel(_filter);

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                SetModel(_filter);

                //Account>=36為ECS，其餘為ALS
                //若帳號未輸入，則不查詢資料
                if (!string.IsNullOrEmpty(_filter.F_ACCTNMBR))
                {
                    strSQL = "UDEBT_DEBT10100_QUERY_SP";
                    var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                    {
                        @THISFORM_ACCTNMBR_VALUE = _filter.F_ACCTNMBR
                    }, commandType: System.Data.CommandType.StoredProcedure);

                    if (result != null)
                    {
                        ResultMessage = result.Read<MessageStatus>().FirstOrDefault();
                        _model.TempMsg = ResultMessage.Message;
                        if (Convert.ToInt16(_filter.F_ACCTNMBR.Substring(0, 2)) >= 36) //ECMS
                        {
                            _model.Data1 = result.Read<dynamic>().Select(x => new DEBT101000ViewModel.T1_DATA
                            {
                                T1_INT_AMNT = x.INT_AMNT == null ? "0" : ((Decimal)x.INT_AMNT).ToString(),
                                T1_EXEC_AMNT = x.EXEC_AMNT == null ? "0" : ((Decimal)x.EXEC_AMNT).ToString(),
                                T1_FEE_AMNT = x.FEE_AMNT == null ? "0" : ((Decimal)x.FEE_AMNT).ToString(),
                                T1_PROC_AMNT = x.PROC_AMNT == null ? "0" : ((Decimal)x.PROC_AMNT).ToString(),
                                T1_BASE_DATE = x.BASE_DATE == null ? "" : ((DateTime)x.BASE_DATE).ToString("yyyy/MM/dd"),
                                T1_SOURCE = x.SOURCE,
                                T1_IF_PREWO = x.IF_PREWO_VALUE,
                                T1_IF_RECORD = x.IF_RECORD,
                                T1_IF_XXWO = "N",
                                T1_REMARK = x.REMARK,
                                T1_UPDATE_P = x.UPDATE_P,
                                T1_UPDATE_T = ((DateTime)x.UPDATE_T).ToString("yyyy/MM/dd hh:mm:ss"),
                                T1_IS_ECMS = x.IS_ECMS

                            }).FirstOrDefault();
                        }
                        else //als
                        {
                            _model.Data1 = result.Read<dynamic>().Select(x => new DEBT101000ViewModel.T1_DATA
                            {
                                T1_INT_AMNT = x.INT_AMNT == null ? "0" : ((Decimal)x.INT_AMNT).ToString(),
                                T1_EXEC_AMNT = x.EXEC_AMNT == null ? "0" : ((Decimal)x.EXEC_AMNT).ToString(),
                                T1_FEE_AMNT = x.FEE_AMNT == null ? "0" : ((Decimal)x.FEE_AMNT).ToString(),
                                T1_PROC_AMNT = x.PROC_AMNT == null ? "0" : ((Decimal)x.PROC_AMNT).ToString(),
                                T1_BASE_DATE = x.BASE_DATE == null ? "" : ((DateTime)x.BASE_DATE).ToString("yyyy/MM/dd"),
                                T1_SOURCE = x.SOURCE,
                                T1_IF_PREWO = x.IF_PREWO_VALUE,
                                T1_IF_RECORD = x.IF_RECORD,
                                T1_IF_XXWO = x.IF_XXWO_VALUE,
                                T1_REMARK = x.REMARK,
                                T1_UPDATE_P = x.UPDATE_P,
                                T1_UPDATE_T = ((DateTime)x.UPDATE_T).ToString("yyyy/MM/dd hh:mm:ss"),
                                T1_IS_ECMS = x.IS_ECMS

                            }).FirstOrDefault();
                        }

                        _model.Grid1 = result.Read<dynamic>().Select(x => new DEBT101000ViewModel.T1_Grid
                        {
                            STMT_YM = x.STMT_YM,
                            BAL_TYPE = x.BAL_TYPE,
                            APR = string.IsNullOrEmpty(x.APR) ? 0 : Convert.ToDecimal(x.APR),
                            N_INT_DATE = string.IsNullOrEmpty(x.N_INT_DATE) ? null : Convert.ToDateTime(x.N_INT_DATE),
                            AMOUNT = string.IsNullOrEmpty(x.AMOUNT) ? 0 : Convert.ToDecimal(x.AMOUNT),
                            ACCTNMBR = x.ACCTNMBR
                        }).ToList();

                        DEBT101000ViewModel.Filter tFilter = result.Read<DEBT101000ViewModel.Filter>().FirstOrDefault();
                        _model.filter.H_ACCTNMBR = tFilter.H_ACCTNMBR;
                        _model.Controls = result.Read<UIControl>().ToList();

                        _model.Grid3 = result.Read<DEBT101000ViewModel.T3_Grid>().ToList();
                    }
                }
                #region Build filter
                _model.Data2.ddlT2_BAL_TYPE = getBAL_Type(_model.Data2.T2_BAL_TYPE);
                #endregion


                if (_model.debtType == DEBT101000ViewModel.DEBTType.ALS)
                {

                }
                else if (_model.debtType == DEBT101000ViewModel.DEBTType.ECS)
                {

                }
                else
                {
                    //return empty model
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conCOGDB2.disconnect();
            }
            return _model;
        }

        /// <summary>
        /// T1 - ADD
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="BASE_DATE"></param>
        /// <param name="FINE_DATE"></param>
        /// <param name="INT_AMNT"></param>
        /// <param name="FEE_AMNT"></param>
        /// <param name="EXEC_AMNT"></param>
        /// <param name="PROC_AMNT"></param>
        /// <param name="FINE_TYPE"></param>
        /// <param name="FINE_AMT"></param>
        /// <param name="FINE_AMT2"></param>
        /// <param name="FINERATE_A"></param>
        /// <param name="FINERATE_B"></param>
        /// <param name="FINE_RATE"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Add(string HACCTNMBR, string ACCTNMBR, string BASE_DATE, string FINE_DATE,
            string INT_AMNT, string FEE_AMNT, string EXEC_AMNT, string PROC_AMNT, string FINE_TYPE,
            string FINE_AMT, string FINE_AMT2, string FINERATE_A, string FINERATE_B, string FINE_RATE, string SOEID)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_New_SP_Sage";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_H_ACCTNMBR_VALUE = HACCTNMBR,
                    @THISFORM_ACCTNMBR_VALUE = ACCTNMBR,
                    @THISFORM_BASE_DATE_VALUE = BASE_DATE,
                    @THISFORM_FINE_DATE_VALUE = FINE_DATE,
                    @THISFORM_INT_AMNT_VALUE = INT_AMNT,
                    @THISFORM_FEE_AMNT_VALUE = FEE_AMNT,
                    @THISFORM_EXEC_AMNT_VALUE = EXEC_AMNT,
                    @THISFORM_PROC_AMNT_VALUE = PROC_AMNT,

                    @THISFORM_FINE_TYPE_VALUE = FINE_TYPE,
                    @THISFORM_FINE_AMT_VALUE = FINE_AMT,
                    @THISFORM_FINE_AMT2_VALUE = FINE_AMT2,
                    @THISFORM_FINERATE_A_VALUE = FINERATE_A,
                    @THISFORM_FINERATE_B_VALUE = FINERATE_B,
                    @THISFORM_FINE_RATE_VALUE = FINE_RATE,
                    @THISFORM_UPDATE_P_VALUE = SOEID
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// T1 - 取消設定為日後債金計算條件
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Cancel(string SOURCE, string HACCTNMBR, string ACCTNMBR, string SOEID)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_NONSETUP_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_SOURCE_VALUE = SOURCE,
                    @THISFORM_H_ACCTNMBR_VALUE = HACCTNMBR,
                    @THISFORM_ACCTNMBR_VALUE = ACCTNMBR,
                    @THISFORM_UPDATE_P_VALUE = SOEID
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 回復備份的人工設定
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="ISFIRSTTIME"></param>
        /// <param name="ISCONTINUE"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Restore(string HACCTNMBR, string ACCTNMBR, bool ISFIRSTTIME, bool ISCONTINUE)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_RESTORE_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_H_ACCTNMBR_VALUE = HACCTNMBR,
                    @THISFORM_ACCTNMBR_VALUE = ACCTNMBR,
                    @ISFIRSTTIME = ISFIRSTTIME,
                    @ISCONTINUE = ISCONTINUE
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.cf = result.Read<Confirm>().FirstOrDefault();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 回復備份的人工設定
        /// </summary>
        /// <param name="HACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="ISFIRSTTIME"></param>
        /// <param name="ISCONTINUE"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Backup(string HACCTNMBR, string ACCTNMBR, bool ISFIRSTTIME, bool ISCONTINUE)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_BACKUP_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_H_ACCTNMBR_VALUE = HACCTNMBR,
                    @THISFORM_ACCTNMBR_VALUE = ACCTNMBR,
                    @ISFIRSTTIME = ISFIRSTTIME,
                    @ISCONTINUE = ISCONTINUE
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.cf = result.Read<Confirm>().FirstOrDefault();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 設定為日後債金計算條件
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="HACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="UPDATE_P"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Setting(string SOURCE, string HACCTNMBR, string ACCTNMBR, string UPDATE_P)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_SETUP_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_SOURCE_VALUE = SOURCE,
                    @THISFORM_H_ACCTNMBR_VALUE = HACCTNMBR,
                    @THISFORM_ACCTNMBR_VALUE = ACCTNMBR,
                    @THISFORM_UPDATE_P_VALUE = UPDATE_P
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="H_ACCTNMBR"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="BASE_DATE"></param>
        /// <param name="INT_AMNT"></param>
        /// <param name="FEE_AMNT"></param>
        /// <param name="EXEC_AMNT"></param>
        /// <param name="PROC_AMNT"></param>
        /// <param name="M_N_INT_DATE">ALS INT_DATE</param>
        /// <param name="M_WO_P">ALS WO_P</param>
        /// <param name="M_WO_I">ALS WO_I</param>
        /// <param name="M_RATE">ALS RATE</param>
        /// <param name="M_INSTALMENT">ALS INSTALMENT</param>
        /// <param name="REMARK">ECS REMARK</param>
        /// <param name="UPDATE_P"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T1_Update(string SOURCE, string H_ACCTNMBR, string ACCTNMBR, string BASE_DATE,
            string INT_AMNT, string FEE_AMNT, string EXEC_AMNT, string PROC_AMNT, string M_N_INT_DATE,
            string M_WO_P, string M_WO_I, string M_RATE,  string UPDATE_P,string REMARK)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101M00_UPDATE_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @SOURCE = SOURCE,
                    @H_ACCTNMBR = H_ACCTNMBR,
                    @ACCTNMBR = ACCTNMBR,
                    @BASE_DATE = BASE_DATE,
                    @INT_AMNT = INT_AMNT,
                    @FEE_AMNT = FEE_AMNT,
                    @EXEC_AMNT = EXEC_AMNT,
                    @PROC_AMNT = PROC_AMNT,
                    @M_N_INT_DATE = M_N_INT_DATE ,
                    @M_WO_P =M_WO_P,
                    @M_WO_I = M_WO_I,
                    @M_RATE = M_RATE,                   
                    @REMARK = REMARK,
                
                    @UPDATE_P = UPDATE_P
                  
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.cf = result.Read<Confirm>().FirstOrDefault();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }


        /// <summary>
        /// 債金計算
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="CUEDATE"></param>
        /// <param name="SOEID"></param>
        /// <param name="ms"></param>
        /// <param name="iCount"></param>
        /// <returns></returns>
        //public MessageStatus T1_Calc(string ACCTNMBR, string CUTDATE, string CAL_TYPE, string SOEID, string templatefile, out MemoryStream ms, out int iCount,  out string filename)
        public MessageStatus T1_Calc(string ACCTNMBR, string CUTDATE, string CAL_TYPE, string SOEID, string templatefile,string filepath)
        {
            ResultMessage = new MessageStatus { Status = false, Message = "" };
            //ms = new MemoryStream();
            //iCount = 0;
            string strFileName = "";
            //DEBTExcelRepository _execlRepo;
            DataTable mDT ;
            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }
                strSQL = "UDEBT_CALC_DEBT_SP";
                ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                                                                       {
                                                                           @ACCTNMBR = ACCTNMBR,
                                                                           @CAL_TYPE = CAL_TYPE,
                                                                           @SOEID = SOEID,
                                                                           @CUTDATE = CUTDATE
                                                                       }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();

                if (ResultMessage != null && ResultMessage.Status)
                {

                    strSQL = "SELECT * FROM [COGDB2].[dbo].[UDEBT_OUTPUT] WHERE CARDNMBR = @ACCTNMBR AND [CREATORID] = @SOEID ORDER BY POST_D";
                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@ACCTNMBR",ACCTNMBR));
                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@SOEID", SOEID));
                    mDT = conCOGDB2.Query(strSQL);

                    if (mDT == null && !string.IsNullOrWhiteSpace(conCOGDB2.ErrorMessage))
                    {
                        throw (new Exception(conCOGDB2.ErrorMessage));
                    }
                    else
                    {
                        //iCount = mDT.Rows.Count;
                        ////_execlRepo = new DEBTExcelRepository();
                        strFileName = mDT.Rows[0]["FILENAME"].ToString();
                        if (strFileName.ToUpper().IndexOf(".XLS") < 10)
                            strFileName = string.Format("{0}.xls", strFileName);
                        
                        ResultMessage.Message = mDT.Rows[0]["MESSAGE_TEXT"].ToString();
                        DEBTExcelRepository execlRepo = new DEBTExcelRepository();
                        if (execlRepo.ExportTemplateExcel(mDT, templatefile, System.IO.Path.Combine(filepath, strFileName)))
                        {
                            ResultMessage.File = new List<URLFile>();
                            //Url.Content(string.Format("~/File/Download?folder={0}&filename={1}","/Files/DEBT" , strFileName))
                            ResultMessage.File.Add(new URLFile { title = mDT.Rows[0]["FILENAME"].ToString(), url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                ResultMessage = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }



            return this.ResultMessage;
        }

        /// <summary>
        /// 人工設定 , T2 新增
        /// </summary>
        /// <param name="ACCTNMBR"></param>
        /// <param name="STMT_YM"></param>
        /// <param name="APR"></param>
        /// <param name="N_INT_DATE"></param>
        /// <param name="PRI_AMNT"></param>
        /// <param name="BAL_TYPE"></param>
        /// <param name="FINE_TYPE"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T2_Add(string ACCTNMBR, string STMT_YM, string APR, string N_INT_DATE, string PRI_AMNT, string BAL_TYPE, string FINE_TYPE, string SOEID)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101A00_ADD_SP_Sage";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_H_ACCTNMBR_VALUE = ACCTNMBR,
                    @THISFORM_STMT_YM_VALUE = STMT_YM,
                    @THISFORM_APR_VALUE = APR,
                    @THISFORM_N_INT_DATE_VALUE = N_INT_DATE,
                    @THISFORM_PRI_AMNT_VALUE = PRI_AMNT,
                    @THISFORM_BAL_TYPE_VALUE = BAL_TYPE,
                    @THISFORM_FINE_TYPE_VALUE = FINE_TYPE,
                    @THISFORM_UPDATE_P_VALUE = SOEID
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 人工設定 , T2 刪除 , 可多筆刪除
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="STMT_YM"></param>
        /// <param name="APR"></param>
        /// <param name="BAL_TYPE"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T2_Del(List<DEBT101000ViewModel.T2_DELETE> list, string SOEID)
        {
            List<DEBT101000ViewModel.MessageControl> lsMC = new List<DEBT101000ViewModel.MessageControl>();
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();
            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101A00_DEL_SP_Sage";
                if (list.Count > 0)
                {
                    using (var transactionScope = new TransactionScope())
                    {
                        try
                        {
                            for (int i = 0; i < list.Count; i++)
                            {
                                DEBT101000ViewModel.MessageControl pmc = new DEBT101000ViewModel.MessageControl();

                                string SOURCE = list[i].SOURCE;
                                string ACCTNMBR = list[i].ACCTNMBR;
                                string STMT_YM = list[i].STMT_YM;
                                string APR = list[i].APR;
                                string BAL_TYPE = list[i].BAL_TYPE;

                                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                                {
                                    @THISFORM_SOURCE_VALUE = SOURCE,
                                    @THISFORM_H_ACCTNMBR_VALUE = ACCTNMBR,
                                    @THISFORM_STMT_YM_VALUE = STMT_YM,
                                    @THISFORM_APR_VALUE = APR,
                                    @THISFORM_BAL_TYPE_VALUE = BAL_TYPE,
                                    @THISFORM_UPDATE_P_VALUE = SOEID
                                }, commandType: System.Data.CommandType.StoredProcedure);

                                if (result != null)
                                {
                                    pmc.ms = result.Read<MessageStatus>().First();
                                    pmc.controls = result.Read<UIControl>().ToList();
                                }
                                lsMC.Add(pmc);
                            }
                            transactionScope.Complete();
                        }
                        catch (Exception ex)
                        {
                            lsMC = new List<DEBT101000ViewModel.MessageControl>();
                            lsMC.Add(new DEBT101000ViewModel.MessageControl { ms = new MessageStatus { Status = false, Message = ex.Message } });
                            //trans.Rollback();
                        }

                    }

                    bool bFlag = lsMC.Select(x => x.ms).Count(x => x.Status == false) > 0 ? false : true;
                    if (bFlag)
                    {
                        mc = lsMC.FirstOrDefault();
                    }
                    else
                    {
                        for (int j = 0; j < lsMC.Count; j++)
                        {
                            if (lsMC[j].ms.Status)
                                continue;

                            mc = lsMC[j];
                            break;
                        }
                    }
                }
                else
                {
                    mc = new DEBT101000ViewModel.MessageControl { ms = new MessageStatus { Status = false, Message = "無刪除資料" } };
                }
            }
            catch (Exception ex)
            {
                mc = new DEBT101000ViewModel.MessageControl { ms = new MessageStatus { Status = false, Message = ex.Message } };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        /// <summary>
        /// 人工設定 , T2 更新
        /// </summary>
        /// <param name="SOURCE"></param>
        /// <param name="ACCTNMBR"></param>
        /// <param name="STMT_YM"></param>
        /// <param name="APR"></param>
        /// <param name="N_INT_DATE"></param>
        /// <param name="PRI_AMNT"></param>
        /// <param name="BAL_TYPE"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT101000ViewModel.MessageControl T2_Update(string SOURCE, string ACCTNMBR, string STMT_YM, string APR, string N_INT_DATE, string PRI_AMNT, string BAL_TYPE, string SOEID)
        {
            DEBT101000ViewModel.MessageControl mc = new DEBT101000ViewModel.MessageControl();

            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                strSQL = "UDEBT_DEBT101A00_UPDATE_SP";
                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @THISFORM_SOURCE_VALUE = SOURCE,
                    @THISFORM_H_ACCTNMBR_VALUE = ACCTNMBR,
                    @THISFORM_STMT_YM_VALUE = STMT_YM,
                    @THISFORM_APR_VALUE = APR,
                    @THISFORM_N_INT_DATE_VALUE = N_INT_DATE,
                    @THISFORM_PRI_AMNT_VALUE = PRI_AMNT,
                    @THISFORM_BAL_TYPE_VALUE = BAL_TYPE,
                    @THISFORM_UPDATE_P_VALUE = SOEID
                }, commandType: System.Data.CommandType.StoredProcedure);

                if (result != null)
                {
                    mc.ms = result.Read<MessageStatus>().First();
                    mc.controls = result.Read<UIControl>().ToList();
                }
            }
            catch (Exception ex)
            {
                mc.ms = new MessageStatus { Status = false, Message = ex.Message };
            }
            finally
            {
                conCOGDB2.disconnect();
            }

            return mc;
        }

        public SelectList getBAL_Type(string defaultValue = "")
        {
            List<SelectListItem> list = new List<SelectListItem>();
            try
            {
                if (!conCOGDB2.IsConnected)
                {
                    conCOGDB2.connect();
                }

                list = getCodeList("DEBT", "ECS_BAL_TYPE", null, ListOption.Blank);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("ERROR:"+ex.Message);
            }
            return new SelectList(list, "Value", "Text", defaultValue);

        }

        [Conditional("DEBUG")]
        private void SetModel(DEBT101000ViewModel.Filter _filter)
        {
            if (_filter.F_ACCTNMBR == null)
            {
                _model.debtType = DEBT101000ViewModel.DEBTType.EMPTY;
            }
            else
            {
                strSQL = "UDEBT_DEBT10100_QUERY_SP";
            }
        }
    }
}