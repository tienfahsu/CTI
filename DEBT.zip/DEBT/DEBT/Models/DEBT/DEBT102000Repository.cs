﻿using System;
using System.IO;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using Dapper;
using DBconnection;
using GTIOpenXML;
using GTIMVC.Models;
using GTICommon.Message;
using GTIWF.Models.SignBox;
using DEBTModel.Models;
using System.Transactions;
using GTIWF;
using System.Data.SqlClient;

namespace DEBT.Models
{
    public class DEBT102000Repository : BaseRepository
    {
        //共用參數
       // MemoryStream ms;
        DEBT102000ViewModel model;
        GTIWF.Models.Flow.FlowRepository _repoFlow;
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="_filter"></param>
        /// <param name="ResultMessage"></param>
        /// <returns></returns>
        public DEBT102000ViewModel getGridViewData(DEBT102000ViewModel.Filter _filter, string SOEID, string UNAME, string LEVEL)
        {
            model = new DEBT102000ViewModel();
            strSQL = "UDEBT_102000_Q00_SP";

            try
            {
                Connect(ref conCOGDB2);

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = _filter.F_ACCTNMBR,
                    @SYS_SOEID = SOEID,
                    @SYS_NAME = UNAME,
                    @SYS_LEVEL = LEVEL
                }, commandType: CommandType.StoredProcedure, commandTimeout: 600);

                model.msg = result.Read<MessageStatus>().FirstOrDefault();
                model.filter = _filter;
                model.filter.IS_FLOW = result.Read<Boolean>().FirstOrDefault();
                if (model.msg.Status)
                {
                    model.lstCALC_SETTING = result.Read<UDEBT_CALC_SETTING_FLOW>().ToList();
                    model.CALC_SETTING_FLOW = model.lstCALC_SETTING.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                model.msg.Status = false;
                model.msg.Message = ex.Message;
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }
            return model;
        }

        /// <summary>
        /// 設定日後債金條件
        /// </summary>
        /// <returns></returns>
        public DEBT102000ViewModel setDebtCondition(DEBT102000ViewModel.DeptSetting data, string SYS_PKEY, string SYS_PNAME)
        {
            model = new DEBT102000ViewModel();
            strSQL = "UDEBT_102000_I01_SP";

            try
            {
                Connect(ref conCOGDB2);
                data.DOCGUID = Guid.NewGuid();
                SqlTransaction trans = conCOGDB2.ConnObj.BeginTransaction();

                try
                {

                    var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                    {
                        @SYS_PKEY = SYS_PKEY,
                        @SYS_PNAME = SYS_PNAME,
                        @UI_DOCGUID = data.DOCGUID,
                        @UI_CHECKER_ID = data.NEW_CHECKER_ID,
                        @UI_CHECKER_NAME = data.NEW_CHECKER_NAME,
                        @UI_ACCTNMBR = data.ACCTNMBR,

                        @UI_WO_P = data.WO_P,
                        @UI_RATE = (data.RATE/100),
                        @UI_WO_I = data.WO_I,
                        @UI_WO_FEE = data.WO_FEE,
                        @UI_PROC_AMNT = data.PROC_AMNT,
                        @UI_EXEC_AMNT = data.EXEC_AMNT,

                        @UI_N_INT_DATE = data.N_INT_DATE,
                        @UI_BASE_DATE = data.BASE_DATE,
                        @UI_IF_XXWO = "N",
                        @UI_IF_PREWO = "N",
                        @UI_REMARK = data.REMARK

                    }, commandType: CommandType.StoredProcedure, commandTimeout: 600, transaction: trans);

                    model.msg = result.Read<MessageStatus>().FirstOrDefault();
                    model.filter.IS_FLOW = result.Read<bool>().FirstOrDefault();

                    if (model.msg.Status)
                    {
                        _repoFlow = new GTIWF.Models.Flow.FlowRepository(ref conCOGDB2, trans);
                        GTIWF.Models.Flow.NewFlowModel flowDataModel = new GTIWF.Models.Flow.NewFlowModel();

                        flowDataModel.ApplicantID = SYS_PKEY;
                        flowDataModel.ApplicantFUC = "";
                        flowDataModel.CreateID = SYS_PKEY;
                        flowDataModel.MessageGV = "設定日後債金計算條件";
                        flowDataModel.SignerID = data.NEW_CHECKER_ID;
                        flowDataModel.SignerFUC = "";
                        flowDataModel.DocGuid = data.DOCGUID;
                        flowDataModel.FlowID = "UDEBT_CALC_SETTING";

                        if (!_repoFlow.SetNewEditDoc(flowDataModel))
                        {
                            throw new Exception(_repoFlow.ErrorMsg);
                        }
                    }
                    else
                    {
                        throw new Exception(model.msg.Message);
                    }
                    trans.Commit();
                }
                catch
                {
                    trans.Rollback();
                    throw;
                }
            }

            catch (Exception ex)
            {
                model.msg.Status = false;
                model.msg.Message = ex.Message;
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }
            return model;
        }

        /// <summary>
        /// 債金計算
        /// </summary>
        /// <returns></returns>
        public DEBT102000ViewModel debtCalculation(UDEBT_CALC_SETTING_TEMP data, string templatePath, string exportPath, string fileName)
        {
            model = new DEBT102000ViewModel();
            strSQL = "UDEBT_102000_I02_SP";

            try
            {
                Connect(ref conCOGDB2);

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_ACCTNMBR = data.ACCTNMBR,
                    @UI_BASE_DATE = data.BASE_DATE,
                    @UI_BUSINESS = data.BUSINESS,
                    @UI_CREATEDBYID = data.CREATEDBYID,
                    @UI_CREATEDBYNAME = data.CREATEDBYNAME,
                    @UI_CREATEDDT = data.CREATEDDT,
                    @UI_CUSTID = data.CUSTID,
                    @UI_CUSTNAME = data.CUSTNAME,
                    @UI_DOCGUID = data.DOCGUID,
                    @UI_EXEC_AMNT = data.EXEC_AMNT,
                    @UI_IF_ECMS = data.IF_ECMS,
                    @UI_IF_PREWO = data.IF_PREWO,
                    @UI_IF_RECORD = data.IF_RECORD,
                    @UI_IF_XXWO = data.IF_XXWO,
                    @UI_LATE_CHRGE = data.LATE_CHRGE,
                    @UI_LEGAL_FEE = data.LEGAL_FEE,
                    @UI_LOCATION = data.LOCATION,
                    @UI_MBRZP_FEE = data.MBRZP_FEE,
                    @UI_N_INT_DATE = data.N_INT_DATE,
                    @UI_PROC_AMNT = data.PROC_AMNT,
                    @UI_RATE = (data.RATE / 100),
                    @UI_REMARK = data.REMARK,
                    @UI_SEQNO = data.SEQNO,
                    @UI_SERV_CHRGE = data.SERV_CHRGE,
                    @UI_SOURCE_AP = data.SOURCE_AP,
                    @UI_TABLENAME = data.TABLENAME,
                    @UI_WO_FEE = data.WO_FEE,
                    @UI_WO_I = data.WO_I,
                    @UI_WO_P = data.WO_P,
                    @UI_WODATE = data.WODATE,
                    @UI_CUT_DATE = data.CUT_DATE,
                    @UI_SCREEN_D = data.SCREEN_D,
                    @UI_CLOSE_D = data.CLOSE_D
                }, commandType: CommandType.StoredProcedure, commandTimeout: 600);

                model.msg = result.Read<MessageStatus>().FirstOrDefault();
                model.filter.IS_FLOW = result.Read<bool>().FirstOrDefault();
                //model.lstEXCEL_REPORT = result.Read<UDEBT_OUTPUT>().ToList();
                if (!model.msg.Status)
                {
                    throw new Exception(model.msg.Message);
                }

                strSQL = "UDEBT_CALC_DEBT_SP";
                ResultMessage = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                {
                    @ACCTNMBR = data.ACCTNMBR,
                    @CAL_TYPE = "DEBT AP",
                    @SOEID = data.CREATEDBYID,
                    @CUTDATE = data.CUT_DATE
                }, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();

                if (ResultMessage != null && ResultMessage.Status)
                {
                    strSQL = "SELECT *,dbo.HIDEPI_FN(ACCTNMBR) AS ACCTNMBR_DISP,dbo.HIDEPI_FN(CARDNMBR) AS CARDNMBR_DISP,dbo.HIDEPI2_FN(CUST_NAME) AS CUST_NAME_DISP FROM [COGDB2].[dbo].[UDEBT_OUTPUT] WHERE CARDNMBR = @ACCTNMBR AND [CREATORID] = @SOEID ORDER BY POST_D";
                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@ACCTNMBR", data.ACCTNMBR));
                    conCOGDB2.ParaColl.Add(new System.Data.SqlClient.SqlParameter("@SOEID", data.CREATEDBYID));
                    DataTable dt = conCOGDB2.Query(strSQL);


                    if (dt == null && !string.IsNullOrWhiteSpace(conCOGDB2.ErrorMessage))
                    {
                        throw (new Exception(conCOGDB2.ErrorMessage));
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        throw (new Exception("無債金計算結果可匯出"));
                    }
                    else
                    {


                        string strFileName = dt.Rows[0]["FILENAME"].ToString();
                        if (strFileName.ToUpper().IndexOf(".XLS") < 10)
                            strFileName = string.Format("{0}.xls", strFileName);

                        ResultMessage.Message = dt.Rows[0]["MESSAGE_TEXT"].ToString();
                        DEBTExcelRepository execlRepo = new DEBTExcelRepository();
                        if (execlRepo.ExportTemplateExcel(dt, Path.Combine(templatePath, fileName), System.IO.Path.Combine(exportPath, strFileName)))
                        {
                            //ResultMessage.File = new List<URLFile>();
                            //ResultMessage.File.Add(new URLFile { title = dt.Rows[0]["FILENAME"].ToString(), url = string.Format("~/File/Download?folder={0}&filename={1}", "DEBT", strFileName) });
                            string[] exportFiles = new string[1] { System.IO.Path.Combine(exportPath, strFileName) };
                            ZipCompress(null, exportFiles, data.CREATEDBYID);
                        }
                    }

                }
                model.msg = ResultMessage;
            }
            catch (Exception ex)
            {
                model.msg.Status = false;
                model.msg.Message = ex.Message;
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }
            return model;
        }

        /// <summary>
        /// Checker 名單
        /// </summary>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public List<SelectListItem> getCheckerList(string SOEID)
        {
            List<SelectListItem> lstItem = new List<SelectListItem>();
            lstItem = SignBoxRepository.getCheckerList(SOEID, ref conCOGDB2);

            return lstItem;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DOCGUID"></param>
        /// <param name="SOEID"></param>
        /// <returns></returns>
        public DEBT102000ViewModel.R0_ViewData queryFlowData(string DOCGUID, string SOEID)
        {
            model = new DEBT102000ViewModel();
            strSQL = "UDEBT_102000_Q01_SP";

            try
            {
                Connect(ref conCOGDB2);

                var result = conCOGDB2.ConnObj.QueryMultiple(strSQL, new
                {
                    @UI_DOCGUID = DOCGUID
                }
                , commandType: System.Data.CommandType.StoredProcedure);

                model.msg = result.Read<MessageStatus>().FirstOrDefault();
                model.flowData.beforeData = result.Read<UDEBT_CALC_SETTING>().FirstOrDefault();
                //Pre-write case 在第一次新增時,不會有before Data
                if (model.flowData.beforeData == null)
                    model.flowData.beforeData = new UDEBT_CALC_SETTING();
                model.flowData.afterData = result.Read<UDEBT_CALC_SETTING>().FirstOrDefault();

                model.flowData.DocGuid = model.flowData.afterData.DOCGUID.ToString();

                model.flowData.ddlChecker = new SelectList(GTIWF.Models.SignBox.SignBoxRepository.getCheckerList(SOEID, ref conCOGDB2),"Value","Text",model.flowData.afterData.CHECKER_ID);

                model.msg = new MessageStatus
                {
                    Status = true,
                    Message = ""
                };

            }
            catch (Exception ex)
            {

                model.msg = new MessageStatus
                {
                    Status = false,
                    Message = string.Format("Models error:{0}", ex.Message)
                };
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }

            return model.flowData;
        }

        #region Flow 
        public MessageStatus F_UDEBT_REASSIGN_CHECKER(string DOCGUID)
        {
            model = new DEBT102000ViewModel();

            strSQL = "F_UDEBT_REASSIGN_CHECKER_SP";

            try
            {
                Connect(ref conCOGDB2);

                model.msg = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                {
                    @DOCGUID = DOCGUID
                }
                , commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
            }
            catch (Exception ex)
            {

                model.msg = new MessageStatus
                {
                    Status = false,
                    Message = string.Format("Models error:{0}", ex.Message)
                };
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }

            return model.msg;
        }

        public MessageStatus F_UDEBT_APPROVE(string DOCGUID)
        {
            model = new DEBT102000ViewModel();
            strSQL = "F_UDEBT_APPROVE_SP";

            try
            {
                Connect(ref conCOGDB2);

                model.msg = conCOGDB2.ConnObj.Query<MessageStatus>(strSQL, new
                {
                    @DOCGUID = DOCGUID
                }
                , commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();

            }
            catch (Exception ex)
            {

                model.msg = new MessageStatus
                {
                    Status = false,
                    Message = string.Format("Models error:{0}", ex.Message)
                };
            }
            finally
            {
                Disconnect(ref conCOGDB2);
            }

            return model.msg;
        }
        #endregion
       
    }
}
