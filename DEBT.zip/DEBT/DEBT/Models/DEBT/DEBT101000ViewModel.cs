﻿using GTICommon.Control;
using GTICommon.Message;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GridMvc;


namespace DEBT.Models
{
    public class DEBT101000ViewModel
    {
        public Filter filter { get; set; }

        public DEBTType debtType { get; set; }

        public T1_DATA Data1 { get; set; }

        public T2_DATA Data2 { get; set; }

        public T3_DATA Data3 { get; set; }

        public List<T1_Grid> Grid1 { get; set; }

        public List<T2_Grid> Grid2 { get; set; }

        public List<T3_Grid> Grid3 { get; set; }

        public List<UIControl> Controls { get; set; }

       // private DEBT101000Repository _repo;

        public string TempMsg { get; set; }

        public class Filter
        {
            [DisplayName("帳號/卡號")]
            public string F_ACCTNMBR { get; set; }

            //背端隱藏使用，避免搜尋後變更卡號。
            public string H_ACCTNMBR { get; set; }

            [DisplayName("債金計算截止日")]
            public DateTime? F_CUTDATE { get; set; }
        }

        /// <summary>
        /// 對外債金計算 - 人工設定 - 1
        /// </summary>
        public class T1_DATA
        {
            [DisplayName("計算基準日")]
            public string T1_BASE_DATE { get; set; }

            [DisplayName("Write off INT")]
            public string T1_INT_AMNT { get; set; }

            [DisplayName("Write off Fee")]
            public string T1_FEE_AMNT { get; set; }

            [DisplayName("執行費")]
            public string T1_EXEC_AMNT { get; set; }

            [DisplayName("程序/裁判費")]
            public string T1_PROC_AMNT { get; set; }

            [DisplayName("XXWO Account")]
            public string T1_IF_XXWO { get; set; }

            [DisplayName("Pre-WO BP Account")]
            public string T1_IF_PREWO { get; set; }

            [DisplayName("備註")]
            public string T1_REMARK { get; set; }

            [DisplayName("更新人員")]
            public string T1_UPDATE_P { get; set; }

            [DisplayName("更新日期")]
            public string T1_UPDATE_T { get; set; }

            //當SOURCE欄位為BADRP、IDRP時，畫面上顯示「DRP ACCOUNT」
            public string T1_SOURCE { get; set; }

            //IF_RECORD 判斷按鈕「設定為日後債金計算條件」，「取消設定為日後債金計算條件」Enable or Disable
            public string T1_IF_RECORD { get; set; }

            public bool T1_IS_ECMS { get; set; }
        }

        /// <summary>
        /// 對外債金計算 - 人工設定 - 2
        /// </summary>
        public class T2_DATA
        {
            [DisplayName("本金")]
            public string T2_PRI_AMNT { get; set; }

            [DisplayName("利率%")]
            public string T2_APR { get; set; }

            [DisplayName("帳單年月 YYMM")]
            public string T2_STMT_YM { get; set; }

            [DisplayName("產品種類")]
            public string T2_BAL_TYPE { get; set; }

            [DisplayName("起息日")]
            public string T2_N_INT_DATE { get; set; }

            public SelectList ddlT2_BAL_TYPE { get; set; }

            public T2_DATA()
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem { Value = "", Text = "" });
                list.Add(new SelectListItem { Value = "A", Text = "固定月違約金" });
                list.Add(new SelectListItem { Value = "B", Text = "兩段式違約金" });
                list.Add(new SelectListItem { Value = "C", Text = "違約金依利率計算" });
                list.Add(new SelectListItem { Value = "D", Text = "一次性違約金" });
                ddlT2_BAL_TYPE = new SelectList(list, "Value", "Text", T2_BAL_TYPE);
            }
        }

        /// <summary>
        /// 對外債金計算 - 系統設定
        /// </summary>
        public class T3_DATA
        {
            [DisplayName("W/O本金")]
            public string T3_WO_P { get; set; }

            [DisplayName("W/O利息")]
            public string T3_WO_I { get; set; }

            [DisplayName("計息基準日")]
            public string T3_BASE_DATE { get; set; }

            [DisplayName("W/O法務費")]
            public string T3_LEGAL_FEE { get; set; }

            [DisplayName("W/O違約金")]
            public string T3_LATE_FEE { get; set; }

            [DisplayName("利率%")]
            public string T3_RATE { get; set; }

            [DisplayName("月付金")]
            public string T3_INSTALMENT { get; set; }

            //[DisplayName("XXWO Account")]
            //public string T3_IF_XXWO { get; set; }

            //[DisplayName("Pre-WO BP Account")]
            //public string T3_IF_PREWO { get; set; }
        }

        public class T1_Grid : UDEBT_CALDEBT_MINPUT
        {

        }

        public class T2_Grid : UDEBT_CALDEBT_ALS
        {

        }

        public class T3_Grid //: UDEBT_CALDEBT_MINPUT
        {
            [DisplayName("W/O本金")]
            public decimal WO_P { get; set; }

            [DisplayName("W/O利息")]
            public decimal WO_I { get; set; }

            [DisplayName("BASE_DATE")]
            public string BASE_DATE { get; set; }

            [DisplayName("起息日")]
            public string N_INT_DATE { get; set; }

            [DisplayName("W/O法務費")]
            public decimal LEGAL_FEE { get; set; }

            [DisplayName("W/O違約金")]
            public decimal LATE_FEE { get; set; }

            [DisplayName("利率%")]
            public decimal RATE { get; set; }

            [DisplayName("月付金")]
            public decimal INSTALMENT { get; set; }

            [DisplayName("XXWO Account")]
            public string IF_XXWO { get; set; }

            [DisplayName("Pre-WO BP Account")]
            public string IF_PREWO { get; set; }

            [DisplayName("帳單年月")]
            public string STMT_YM { get; set; }

            [DisplayName("產品種類")]
            public string BAL_TYPE { get; set; }
        }

        /// <summary>
        /// for json return message and controls
        /// </summary>
        public class MessageControl
        {
            public MessageStatus ms { get; set; }

            public List<UIControl> controls { get; set; }

            public Confirm cf { get; set; }

            public MessageControl()
            {
                ms = new MessageStatus();
                controls = new List<UIControl>();
                cf = new Confirm();
            }
        }

        public DEBT101000ViewModel()
        {
            filter = new Filter();
            Data1 = new T1_DATA();
            Data2 = new T2_DATA();
            Data3 = new T3_DATA();
            Grid1 = new List<T1_Grid>();
            Grid2 = new List<T2_Grid>();
            Grid3 = new List<T3_Grid>();
            Controls = new List<UIControl>();
        }

        public DEBT101000ViewModel(Filter _filter)
        {
            filter = _filter;
            Data1 = new T1_DATA();
            Data2 = new T2_DATA();
            Data3 = new T3_DATA();
            Grid1 = new List<T1_Grid>();
            Grid2 = new List<T2_Grid>();
            Grid3 = new List<T3_Grid>();
            Controls = new List<UIControl>();
        }

        public enum DEBTType
        {
            EMPTY = 0,
            ALS = 1,
            ECS = 2
        }

        public class T2_DELETE
        {
            public string SOURCE { get; set; }
            public string ACCTNMBR { get; set; }
            public string STMT_YM { get; set; }
            public string APR { get; set; }
            public string BAL_TYPE { get; set; }
        }

        public class UDEBT_CALDEBT_ALS
        {
            [DisplayName("帳號/卡號")]
            public string ACCTNMBR { get; set; }
            public string CUSTID { get; set; }
            public string NAME { get; set; }
            public string LOCATION { get; set; }
            public string BUSINESS { get; set; }
            public string PRODTYPE { get; set; }
            public string ACCTTYPE { get; set; }
            public string FINE_TYPE { get; set; }
            public decimal? FINE_RATE { get; set; }
            public decimal? M_FINE_RATE { get; set; }
            public decimal? FINEAMT { get; set; }
            public decimal? M_FINEAMT { get; set; }
            public string M_FINE_TYPE { get; set; }
            public DateTime? FINE_DATE { get; set; }
            public DateTime? M_FINE_DATE { get; set; }
            public DateTime? WODATE { get; set; }

            [DisplayName("起息日")]
            public DateTime? N_INT_DATE { get; set; }

            [DisplayName("起息日")]
            public DateTime? M_N_INT_DATE { get; set; }

            public DateTime? BASE_DATE { get; set; }

            [DisplayName("計算基準日")]
            public DateTime? M_BASE_DATE { get; set; }
            public DateTime? PASTDUE_D { get; set; }

            [DisplayName("W/O本金")]
            public decimal? WO_P { get; set; }

            [DisplayName("本金")]
            public decimal? M_WO_P { get; set; }

            [DisplayName("W/O利息")]
            public decimal? WO_I { get; set; }

            [DisplayName("利息")]
            public decimal? M_WO_I { get; set; }

            [DisplayName("W/O法務費")]
            public decimal? LEGAL_FEE { get; set; }

            [DisplayName("W/O違約金")]
            public decimal? LATE_FEE { get; set; }

            [DisplayName("程序/裁判費")]
            public decimal? PROC_AMNT { get; set; }

            [DisplayName("執行費")]
            public decimal? EXEC_AMNT { get; set; }
            public decimal? RATE { get; set; }

            [DisplayName("利率%")]
            public decimal? M_RATE { get; set; }

            [DisplayName("月付金")]
            public decimal? INSTALMENT { get; set; }
            public decimal? M_INSTALMENT { get; set; }
            public decimal? DUE_AMT { get; set; }
            public decimal? M_DUE_AMT { get; set; }
            public DateTime? CLOSE_D { get; set; }
            public DateTime? SCREEN_D { get; set; }
            public string IF_RECORD { get; set; }
            public string IF_XXWO { get; set; }
            public string IF_PREWO { get; set; }
            public string RECORD_P { get; set; }
            public DateTime? RECORD_T { get; set; }

            [DisplayName("備註")]
            public string REMARK { get; set; }

            [DisplayName("更新人員")]
            public string UPDATE_P { get; set; }

            [DisplayName("更新日期")]
            public DateTime? UPDATE_T { get; set; }
            public string SOURCE { get; set; }
        }

        public class UDEBT_CALDEBT_MINPUT
        {
            public string ACCTNMBR { get; set; }

            [DisplayName("帳單年月 YYYYMM")]
            public string STMT_YM { get; set; }

            [DisplayName("產品種類")]
            public string BAL_TYPE { get; set; }

            [DisplayName("利率%")]
            public decimal APR { get; set; }
            public string FINE_TYPE { get; set; }
            public DateTime? FINE_DATE { get; set; }

            /// <summary>
            /// FoxPro欄位名稱：INT_AMNT 及 FEE_AMNT 及 PRI_AMNT
            /// </summary>
            public decimal? AMOUNT { get; set; }
            public decimal? EXEC_AMNT { get; set; }
            public decimal? PROC_AMNT { get; set; }

            [DisplayName("計息基準日")]
            public DateTime? BASE_DATE { get; set; }

            [DisplayName("起息日")]
            public DateTime? N_INT_DATE { get; set; }

            public string IF_RECORD { get; set; }
            public decimal? FINE_AMT { get; set; }
            public decimal? FINE_RATE { get; set; }
            public decimal? FINERATE_A { get; set; }
            public decimal? FINERATE_B { get; set; }
            public decimal? FINE_AMT2 { get; set; }

            [DisplayName("Pre-WO BP Account")]
            public string IF_PREWO { get; set; }
            public string IF_RECORD_P { get; set; }
            public DateTime? IF_RECORD_T { get; set; }
            public string REMARK { get; set; }
            public string UPDATE_P { get; set; }
            public DateTime? UPDATE_T { get; set; }
            public string SOURCE { get; set; }

            public string TAG { get; set; }
        }

    }
}