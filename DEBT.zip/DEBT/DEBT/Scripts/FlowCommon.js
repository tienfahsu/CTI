﻿$(function () {
    window.onunload = function (e) {
        opener.CallParentfunction();
    };  

});
function DocSend() {
    $.ajax({
        url: Home + 'GTIWF/DocSend', //defined at ~/Views/Shared/_DocumentLayout.cshtml
        type: "post",
        data: $('#DocForm :input').serialize(),
        async: false,
        cache: false,
        success: function (data) {
            if (typeof (data) !== 'undefined' && typeof (data) == 'object' && data.Status === false) {
                alert(data.Message);

            } else if (typeof (data) == 'object' && data.Status === true) {
                
                if (data.Message != "") {
                    alert(data.Message);
                }
                window.close();
            }
        },
        error: function (xhr, status, text) {
            alert("Flow Error : " + text);
        },
        complete: function () {
            //即使Query沒有這個帳號，仍把ACCTNMBR設定為此帳號
            $('#ACCTNMBR').val($('#F_ACCTNMBR').prop('value'));

        }
    });
}