﻿$.Message = {
    _MessageCategory: '',
    _MessageType: '',
    _MessageSubject: '',
    _MessageCode: '',
    _Message: '',
    _Javascript: '',
    _MessageArray: new Array(),
    _width: '',
    _height: '',
    _isTW: true,
    _ContainerID: 'divMessageContainer',
    _Callback: null,
    _CreateMessageArray: function (MsgArray) {
        this._MessageArray = MsgArray;
        this._MessageCategory = MsgArray[0];
        this._MessageType = MsgArray[1];
        this._MessageSubject = MsgArray[2];
        this._MessageCode = MsgArray[3];
        this._Message = MsgArray[4];
        this._Javascript = MsgArray[5];
        this._Callback = null;
    },
    alert: function (option) {
        $("#" + this._ContainerID).modal(option);
    },
    init: function (option) {
        var blFlag = true;
        if (typeof (option.MsgArray) == "object" && option.MsgArray.length == 6) {
            this._CreateMessageArray(option.MsgArray);
        }
        else {
            if (typeof (option) == "string") {
                var customMessage = { MsgArray: ["01", "I", "訊息", "000000", option, ""] };
                this._CreateMessageArray(customMessage.MsgArray);
            }
            else {
                var customMessage = { MsgArray: ["01", "D", "訊息", "000000", 'option 格式不符合', ""] };
                this._CreateMessageArray(customMessage.MsgArray);
            }
        }

        if (typeof (option.ContainerID) == "string")
            this._ContainerID = option.ContainerID;

        if (typeof (option.callback) == "function") {
            this._Callback = option.callback;
        }
        return blFlag;
    },
    initcode: function (option) {

    },
    buildButtonHTML: function (text) {
        var button = $("<button />").attr({
            type: "button",
            'data-dismiss': 'modal',
            'aria-hidden': 'true'
        }).addClass("close").text(text);
        return button[0].outerHTML;
    },
    buildMessageHTML: function (text) {
        var ul = $("<ul />");
        //var li = $("<li />").addClass("text-error").text(text);
        var li = $("<li />").addClass("text-error");
        text = text == null ? '' : text;
        if (text.indexOf('\n') >= 0) {
            var pre = $("<pre />").text(text);
            pre.appendTo(li);
        }
        else
            li.text(text);
        li.appendTo(ul);

        return ul[0].outerHTML;
    },
    buidMessageModal: function () {
        var divModal = $("#" + this._ContainerID).on('hide.bs.modal', function () {
            if ($(this).find("#btnMsgJavascript").length > 0) {
                $(this).find("#btnMsgJavascript").click();
                $(this).find("#btnMsgJavascript").remove();
            }
        });

        var divDialog = $("<div />").addClass("modal-dialog").css("width", "600px");
        var divContent = $("<div />").addClass("modal-content");
        var divHeader = $("<div />").addClass("modal-header");
        var divBody = $("<div />").addClass("modal-body");
        var divFooter = $("<div />").addClass("modal-footer");
        var txtSure = this._isTW ? "確定" : "Close";
        switch (this._MessageType.toUpperCase()) {
            case "I":
                divHeader.addClass("alert-info");
                break;
            case "S":
                divHeader.addClass("alert-success");
                break;
            case "W":
                divHeader.addClass("alert-warning");
                break;
            case "E":
            case "D":
                divHeader.addClass("alert-danger");
                break;
            default:
                divHeader.addClass("alert-info");
                break;
        }

        var button = this.buildButtonHTML("x");
        var bodyUL = this.buildMessageHTML(this._Message);
        divHeader.html(button + "<h4 class=\"modal-title\">" + this._MessageSubject + "</h4>");
        divBody.html(bodyUL);
        if (this._Javascript != "") {
            var tempJS = $("<input />").attr({ id: "btnMsgJavascript", onclick: this._Javascript }).addClass("hide");
            divFooter.html("<button type=\"button\" id=\"btnMessageOK\" class=\"btn btn-default\" data-dismiss=\"modal\">" + txtSure + "</button>" + tempJS[0].outerHTML);
        }
        else
            divFooter.html("<button type=\"button\" id=\"btnMessageOK\" class=\"btn btn-default\" data-dismiss=\"modal\">" + txtSure + "</button>");

        divContent.html(divHeader[0].outerHTML + "\r\n" + divBody[0].outerHTML + "\r\n" + divFooter[0].outerHTML + "\r\n");
        divDialog.html(divContent[0].outerHTML);
        divModal.html(divDialog[0].outerHTML);

        this.buildListen(this);
    },
    buildListen: function (msgbox) {
        $("#" + msgbox._ContainerID).find("#btnMessageOK").off().click(function () {

            if (typeof (msgbox._Callback) == 'function') {
                msgbox._Callback(msgbox);
                //$("#" + msgbox._ContainerID).modal('hide');
            }
            else
                $("#" + msgbox._ContainerID).modal('hide');

        });
    },
    checkcontent: function () {
        if ($("#" + this._ContainerID).length > 0) {
            $("#" + this._ContainerID).remove("");
        }
        $("<div />").attr("id", this._ContainerID).addClass("modal fade").appendTo("body");
    },
    Open: function (option) {
        if (!this.init(option))
            alert(this._Message);

        this.checkcontent();
        this.buidMessageModal();
        this.alert({ show: true, backdrop: 'static' });
    },
    OpenCode: function (msgtype, msgcode, isTW) {
        var result;
        result = this.CodeRequest(msgtype, msgcode, isTW);

        this._isTW = isTW;
        this.Open(result);
    },
    OpenChtCode: function (option) {
        var result, blFlag;
        var MsgType, MsgCode
        if (typeof (option.MsgArray) == "object" && option.MsgArray.length == 2) {
            MsgType = option.MsgArray[0];
            MsgCode = option.MsgArray[1];
            blFlag = true;
        }
        else {
            if (typeof (option) == "array" && option.length == 2) {
                MsgType = option[0];
                MsgCode = option[1];
                blFlag = true;
            }
            else {
                result = { MsgArray: ["01", "D", "訊息", "000000", 'opencode 參數格式不符合', ""] };
                blFlag = false;
            }
        }

        if (blFlag) {
            result = this.CodeRequest(MsgType, MsgCode, true);
        }

        if (typeof (option.callback) == 'function') {
            result.callback = option.callback;
        }

        this.Open(result);
    },
    OpenEngCode: function (option) {
        var result, blFlag;
        var MsgType, MsgCode
        if (typeof (option.MsgArray) == "object" && option.MsgArray.length == 2) {
            MsgType = option.MsgArray[0];
            MsgCode = option.MsgArray[1];
            blFlag = true;
        }
        else {
            if (typeof (option) == "array" && option.length == 2) {
                MsgType = option[0];
                MsgCode = option[1];
                blFlag = true;
            }
            else {
                result = { MsgArray: ["01", "D", "訊息", "000000", 'opencode 參數格式不符合', ""] };
                blFlag = false;
            }
        }

        if (blFlag) {
            result = this.CodeRequest(MsgType, MsgCode, false);
        }

        if (typeof (option.callback) == 'function') {
            result.callback = option.callback;
        }
        this._isTW = false;
        this.Open(result);
    },
    CodeRequest: function (msgtype, msgcode, isTW) {
        var result;
        $.ajax({
            url: URLForMessageCode,
            type: "POST",
            data: { MsgCategory: msgtype, MsgCode: msgcode, isTW: isTW },
            async: false,
            cache: false,
            success: function (data) {
                if (typeof (data) != 'undefined' && data.length == 6) {
                    result = { MsgArray: data };
                }
                else {
                    result = { MsgArray: ["01", "D", "訊息", "000000", 'Request 回傳格式不符', ""] };
                }
            }
        });
        return result;
    }
};


$.Confirm = function (option, fnOk, fnCancel) {
    var _MessageType = 'I',
        _MessageSubject = '',
        _Message = '',
        _width = '',
        _height = '',
        _Cancel = null,
        _Confirm = null,
        _ContainerID = 'divConfirmContainer',
        _ErrorMsg = {},
        _isTW = true,
        _Result = false,
        _cfBtn = '確定',
        alert = function (modeloption) {
            $("#" + _ContainerID).modal(modeloption);
        },
        init = function () {
            var blFlag = true;
            reset();
            if (typeof (option) === "string") {
                option = {
                    MsgType: "I", MsgSubject: "確認訊息", Message: option, ContainerID: "divConfirmContainer",
                    isTW: true
                };
            }
            if (typeof (option.MsgType) === "string")
                _MessageType = option.MsgType;

            if (typeof (option.MsgSubject) === "string")
                _MessageSubject = option.MsgSubject;

            if (typeof (option.Message) === "string")
                _Message = option.Message;

            if (typeof (option.ContainerID) === "string")
                _ContainerID = option.ContainerID;

            if (typeof (option.width) === "string")
                _width = option.width;

            if (typeof (option.height) === "string")
                _height = option.height;

            if (typeof (option.isTW) === "boolean")
                _isTW = option.isTW;

            if (typeof (option.cfBtn) === "string") {
                _cfBtn = option.cfBtn;
            }

            if (typeof (fnOk) === "function") {
                _Confirm = fnOk;
            }
            else {
                _ErrorMsg = { MsgArray: ["01", "D", "訊息", "000000", '查無 Confirm function', ""] };
                blFlag = false;
            }

            if (typeof (fnCancel) === "function") {
                _Cancel = fnCancel;
            }

            return blFlag;
        },
        buildButtonHTML = function (text) {
            var button = $("<button />").attr({
                type: "button",
                'data-dismiss': 'modal',
                'aria-hidden': 'true'
            }).addClass("close").text(text);
            return button[0].outerHTML;
        },
        buildMessageHTML = function (text) {
            if (text.indexOf('\r\n') >= 0 || text.indexOf('\n') >= 0) {
                var pre = $("<pre />").text(text);
                return pre[0].outerHTML;
            }
            else {
                var ul = $("<ul />");
                var li = $("<li />").addClass("text-error").text(text);
                li.appendTo(ul);
                return ul[0].outerHTML;
            }
        },
        buidMessageModal = function () {
            var divModal = $("#" + _ContainerID);
            var divDialog = $("<div />").addClass("modal-dialog");
            var divContent = $("<div />").addClass("modal-content");
            var divHeader = $("<div />").addClass("modal-header");
            var divBody = $("<div />").addClass("modal-body");
            var divFooter = $("<div />").addClass("modal-footer");
            var txtSure = _isTW ? _cfBtn : "Close";
            //區分標題 class
            switch (_MessageType.toUpperCase()) {
                case "I":
                    divHeader.addClass("alert-info");
                    break;
                case "S":
                    divHeader.addClass("alert-success");
                    break;
                case "W":
                    divHeader.addClass("alert-warning");
                    break;
                case "E":
                case "D":
                    divHeader.addClass("alert-danger");
                    break;
                default:
                    divHeader.addClass("alert-info");
                    break;
            }
            //是否有自定義寬高
            if (_width)
                divDialog.css("width", _width);
            if (_height)
                divDialog.css("height", _height);

            var button = buildButtonHTML("x");
            var bodyUL = buildMessageHTML(_Message);
            divHeader.html(button + "<h4 class=\"modal-title\">" + _MessageSubject + "</h4>");
            divBody.html(bodyUL);
            var buttonCancel = "<button type=\"button\" class=\"btn\" data-dismiss=\"modal\">取消</button>";
            divFooter.html(buttonCancel + "<button type=\"button\" id=\"btnConfirmOK\" class=\"btn btn-default\" data-dismiss=\"modal\">" + txtSure + "</button>");

            divContent.html(divHeader[0].outerHTML + "\r\n" + divBody[0].outerHTML + "\r\n" + divFooter[0].outerHTML + "\r\n");
            divDialog.html(divContent[0].outerHTML);
            divModal.html(divDialog[0].outerHTML);

            buildListen();
        },
        //檢查是否有 container
        checkcontent = function () {
            if ($("#" + _ContainerID).length == 0) {
                $("#" + _ContainerID).remove();
            }

            $("<div />").attr("id", _ContainerID).addClass("modal fade").appendTo("body");
        },
        Open = function () {
            var blFlag = true;
            if (!init()) {
                blFlag = false;
                $.Message.Open(_ErrorMsg);
            }
            else {
                checkcontent();
                buidMessageModal();
                alert({ show: true, backdrop: 'static' });
            }

            return blFlag;
        },

        //建立 Handler
        buildListen = function () {
            $("#" + _ContainerID).find("#btnConfirmOK").off().click(function () {
                if (typeof (fnOk) == 'function') {
                    _Result = true;
                }
                else
                    $("#" + _ContainerID).modal('hide');
            });

            $("#" + _ContainerID).off().on('hide.bs.modal', function (event) {
                if (_Result && typeof (fnOk) == 'function') {
                    fnOk();
                } else if (!_Result && typeof (fnCancel) == 'function') {
                    fnCancel();
                }
            });
        },
        reset = function () {
            _MessageType = 'I';
            _MessageSubject = '確認訊息';
            _Message = '';
            _width = '';
            _height = '';
            _Cancel = null;
            _Confirm = null;
            _ContainerID = 'divConfirmContainer';
            _ErrorMsg = {};
            _isTW = true;
            _Result = false;
            _cfBtn = '確定';
        };

    Open();
};