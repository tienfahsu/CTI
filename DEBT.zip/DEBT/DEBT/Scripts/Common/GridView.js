﻿$(function () {
    $.ajaxSetup({ cache: false });

    if ($(".table-list").length > 0) {
        var bodyRows = $(".table-list tbody tr");
        if (bodyRows != null) {
            bodyRows.each(function () {
                var $tr = $(this);
                var strClassName = $tr.attr('class');
                $tr.mouseover(function () {
                    $tr.removeAttr('class');
                    $tr.addClass(strClassName + "hover");
                    if (OpenLink != false) {
                        $tr.css("cursor", "pointer");
                    }
                });
                $tr.mouseout(function () {
                    $tr.removeAttr('class');
                    $tr.addClass(strClassName);
                    if (OpenLink != false) {
                        $tr.css("cursor", "default");
                    }
                });
            });
        }
    }
    //20150904 新增
    PaginationIsFirstTime();
    resizeControlCenter();
});

function genPageSizeSelect() {
    var iMax = $(".pagination").length;
    $(".pagination").each(function (i) {
        var divID = "divPageSize_" + i;
        var ddl = $("<select />")
        //.attr("id", "PageSize_" + i)
            .attr("class", "PagerPageSize")
            .css({
                width: "170px"
            });
        if (i == 0) {
            $(ddl).attr("data-autopostback", "false")
            .attr("name", "PageSize");
        }

        $(ddl).unbind('change');
        $(ddl).bind('change', function () {
            var currentUrl = window.self.location.href;
            var selvalue = $(this).val();
            var ddls = $(".PagerPageSize").each(function () {
                $(this).val(selvalue);
                changePageSize(selvalue);
            });
        });

        var currentSize = QueryString("PageSize");

        if ($("#PageSize").length > 0 && $("#PageSize").val() != "") {
            currentSize = $("#PageSize").val();
        }

        if (typeof (currentSize) != 'undefined' && currentSize != '') {
            $(ddl).val(currentSize);
        }

        $("<option />", { value: 10, text: "Show 10 Records" }).appendTo(ddl);
        $("<option />", { value: 20, text: "Show 20 Records" }).appendTo(ddl);
        $("<option />", { value: 50, text: "Show 50 Records" }).appendTo(ddl);

        $(ddl).find("option").filter(function () {
            return $(this).val() == currentSize;
        }).attr("selected", true);

        var div = $("<div />")
            .css("float", "right")
            .attr("name", "divPageSize")
            .attr("id", divID)
            .appendTo($(".pagination")[i]);
        $(ddl).appendTo(div);
    });
}

function changePageSize(size) {
    var PSpattern = /PageSize=\d+/i;
    var Pagepattern = /page=\d+/i;
    var url = window.location.href;
    //if (url.indexOf("?") < 0) {
    //    url = url + "?";
    //}

    if (url.indexOf("?") > 0) {
        //切換回第一頁
        url = url.replace(Pagepattern, "page=" + 1);

        if (url.indexOf("PageSize") > 0) {
            url = url.replace(PSpattern, "PageSize=" + size);
        }
        else {
            url = url + "&PageSize=" + size;
        }
    }
    else {
        url = url + "?PageSize=" + size;
    }
    window.location.href = url;
}


function resizeControlCenter() {
    if (typeof (window.parent.ResizeIframe) == 'function') {
        window.parent.ResizeIframe();
    }
}

//20150904 新增
function PaginationIsFirstTime() {
    $(".pagination").parent().closest('form').submit(function () {
        $(this).find("#page").val("1");
    });

    $(".pagination").find("a").each(function () {
        var PSpattern = /(isFirstTime=)([a-z]+)?/ig;

        var url = $(this).attr("href");
        if (url.indexOf("isFirstTime") > 0) {
            url = url.replace(PSpattern, "isFirstTime=false");
        }
        else {
            url = url + "&isFirstTime=";
        }
        $(this).attr("href", url);

//        $(this).click(function (e) {
//            e.preventDefault();
//            url = $(this).attr("href");
//            
//            $("#isFirstTime").val("false");
//            $("#page").val(getHrefVars(url)["page"]);
//            $("#PageSize").val(getHrefVars(url)["PageSize"]);
//            $(this).parent().closest('form').submit();
//        });
    });
}

function getHrefVars(HrefURL) {
    var vars = [], hash;
    var hashes = HrefURL.slice(HrefURL.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}