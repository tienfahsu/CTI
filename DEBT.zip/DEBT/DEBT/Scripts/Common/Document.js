﻿var ControlCenterWindow, DocWindow;
DocWindow = this.window;

if (typeof (opener) != 'undefined' && typeof (opener.window) != "unknown") {
    if (opener.location.href.indexOf('iControlCenter') >= 0)
        ControlCenterWindow = opener.window;
    else
        ControlCenterWindow = null;
}
else
    ControlCenterWindow = null;

function closeWin() {
    if (ControlCenterWindow && ControlCenterWindow.document) {
        if ($("#btnRefreshDiv", opener.document).length == 1) {
            $("#btnRefreshDiv", opener.document).click();
        }
        refreshControlCenter();
    }
    else {
        if (opener && opener.window.document) {
            if ($("#btnRefreshDiv", opener.document).length == 1) {
                $("#btnRefreshDiv", opener.document).click();
            }
        }
        DocWindow.close();
    }
}

function openEdit() {
    var blFlag = false;
    var strMsg = '';
    var form = $("#DocForm");
    if (form.length == 0) {
        strMsg += '查無表單屬性 DocForm\n';
    }

    var controller = form.attr("controller");
    if (typeof (controller) == 'undefined') {
        strMsg += '查無表單屬性 controller\n';
    }

    var name = form.attr("name");
    if (typeof (name) == 'undefined') {
        strMsg += '查無表單屬性 name\n';
    }

    var seq = form.attr("seq");
    if (typeof (seq) == 'undefined') {
        strMsg += '查無表單屬性 seq\n';
    }

    if (typeof (Home) == 'undefined') {
        strMsg += 'DocumentLayout 未設定 Home 參數';
    }

    var newResult = name.replace(/\r\n/g, '').replace(/\n/g, '').replace(/\r/g, '');
    var regex = /(\w+)(R0)$/;
    var matches, output = [];
    var results = regex.exec(newResult);

    if (results) {
        name = results[1] + results[2].replace("R", "E");
    }
    else
        strMsg += "表單格式 name 不符合\n";


    if (strMsg != '') {
        alert(strMsg);
        return false;
    }
    else {
        var r = new Date().getTime();
        self.location.href = Home + controller + '/' + name + '/' + seq + '?r=' + r;
    }
}

function openRead() {
    var blFlag = false;
    var strMsg = '';
    var form = $("#DocForm");
    if (form.length == 0) {
        strMsg += '查無表單屬性 DocForm\n';
    }

    var controller = form.attr("controller");
    if (typeof (controller) == 'undefined') {
        strMsg += '查無表單屬性 controller\n';
    }

    var name = form.attr("name");
    if (typeof (name) == 'undefined') {
        strMsg += '查無表單屬性 name\n';
    }

    var seq = form.attr("seq");
    if (typeof (seq) == 'undefined') {
        strMsg += '查無表單屬性 seq\n';
    }

    if (typeof (Home) == 'undefined') {
        strMsg += 'DocumentLayout 未設定 Home 參數';
    }

    var newResult = name.replace(/\r\n/g, '').replace(/\n/g, '').replace(/\r/g, '');
    var regex = /(\w+)(A0|E0)$/;
    var matches, output = [];
    var results = regex.exec(newResult);

    if (results) {
        name = results[1] + results[2].replace("A", "R").replace("E", "R");
    }
    else
        strMsg += "表單格式 name 不符合\n";


    if (strMsg != '') {
        alert(strMsg);
        return false;
    }
    else {
        var r = new Date().getTime();
        self.location.href = Home + controller + '/' + name + '/' + seq + '?r=' + r;
    }
}

function refreshControlCenter() {
    if (ControlCenterWindow.document && $("#DocForm").length > 0) {
        $("#DocForm").submit();
    }

    DocWindow.close();
}