﻿function isDate(txtDate) {
    var currVal = txtDate;

    if (currVal == '') {
        return true;
    }
    var hasSymbol = currVal.indexOf('-') >= 0 || currVal.indexOf('/') >= 0;
    //Declare Regex
    var rxDatePattern = /^(\d{4})(\/|-)?(\d{1,2})(\/|-)?(\d{1,2})$/;
    if (hasSymbol) {
        rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/;
    }
    else {
        rxDatePattern = /^(\d{4})(\/|-)?(\d{2})(\/|-)?(\d{2})$/;
    }
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray == null) {
        return false;
    }

    //Checks for yyyy/mm/dd format.
    dtYear = dtArray[1];
    dtMonth = dtArray[3];
    dtDay = dtArray[5];

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
        return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap))
            return false;
    }
    return true;
}

// 重新整理畫面
function reloadSelfFunction(path, url, key) {
    path = path || "";
    url = url || "";
    key = key || "";

    if (path == "" || url == "" || key == "") {
        $("Body").append('<a id="reloadSelf" href="' + window.location.href + '" style="display: none"></a>');
    } else {
        $("Body").append('<a id="reloadSelf" href="' + path + url + "/" + key + '" style="display: none"></a>');
    }

    reloadSelf.click();
}


function reloadParentWindow() {
    var Iframe;
    if (window.dialogArguments) {
        //Iframe = $("#ifMainContent", window.dialogArguments.document);
        //Iframe.attr("src", $Iframe.attr("src"));
        //Iframe.load();
        $("#DocForm", window.dialogArguments.document).submit();
    } else if (window.opener) {
        Iframe = $("#ifMainContent", window.opener.document);
        Iframe.attr("src", Iframe.attr("src"));
        Iframe.load();
    }
}


function redirectParentWindow(url) {
    var Iframe;
    if (window.dialogArguments) {
        //        Iframe = $("#ifMainContent", window.dialogArguments.document);
        //        Iframe.attr("src", $Iframe.attr("src"));
        //        Iframe.load();
        $("#ifMainContent", window.dialogArguments.document).attr("src", url)
        // $("#DocForm", window.dialogArguments.document).submit();
    } else if (window.opener) {
        alert("1");
        Iframe = $("#ifMainContent", window.opener.document);
        Iframe.attr("src", Iframe.attr("src"));
        Iframe.load();
    }
}

function isEmail(strEmail) {
    //please input the test email to see is valid
    //var strEmail = “foxfirejack@gmail.com”;
 
    //Regular expression Testing
    var emailRule = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z]+$/;

    //validate ok or not
    return emailRule.test(strEmail);
}

$(document).ready(function () {
    var attrAjaxForm = $("form").attr("AjaxForm");
    if (attrAjaxForm == "true") {
        if ($("span.field-validation-error").html() != null) {
            $("span.field-validation-error").remove();
            $("div.validation-summary-errors").remove();
        }

        $("form").bind("form-pre-serialize", function () {
            if (window.DoSomethingBeforeAjaxFormSubmit) {
                DoSomethingBeforeAjaxFormSubmit();
            }
        });

        $('form').ajaxForm({
            success: function (data) {
                if (data[0] == "succeed") {  // Status
                    if (data[1] == "ShowMessage") {
                        alert(data[2]);

                        if (data[3] != undefined && data[3] != "") {
                            eval(data[3]);
                        } else {
                            reloadSelfFunction();
                        }
                    }
                    else if (data[1] == "RedirectToUrl") {
                        alert(data[2]);
                        if (window.dialogArguments != undefined) {
                            window.close();
                            window.dialogArguments.SeqNO = data[3]; // Key
                            window.dialogArguments.OpenDlg(data[4]); // RedirectToUrl
                        }
                        else {
                            reloadSelfFunction(path, data[4], data[3]);
                        }
                    }
                    else if (data[1] == "ParentRedirectToUrl") {
                        alert(data[2]);
                        $Iframe = $("#ifMainContent", window.dialogArguments.document);
                        if ($Iframe.length > 0) {
                            $Iframe.attr("src", data[4]);
                            $Iframe.load();
                        }
                        else if ($("#ifMainContent", window.parent.document).length > 0) {
                            $Iframe = $("#ifMainContent", window.parent.document);
                            $Iframe.attr("src", data[4]);
                            $Iframe.load();
                        }
                        else {
                            window.dialogArguments.location = data[4];

                        }
                        window.close();
                    }
                    else if (data[1] == "ShowMsgAndRedirectToUrl") {
                        alert(data[2]);
                        reloadSelfFunction(path, data[4], data[3]);
                    }
                }

                else if (data[0] == "Error") {
                    var ErrorMessage = "";
                    $.each(data, function (i, item) {
                        if (i == 0 || i == 1 || i == 2) return true;
                        if (item != undefined) {
                            ErrorMessage += item + "\n";
                        }
                    });
                    alert(ErrorMessage);
                    if (data[1] != undefined && data[1].toLowerCase() == "true") {
                        reloadSelfFunction();
                    }

                    if (data[2] != undefined && data[2] != "") {
                        eval(data[2]);
                    }
                }
            },
            error: function (request, status, errorThrown) {
                alert('AjaxForm Submit Error\r\n' + request.statusText + ":" + request.status + ' ' + errorThrown + "\r\n" + request.responseText);
            },
            beforeSubmit: function (formData, jqForm, options) {
                // formData is an array; here we use $.param to convert it to a string to display it 
                // but the form plugin does this for you automatically when it submits the data 
                var queryString = $.param(formData);

                // jqForm is a jQuery object encapsulating the form element.  To access the 
                // DOM element for the form do this: 
                // var formElement = jqForm[0]; 

                //            alert('About to submit: \n\n' + queryString);

                // here we could return false to prevent the form from being submitted; 
                // returning anything other than false will allow the form submit to continue 
                return true;
            }
        });
    }
});