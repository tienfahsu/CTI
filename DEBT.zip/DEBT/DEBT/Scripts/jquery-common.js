﻿
(function ($) {
    //依照類型，取的銀行名稱選單
    $.fn.GetBank = function () {
        if (typeof UrlForGetBankName === 'undefined') {
            alert('未設定變數 UrlForGetBankName');
        }
        else {
            return this.each(function () {
                $(this).bind("change", function () {
                    var source = $(this);
                    var container = $("#" + $(this).attr("containerID"));
                    var target = $("select[name='" + $(this).attr("target") + "']", container);
                    target.children().remove();
                    if (target.length > 0) {
                        $.ajax({
                            url: UrlForGetBankName,
                            type: 'post',
                            data: { strType: $(this).val() },
                            cache: false,
                            async: false,
                            success: function (data) {
                                for (var i = 0; i < data.length; i++) {
                                    target.append($("<option value='" + data[i].Value + "'>" + data[i].Text + "</option>"));
                                }
                            }
                        });
                    }
                    else {
                        alert('請通知PG於BankType選單中加入屬性 target & containerID(target 為 銀行名稱之下拉選單 name)');
                    }
                });
            });
        }
    };

    //若郵遞區號未選擇時，可針對地址欄位，反解析出郵遞區號
    $.fn.ZipInput = function () {
        return this.each(function () {
            $(this).bind('keyup change', function (e) {
                //var zipcode = $("#" + $(this).attr("ZipFN"), "#" + $(this).attr("containerID"));
                var zipcode = $("select[name='" + $(this).attr("ZipFN") + "']", "#" + $(this).attr("containerID"));
                if (zipcode.length > 0) {

                    if (zipcode.val() == '' && $(this).val().match(/(\D{3})?(\D+[縣市])(\D+?(市區|鎮區|鎮市|[鄉鎮市區]))/)) {
                        var compare = $(this).val();
                        var t = zipcode.find('option').filter(function () {
                            return $(this).text().match("^" + compare) || $(this).text().match(compare + "$");
                        }).val();
                        if (typeof t != 'undefined' && t != '') {
                            zipcode.val(t);
                        }
                    }
                }
                else {
                    alert('請通知PG於zipcode選單中加入屬性 ZipFN & containerID(ZipFN 為 郵遞區號名稱之下拉選單 name)')
                }
            });
        });
    };


    $.fn.OnlyNumber = function () {
        return this.each(function () {
            $(this).css("ime-mode", "disabled");
            $(this).bind('keydown', function (e) {
                // Allow: backspace, delete, tab, escape, enter and .
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                    (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
        });
    };

    $.fn.OnlyInt = function () {
        return this.each(function () {
            $(this).css("ime-mode", "disabled");
            $(this).bind('keydown', function (e) {
                // Allow: backspace, delete, tab, escape, enter
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                    (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
        });
    };
}(jQuery));

