﻿$(function () {
    //上傳檔案使用 1/3
    var options = {
        target: ' #output1 ',    //  target element(s) to be updated with server response     
        // beforeSubmit: showRequest,   //  pre-submit callback                     
        success: showResponse   //  post-submit callback     

        //  other available options:     
        // url:       url         // override for form's 'action' attribute     
        // type:      type        // 'get' or 'post', override for form's 'method' attribute     
        , dataType: 'json'        // 'xml', 'script', or 'json' (expected server response type)     
        // clearForm: true        // clear all form fields after successful submit     
        // resetForm: true        // reset the form after successful submit     

        //  $.ajax options can be used here too, for example:     
        // timeout:   3000     
    };

    //上傳檔案使用 2/3
    $("#btnCalc").click(function () {

        $("#btnImport").attr("disabled", true);
        $('#DocForm2').attr('enctype', 'multipart/form-data').get(0).encoding = 'multipart/form-data';
        $("#DocForm2").ajaxSubmit(options);
        blockMessage("請稍後.....");
    });
});

//上傳檔案使用 3/3
function showResponse(data) {

    if (!data.Status) {
        unBlock();
        showFileMessage(data.Message, data.File);
    }
    else {

        if (data.Status) {
            unBlock();
            showFileMessage(data.Message, data.File);
          // base64Zip(data);
        }
        else {
            unBlock();
            alert(data.Message);
            //unBlock();
        }
       // showFileMessage(data.Message, data.File);
//        ExportFromAjax(urlForUpload, "post", { DATE: '' }, "程式執行中......", "程式執行完畢");


    }
}
function base64Zip(data) {
    inputs = { base64zip: data.Message };
    ExportFromAjax(urlForBase64Zip, "post", inputs, "程式執行中........", "程式執行完畢");
    unBlock();
}
function showFileMessage(message, file) {

    if ($("#divMsgDialog").length == 0) {
        var modalDialog = $('<div/>').attr("id", "divMsgDialog");
        modalDialog.appendTo($("body"));

    }

    $("#divMsgDialog").html("<span style=\"font-size:10pt\">" + message + "</span>");

    if (file != null && typeof (file) == "object") {
        for (var i = 0; i < file.length; i++) {
            var TagA = $("<a style=\"font-size:10pt\"></a>").attr("href", file[i].url).text(file[i].title);
            $("#divMsgDialog").append("<br/>").append(TagA);
        }
    }

    $("#divMsgDialog").dialog(
        {
            title: "訊息",
            width: 550,
            height: 350,
            modal: true,
            buttons: {
                "Ok": function () {
                    $(this).dialog("close");

                } //function
            } //buttons
        });
}
