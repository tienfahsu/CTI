﻿
function bindButtonEvent()
{
     //提示
   $("#div_prompt").dialog({
       width: 550,
       height: 350,
       modal: true,
        autoOpen: false,
        buttons: {
            "確定": function () { $(this).dialog("close"); }        
        }
    });


    //GridView 上方新增按鈕
    $('#btnNew').click(function () {
        $('#PAYMENT_TEMP_TXAMT').val('');
        $("#div_ADDPAYMENT_NEW").dialog("open");

        return false;
    });
    

}

$(document).ready(function () {
   
   bindButtonEvent();
   $("#div_ADDPAYMENT_NEW").dialog({
        width: 550,
        height: 350,
        modal : true,
        autoOpen: false,
    });
    //新增繳款紀錄 取消btn
    $('#btnCancel_dlg').click(function () {
        if (confirm("是否要離開?") == true) {
            $('#PAYMENT_TEMP_TXDATE').val('');
            $('#PAYMENT_TEMP_TXAMT').val('0');
            $("#div_ADDPAYMENT_NEW").dialog("close");
        }
        else {
          
        }  
    });
   
    //送出
    $('#btnSubmit').click(function () {
        if (confirm("是否要送出?") == true) {
            Submit();
          
        }
        else {
           
        }
    });
    //取消
    $('#btnCancel').click(function () {
        if (confirm("是否要離開?") == true) {
            Exit();
        
        }
        else {
            
        }
        
    });
    //新增繳款btn
    $('#btnAdd').click(function () {
        var TXDATE = $('#PAYMENT_TEMP_TXDATE').val();
        var TXAMT = $('#PAYMENT_TEMP_TXAMT').val();
       
        if (confirm("是否要新增?") == true) {
            if (TXDATE == "" || TXDATE == null) {
                alert('請選擇日期!!')
            }
            else if ( TXAMT == null || TXAMT == "") {
                alert('金額不能為空白')
            }
            else {
                addPayment();              
                $('#div_ADDPAYMENT_NEW').dialog("close");
            
            }
        }
        else {
         
        }
      
    });
    //日期選擇器
    $("#PAYMENT_TEMP_TXDATE").datepicker({
        dateFormat: "yy/mm/dd",
        yearRange: "c-20:c+5",
        changeYear: true, //手動修改年
        changeMonth: true, //手動修改月
        showMonthAfterYear: true,
        showOtherMonths: true, //在本月中顯示其他月份
        selectOtherMonths: true, //可以在本月中選擇其他月份
        beforeShow: function () {
            setTimeout(function () {
                $('.ui-datepicker').css('z-index', 1200);
            }, 0);
        }
    });
    $(".grid-mvc").each(function () {
        $(".grid-mvc").gridmvc();
    });
   
    IS_ADJUST();
    IS_FLOW();
});
//他人正在進行繳款作業 關btn
function IS_FLOW()
{
    var IS_FLOW = $('#IS_FLOW').val();
    if (IS_FLOW == "True")
    {
        $('#btnSubmit').prop("disabled", true);
        $('#btnNew').prop("disabled", true);
        $('.grid-row  #btnDelete').prop("disabled", true);
        $("#div_prompt").dialog("open");
        $('#Cancel').hide();
    }
}
function IS_ADJUST()
{
    var IS_ADJUST = $('#IS_ADJUST').val();
    if (IS_ADJUST == "True")
    {
        $('#btnSubmit').prop("disabled", true);
        $('#btnNew').prop("disabled", true);
        $('.grid-row  #btnDelete').prop("disabled", true);
        $('.grid-row #Cancel').prop("disabled", true);
    }


}
//送出
function Submit()
{
    $.ajax({
        url: urlForSubmit,
        type: 'post',
        data: 
            {
                ACCTNMBR: $('#DisACCTNMBR').val(),
                Checker: $('#pFilter_CHECKER').val()
            },
        cache: false,
        success: function (MS) {
            if (typeof (MS) !== 'undefined') {

                if (MS.Status  && MS.Message !== "") {
                    alert(MS.Message);
                    self.close();
                }
                else  {
                    alert(MS.Message);
            }
           
                
            }
          
        },
        error: function (xhr, status, text) {
            alert("Query Error : " + text);
        }
    }).complete(function () {
       
        unBlock();
    });
}
    //取消
    function Exit() {
        $.ajax({
            url: urlForExit,
            type: 'post',
            data: {
                ACCTNMBR: $('#DisACCTNMBR').val(),
            },
            cache: false,
            success: function (MS) {
                if (typeof (MS) !== 'undefined') {

                    if (MS.Message !== "") {
                        alert(MS.Message);                        
                    }
                    if(MS.Status)  {
                        self.close();
                    }
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            
            unBlock();
        });
 
    }

    function refreshGrid()
    {
        $.ajax({
            url: urlForQueryTemp,
            type: 'get',
            data: {
                ACCTNMBR: $('#DisACCTNMBR').val()                
            },
            cache: false,
            success: function (data) {
                $("#TAB_DEBT103001").html(data);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
        
            bindButtonEvent();
            unBlock();
        });
    }
    //新增繳款
    function addPayment() {

        $.ajax({
            url: urlForaddPayment,
            type: 'post',
            data: {
                ACCTNMBR: $('#DisACCTNMBR').val(),
                TXDATE: $('#PAYMENT_TEMP_TXDATE').val(),
                TXAMT: $('#PAYMENT_TEMP_TXAMT').val()
            },
            cache: false,
            success: function (MS) {
                alert(MS.Message);
                refreshGrid()
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
        
            //location.reload();
            unBlock();
        });
 
    }
    //刪除
    function delPayment() {
        if (confirm("是否要刪除?") == true) {
            $.ajax({
                url: urlFordelPayment,
                type: 'post',
                data: {
                    ACCTNMBR: $('#DisACCTNMBR').val(),
                    SEQNO: $('#SEQNO').val()

                },
                cache: false,
                success: function (MS) {
                    alert(MS.Message);

                },
                error: function (xhr, status, text) {
                    alert("Query Error : " + text);
                }
            }).complete(function () {
                //location.reload();
                refreshGrid()
                unBlock();
            });
        }
        else {

        }
   
    }
    //Grid按鈕 抓值
    function catchVal(btn) {
        var row = $(btn).closest(".grid-row");
        if (row.length <= 0)
            return;
        var gridRow = {};
        row.find(".grid-cell").each(function () {
            var columnName = $(this).attr("data-name");
            if (columnName.length > 0)
                gridRow[columnName] = $(this).text();
        });

        pageGrids.DEBT103001.markRowSelected(row);

        for (var name in gridRow) {
            var fn = name;
            var el = $("[name='" + fn + "']");

            if (el.length > 0) {
                var tag = el[0].tagName;
                switch (tag) {
                    case "INPUT":
                        var type = el.attr("type").toUpperCase();
                        if (type == 'TEXT') {
                            $("input[name='" + fn + "']").val(gridRow[name]);
                       
                        }
                        else if (type === 'RADIO' || type === 'CHECKBOX') {
                            for (var i = 0; i < el.length; i++) {
                                if ($(el[i]).attr("value").toUpperCase() == gridRow[name].toUpperCase()) {
                                    $(el[i]).prop("checked", true);
                                }
                                else {
                                    $(el[i]).prop("checked", false);
                                }
                            }
                        }

                        break;
                    case "SELECT":
                        var t = $("select[name='" + fn + "']").children().filter(function () {
                            return $(this).val() == gridRow[name];
                        }).val();
                        $("select[name='" + fn + "']").val((typeof t == 'undefined' ? '' : t));

                        break;
                }
            }
        }

    }
    //取消異動
    function btCancel()
    {
        if (confirm("是否要取消資料?") == true) { 
            $.ajax({
                url: urlForCancel,
                type: 'post',
                data: {
                    ACCTNMBR: $('#DisACCTNMBR').val(),
                    LASTUPDATEDDT: $("#LASTUPDATEDDT").val(),
                    SEQNO: $('#SEQNO').val(),
                    ACTIONTYPE: $('#ACTIONTYPE').val()
                },
                cache: false,
                success: function (MS) {
                    alert(MS.Message);
          
                },
                error: function (xhr, status, text) {
                    alert("Query Error : " + text);
                    document.write(xhr.responseText);
                }
            }).complete(function () {
                //location.reload();
                refreshGrid()
                unBlock();
            });
        }
        else {

        }
    }
    //重新整理
    function Re()
    {
        $.ajax({
            url: urlForRe,
            type: 'post',
            data: {
                ACCTNMBR: $('#DisACCTNMBR').val(),
            },
            cache: false,
            success: function (MS) {
                if (typeof (MS) !== 'undefined') {

                    if (MS && MS.Message !== "") {
                        //  alert(MS.Message);
                    }
                }

            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            location.reload();
            unBlock();
        });
    }
