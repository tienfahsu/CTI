﻿$(document).ready(function () {

    $('#F_Variant').val($('#CHECKER_NAME').val());

    $('#CHECKER_NAME').change(function () {
        $('#DocButton #F_Variant').val($('#CHECKER_NAME').val());
        $('#DocForm #F_Variant').val($('#CHECKER_NAME').val());
    });

    $(':checkbox[readonly]').click(function () {
        return false;
    });
    
});

function ControlCheckerList() {
    if ($("#btnReSendTo").length == 0) {
        $("#trCHECKER").hide();
        $("#trNONCHECKER").show();
    }
    else {
        $("#trCHECKER").show();
        $("#trNONCHECKER").hide();
    }
}