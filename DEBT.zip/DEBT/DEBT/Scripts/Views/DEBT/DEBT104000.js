﻿$(document).ready(function () {
    MainScript();
});

function MainScript() {
    window.CallParentfunction = function () {
        $("#DocForm").submit();
    }
}

//function btnDetail_fn(btn) {
//    //將資料上傳至Controller
//    var tr = $(btn).closest('tr');
//    var SEQNO = tr.children().eq(0).text();
//}