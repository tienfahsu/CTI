﻿$(document).ready(function () {

    $('#F_Variant').val($('#pFilter_CHECKER').val());

    $('#pFilter_CHECKER').change(function () {
        $('#DocButton #F_Variant').val($('#pFilter_CHECKER').val());
        $('#DocForm #F_Variant').val($('#pFilter_CHECKER').val());
        //alert($('#pFilter_CHECKER').val());
    });

});
