﻿$(function () {
    $('#btnQuery').click(function () {
        $("#DocForm").submit();
    });
    window.CallParentfunction = function () {
        $("#btnQuery").click();
    }
});


