﻿
$(function () {
    var opt = {
        showMonthAfterYear: true,
        dateFormat: "yy/mm/dd"
    };
    $(".date").datepicker(opt);

    //當SOURCE欄位為BADRP、IDRP時，畫面上顯示「DRP ACCOUNT」。
    if ($("#T1_SOURCE").val() == "BADRP" || $("#T1_SOURCE").val() == "IDRP") {
        $("#dspDRP_ACCOUNT").show();
    }
    else {
        $("#dspDRP_ACCOUNT").hide();
    }

    //form submit
    $("#btnQuery").click(function () {
        $("#DocForm").submit();
    });

    //債金計算-人工設定
    $("#btnT1Calc").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForTCalc,
            type: 'post',
            data: {
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                CUTDATE: $("#F_CUTDATE").val(),
                CALTYPE: 'AP'

            },
            cache: false,
            success: function (data) {
                if (typeof (data) != "string") {
                    if (data.Status) {
                        showFileMessage(data.Message, data.File);
                    }
                    else {
                        showSelfMessage(data.Message, "");
                    }
                }
                else {
                    showSelfMessage(data, "");
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });
    //債金計算-系統設定
    $("#btnT3Calc").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForTCalc,
            type: 'post',
            data: {
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                CUTDATE: $("#F_CUTDATE").val(),
                CALTYPE: 'BATCH'

            },
            cache: false,
            success: function (data) {
                if (typeof (data) != "string") {
                    if (data.Status) {
                        showFileMessage(data.Message, data.File);
                    }
                    else {
                        showSelfMessage(data.Message, "");
                    }
                }
                else {
                    showSelfMessage(data, "");
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });
    //for t1 add 新增
    $("#btnT1Add").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForT1Add,
            type: 'post',
            data: {
                HACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                BASE_DATE: $("#T1_BASE_DATE").val(),
                FINE_DATE: '',
                INT_AMNT: $("#T1_INT_AMNT").val(),
                FEE_AMNT: $("#T1_FEE_AMNT").val(),
                EXEC_AMNT: $("#T1_EXEC_AMNT").val(),
                PROC_AMNT: $("#T1_PROC_AMNT").val(),
                FINE_TYPE: '',
                FINE_AMT: '0',
                FINE_AMT2: '0',
                FINERATE_A: '0',
                FINERATE_B: '0',
                FINE_RATE: '0'
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }
                if (mc.controls && mc.controls.length > 0)
                    SetControls(mc.controls);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t1 cancel
    $("#btnT1Cancel").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForT1Add,
            type: 'post',
            data: {
                SOURCE: $("#T1_SOURCE").val(),
                HACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val()
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }
                if (mc.controls && mc.controls.length > 0)
                    SetControls(mc.controls);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t1 restore
    $("#btnT1Restore").click(function () {
        blockMessage('執行中...');
        //first time
        $.ajax({
            url: UrlForT1Restore,
            type: 'post',
            data: {
                HACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                ISFIRSTTIME: true,
                ISCONTINUE: false
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (typeof mc.cf === 'undefined') {
                    alert('SQL 缺少回傳 Confirm model');
                    return;
                }

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }

                if (confirm(mc.cf.CONFIRM_MESSAGE)) {
                    blockMessage('執行中...');
                    $.ajax({
                        url: UrlForT1Restore,
                        type: 'post',
                        data: {
                            HACCTNMBR: $("#H_ACCTNMBR").val(),
                            ACCTNMBR: $("#F_ACCTNMBR").val(),
                            ISFIRSTTIME: false,
                            ISCONTINUE: true
                        },
                        cache: false,
                        success: function (pmc) {
                            if (typeof pmc === 'undefined')
                                return;

                            if (pmc.ms && pmc.ms.Message != '') {
                                alert(pmc.ms.Message);
                            }
                            if (pmc.controls && pmc.controls.length > 0)
                                SetControls(pmc.controls);
                        },
                        error: function (xhr, status, text) {
                            alert("Query Error : " + text);
                        }
                    }).complete(function () {
                        unBlock();
                    });
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t1 Backup
    $("#btnT1Backup").click(function () {
        blockMessage('執行中...');
        //first time
        $.ajax({
            url: UrlForT1Backup,
            type: 'post',
            data: {
                HACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                ISFIRSTTIME: true,
                ISCONTINUE: false
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (typeof mc.cf === 'undefined') {
                    alert('SQL 缺少回傳 Confirm model');
                    return;
                }

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }

                if (confirm(mc.cf.CONFIRM_MESSAGE)) {
                    blockMessage('執行中...');
                    $.ajax({
                        url: UrlForT1Backup,
                        type: 'post',
                        data: {
                            HACCTNMBR: $("#H_ACCTNMBR").val(),
                            ACCTNMBR: $("#F_ACCTNMBR").val(),
                            ISFIRSTTIME: false,
                            ISCONTINUE: true
                        },
                        cache: false,
                        success: function (pmc) {
                            if (typeof pmc === 'undefined')
                                return;

                            if (pmc.ms && pmc.ms.Message != '') {
                                alert(pmc.ms.Message);
                            }
                            if (pmc.controls && pmc.controls.length > 0)
                                SetControls(pmc.controls);
                        },
                        error: function (xhr, status, text) {
                            alert("Query Error : " + text);
                        }
                    }).complete(function () {
                        unBlock();
                    });
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t1 Setting
    $("#btnT1Setting").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForT1Setting,
            type: 'post',
            data: {
                SOURCE: $("#T1_SOURCE").val(),
                HACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val()
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }
                if (mc.controls && mc.controls.length > 0)
                    SetControls(mc.controls);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t1 Update
    $("#btnT1Update").click(function () {
        var SOURCE = '';
        blockMessage('執行中...');
        //ECS -- CONFIRM -- '更新人工設定會移除該Account的Pre WO BP標記，更新前請確認您提供的計算條件可以避免Pre WO BP Exception產生!!! ' + CHAR(13)+ '請問您是否要繼續更新人工設定?'
        //ALS -- confirm --更新人工設定會移除該Account的Exception 標記，更新前請確認您提供的計算條件可以避免Exception產生!!! " + CHR(13)+CHR(13) + "請問您是否要繼續更新人工設定?
        if (parseInt($("#F_ACCTNMBR").val().substring(0, 2)) >= 36) {
            SOURCE = 'DEBT AP';
            if ($("#T1_IF_PREWO").is(":checked") && !confirm("更新人工設定會移除該Account的Pre WO BP標記，更新前請確認您提供的計算條件可以避免Pre WO BP Exception產生!!! \n請問您是否要繼續更新人工設定?")) {
                unBlock();
                return;
            }
        }
        else if ($("#T1_IF_PREWO").is(":checked") || $("#T1_IF_XXWO").is(":checked")) {
            SOURCE = 'ALS DEBT AP';
            if (!confirm("更新人工設定會移除該Account的Exception 標記，更新前請確認您提供的計算條件可以避免Exception產生!!! \n\n請問您是否要繼續更新人工設定?")) {
                unBlock();
                return;
            }

        }
        //first time
        $.ajax({
            url: UrlForT1Update,
            type: 'post',
            data: {
                SOURCE: SOURCE,
                H_ACCTNMBR: $("#H_ACCTNMBR").val(),
                ACCTNMBR: $("#F_ACCTNMBR").val(),
                BASE_DATE: $("#T1_BASE_DATE").val(),
                INT_AMNT: $("#T1_INT_AMNT").val(),
                FEE_AMNT: $("#T1_FEE_AMNT").val(),
                EXEC_AMNT: $("#T1_EXEC_AMNT").val(),
                PROC_AMNT: $("#T1_PROC_AMNT").val(),
                M_N_INT_DATE: $("#T2_N_INT_DATE").val(),
                M_WO_P: $("#T2_PRI_AMNT").val(),
                M_WO_I: $("#T1_INT_AMNT").val(),
                M_RATE: $("#T2_APR").val(),
                REMARK: $("#T1_REMARK").val()
                
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (typeof mc.cf === 'undefined') {
                    alert('SQL 缺少回傳 Confirm model');
                    return;
                }

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }

                if (confirm(mc.cf.CONFIRM_MESSAGE)) {
                    blockMessage('執行中...');
                    $.ajax({
                        url: UrlForT1Update,
                        type: 'post',
                        data: {
                            SOURCE: $("#H_ACCTNMBR").val(),
                            H_ACCTNMBR: $("#H_ACCTNMBR").val(),
                            ACCTNMBR: $("#F_ACCTNMBR").val(),
                            BASE_DATE: $("#T1_BASE_DATE").val(),
                            INT_AMNT: $("#T1_INT_AMNT").val(),
                            FEE_AMNT: $("#T1_FEE_AMNT").val(),
                            EXEC_AMNT: $("#T1_EXEC_AMNT").val(),
                            PROC_AMNT: $("#T1_PROC_AMNT").val(),
                            FINE_TYPE: '',
                            FINE_AMT: '0',
                            FINE_AMT2: '0',
                            FINERATE_A: '0',
                            FINERATE_B: '0',
                            FINE_RATE: '0',
                            FINE_DATE: '',
                            IF_PREWO: $("#T1_IF_PREWO").is(":checked"),
                            UPDATE_P: $("#H_ACCTNMBR").val(),
                            ISFIRSTTIME: false,
                            ISCONTINUE: true
                        },
                        cache: false,
                        success: function (pmc) {
                            if (typeof pmc === 'undefined')
                                return;

                            if (pmc.ms && pmc.ms.Message != '') {
                                alert(pmc.ms.Message);
                            }
                            if (pmc.controls && pmc.controls.length > 0)
                                SetControls(pmc.controls);
                        },
                        error: function (xhr, status, text) {
                            alert("Query Error : " + text);
                        }
                    }).complete(function () {
                        unBlock();
                    });
                }
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t2 add
    $("#btnT2Add").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForT2Add,
            type: 'post',
            data: {
                ACCTNMBR: $("#H_ACCTNMBR").val(),
                STMT_YM: $("#T2_STMT_YM").val(),
                APR: $("#T2_APR").val(),
                N_INT_DATE: $("#T2_N_INT_DATE").val(),
                PRI_AMNT: $("#T2_PRI_AMNT").val(),
                BAL_TYPE: $("#T2_BAL_TYPE").val(),
                FINE_TYPE: ''
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }
                if (mc.controls && mc.controls.length > 0)
                    SetControls(mc.controls);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    //for t2 delete
    $("#btnT2Delete").click(function () {
        if ($("#DEBT101G01 tbody").find("input[name='chkGV1']:checked").length > 0) {
            if (confirm("是否刪除人工設定已勾選資料")) {
                var data = procT2DeleteData();

                if (data) {
                    blockMessage('執行中...');
                    $.ajax({
                        url: UrlForT2Del,
                        type: 'post',
                        data: data,
                        cache: false,
                        success: function (mc) {
                            if (typeof mc === 'undefined')
                                return;

                            if (mc.ms && mc.ms.Message != '') {
                                alert(mc.ms.Message);
                            }
                            if (mc.controls && mc.controls.length > 0)
                                SetControls(mc.controls);
                        },
                        error: function (xhr, status, text) {
                            alert("Query Error : " + text);
                        }
                    }).complete(function () {
                        unBlock();
                    });
                }
            }
        }
        else {
            alert("請勾選刪除資料");
        }
    });

    //for t2 update
    $("#btnT2Update").click(function () {
        blockMessage('執行中...');
        $.ajax({
            url: UrlForT2Update,
            type: 'post',
            data: {
                SOURCE: $("#T1_SOURCE").val(),
                ACCTNMBR: $("#H_ACCTNMBR").val(),
                STMT_YM: $("#T2_STMT_YM").val(),
                APR: $("#T2_APR").val(),
                N_INT_DATE: $("#T2_N_INT_DATE").val(),
                PRI_AMNT: $("#T2_PRI_AMNT").val(),
                BAL_TYPE: $("#T2_BAL_TYPE").val(),
                FINE_TYPE: ''
            },
            cache: false,
            success: function (mc) {
                if (typeof mc === 'undefined')
                    return;

                if (mc.ms && mc.ms.Message != '') {
                    alert(mc.ms.Message);
                }
                if (mc.controls && mc.controls.length > 0)
                    SetControls(mc.controls);
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        }).complete(function () {
            unBlock();
        });
    });

    SetControls(controls);
});

function SetControls(controls) {
    if (controls.length > 0) {
        for (var i = 0; i < controls.length; i++) {
            var obj = controls[i];
            var id = obj.ID;
            var action = obj.ACTION;
            var flag = obj.ENABLED;

            if ($("#" + id).length > 0) {
                switch (action) {
                    case "ENABLED":
                        $("#" + id).prop('disabled', !flag);
                        break;
                    case "DISABLED":
                        $("#" + id).prop('disabled', flag);
                        break;
                    case "VISIBLE":
                        break;
                    case "CLICK":
                        if (flag) {
                            $("#" + id).click();
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}

function procT2DeleteData() {
    var data = {};
    $("#DEBT101G01 tbody").find("input[name='chkGV1']:checked").each(function (idx, el) {
        var tr = $(this).closest('tr');
        var prefix = "list[" + idx + "].";
        var source = prefix + "SOURCE";
        var acctnmbr = prefix + "ACCTNMBR";
        var ym = prefix + "STMT_YM";
        var apr = prefix + "APR";
        var bal = prefix + "BAL_TYPE";
        data[source] = $("#T1_SOURCE").val();
        data[acctnmbr] = tr.find("[data-name='ACCTNMBR']").text();
        data[ym] = tr.find("[data-name='STMT_YM']").text();
        data[apr] = tr.find("[data-name='APR']").text();
        data[bal] = tr.find("[data-name='BAL_TYPE']").text();
    });

    return data;
}

function DEBT101G01_Select(btn) {
    var row = $(btn).closest(".grid-row");
    if (row.length <= 0)
        return;
    var gridRow = {};
    row.find(".grid-cell").each(function () {
        var columnName = $(this).attr("data-name");
        if (columnName.length > 0)
            gridRow[columnName] = $(this).text();
    });

    pageGrids.DEBT101G01.markRowSelected(row);
    var prefix = 'T2_';
    for (var name in gridRow) {
        var fn = prefix + name;
        var el = $("[name='" + fn + "']");

        if (el.length > 0) {
            var tag = el[0].tagName;
            switch (tag) {
                case "INPUT":
                    var type = el.attr("type").toUpperCase();
                    if (type == 'TEXT') {
                        $("input[name='" + fn + "']").val(gridRow[name]);
                    }
                    else if (type === 'RADIO' || type === 'CHECKBOX') {
                        for (var i = 0; i < el.length; i++) {
                            if ($(el[i]).attr("value") == gridRow[name]) {
                                $(el[i]).prop("checked", true);
                            }
                            else {
                                $(el[i]).prop("checked", false);
                            }
                        }
                    }
                    break;
                case "SELECT":
                    var t = $("select[name='" + fn + "']").children().filter(function () {
                        return $(this).val() == gridRow[name];
                    }).val();
                    $("select[name='" + fn + "']").val((typeof t == 'undefined' ? '' : t));
                    break;
            }
        }
    }

    //change some field to readonly
    $("#T2_APR").prop("disabled", true);
    $("#T2_STMT_YM").prop("disabled", true);
    $("#T2_BAL_TYPE").prop("disabled", true);
}

function T1_CheckAll(chk) {
    if ($(chk).attr('name') == "chkG1All") {
        $("input[name='chkGV1']").prop("checked", $(chk).is(":checked"));
    }
    else {
        if ($("input[name='chkGV1']").length == $("input[name='chkGV1']:checked").length) {
            $("input[name='chkG1All']").prop("checked", true);
        }
        else {
            $("input[name='chkG1All']").prop("checked", false);
        }
    }
}
