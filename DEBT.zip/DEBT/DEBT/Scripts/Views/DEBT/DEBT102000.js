﻿$(document).ready(function () {
    MainScript();
    //debug
    //$('#F_ACCTNMBR').val("1111********4444");
    uiClean();

    $('.TP').attr("maxlength", "11");
    TextBoxNumberToAddComma();

});

function TextBoxNumberToAddComma() {
    $('.TP').each(function (i, item) {
        $(item).focus(function () {
            //當獲得focus時，要把千分位給拿掉
            $(this).val(RemoveComma($(this).val()));
            $(this).select();
        })
        .blur(function () {
            //限制輸入長度
            TextAreaLength(this, 14);

            //加千分位
            AdjustComma(this, 11);
        });
    });

    $('.TP').each(function (i, item) {
        $(item).change(function () {
            //當獲得chage時，要把千分位給拿掉
            $("#SOURCE_AP").val("人工設定");
        });

    });
}

//數字處理為有千分位
//function AppendComma(n) {
//    if (!/^((-*\d+)|(0))$/.test(n)) {
//        var newValue = /^((-*\d+)|(0))$/.exec(n);
//        if (newValue != null) {
//            if (parseInt(newValue, 10)) {
//                n = newValue;
//            }
//            else {
//                n = '0';
//            }
//        }
//        else {
//            n = '0';
//        }
//    }

//    if (parseInt(n, 10) == 0) {
//        n = '0';
//    }
//    else {
//        n = parseInt(n, 10).toString();
//    }

//    n += '';
//    var arr = n.split('.');
//    var re = /(\d{1,3})(?=(\d{3})+$)/g;
//    return arr[0].replace(re, '$1,') + (arr.length == 2 ? '.' + arr[1] : '');
//}


//數字處理為有千分位
function AppendComma(n) {
    // if (!/^((-*\d+)|(0))$/.test(n)) {
    if (!/^\d+[.]?\d*$/.test(n)) {
        //  var newValue = /^((-*\d+)|(0))$/.exec(n);
        var newValue = /^\d+[.]?\d*$/.exec(n);
        if (newValue != null) {
            if (parseFloat(newValue, 10)) {
                n = newValue;
            }
            else {
                n = '0';
            }
        }
        else {
            n = '0';
        }
    }

    if (parseFloat(n, 10) == 0) {
        n = '0';
    }
    else {
        n = parseFloat(n, 10).toString();
    }

    n += '';
    var arr = n.split('.');
    var re = /(\d{1,3})(?=(\d{3})+$)/g;
    return arr[0].replace(re, '$1,') + (arr.length == 2 ? '.' + arr[1] : '');
}




//將有千分位的數值轉為一般數字
function RemoveComma(n) {
    return n.replace(/[,]+/g, '');
}

//調整千分位
function AdjustComma(item, length) {
    var originalValue = $.trim($(item).val()).length > length
        ? $.trim($(item).val()).substr(0, length)
        : $.trim($(item).val());

    $(item).val(AppendComma(originalValue));
}

//動態調整輸入欄位的長度
function TextAreaLength(item, length) {
    if (item.value.length > length) {
        item.value = item.value.substring(0, length);
    }
}





function MainScript() {
    $(".dp").datepicker({
        dateFormat: "yy/mm/dd",
        showMonthAfterYear: true,
        changeYear: true,
        changeMonth: true
        //buttonText: "Select date"
    });

    //製作Dialog
    createDialog();

    //CUT_DATE Default
    var date = new Date();
    var now = date.getFullYear() + '/'
        + (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '/'
        + (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
    //$('#btnAdj').prop("disabled", "disabled");
    $('#CUT_DATE').val(now);

    //CUT_DATE變更時
    $('#CUT_DATE').change(function () {
        var strLen = $(this).prop('value').replace(/\D/g, '').length;
        if (strLen !== 8) {
            alert('債金計算截止日不正確，將變更回預設值！')
            $('#CUT_DATE').prop("value", now);
        } else {
            var t_old = $(this).prop('value').replace(/\D/g, '');
            var t_combo = t_old.substring(0, 4) + '/' + t_old.substring(4, 6) + '/' + t_old.substring(6, 8);
            $('#CUT_DATE').prop("value", t_combo);
        }
    });

    //帳號，卡號變更時
    $('#F_ACCTNMBR').blur(function () {
        uiClean();
        $(this).val($.trim($(this).val()));
        $('#ACCTNMBR').val($(this).prop('value'));
    });

    //設定條件按鈕按下時
    $('#btnSet').click(function () {
        if ($('#IS_FLOW').val() === "True") {
            alert("帳號/卡號:" + $('#ACCTNMBR').val() + "正在進行流程");
        }
        else {
            $("#CKS_Dialog").dialog('open');
        }
    });

    //CheckBox變更時
    $("input[type=checkbox]", $('#DEBT102002')).click(function () {
        var cb_name = $(this).prop('name');
        if (cb_name == 'IF_XXWO_CB') {
            $('#IF_XXWO').prop('value', ($(this).prop('checked') == true ? 'Y' : 'N'));
        }
        if (cb_name == 'IF_PREWO_CB') {
            $('#IF_PREWO').prop('value', ($(this).prop('checked') == true ? 'Y' : 'N'));
        }
    });

    //102002變更時
    $("#DEBT102002 .zc").blur(function () {//金額欄位
        if ($(this).val() == '') {
            $(this).val("0");
        }
    });
    $("#DEBT102002 .rz").blur(function () {//利息欄位
        if ($(this).val() == '') {
            $(this).val("0");
        }
        //百分比防呆
        //var index_num = $(this).val().indexOf('%')
        //if (index_num === -1) {//找不到百分比
        //    $(this).val( $(this).val() + '%');
        //}
        //if (index_num === 0 && $(this).length === 1) {//只有百分比
        //    $(this).val('0%');
        //}
    });
}

//搜尋
function btnQuery_fn() {
    ///var row = $("#DEBT102001").closest(".grid-row");
    if ($('#F_ACCTNMBR').prop('value').length == 0) {
        alert("請輸入 帳號/卡號！")
    } else {
    $.ajax({
        url: urlForSearch,
        type: "post",
        data: $('#DEBT10200F :input').serialize(),
        async: false,
        cache: false,
        success: function (data) {
            if (typeof (data) !== 'undefined' && typeof (data) == 'object' && data.Status === false) {
                alert(data.Message);
                uiClean(); //Clean DEBT102002
                $('#btnAdj').prop("disabled", true);
                $('#DEBT102001 > tbody').empty();
                $('#DEBT102001 > tbody').append('<tr class="grid-empty-text"><td colspan="44">查無資料</td></tr>')
            } else {
                $("#DEBT102001").html(data);
                if ($('#DEBT102001 > tbody > tr:eq(0) td:eq(0)').length > 0) {
                    var btn = $('#DEBT102001 > tbody > tr:eq(0) td:eq(0)').find('input[type=button]');
                    btnDetail_fn(btn);
                }
                else {
                    uiClean(); //Clean DEBT102002
                }

                uiControl($('#IS_FLOW').val());
                if ($('#IS_FLOW').val() === "True") {
                    //alert("此Account正在進行簽核作業。");
                    if ($('#AlertMsg').val() != "")
                        alert(($('#AlertMsg').val()).replace(/<BR \/>/g, "\n"));
                    else
                        alert("帳號/卡號:" + $('#F_ACCTNMBR').val() + "正在進行流程");
                }
                else if ((typeof ($('#AlertMsg').val()) != "undefined" && $('#AlertMsg').val() != "")) {
                    alert(($('#AlertMsg').val()).replace(/<BR \/>/g, "\n"));
                }
            }
            parent.ResizeIframe();

        },
        error: function (xhr, status, text) {
            alert("Query Error : " + text);
        },
        complete: function () {
            //即使Query沒有這個帳號，仍把ACCTNMBR設定為此帳號
            $('#ACCTNMBR').val($('#F_ACCTNMBR').prop('value'));

        }
    });

    }
}

//顯示詳細資料
function btnDetail_fn(btn) {
    var tr = $(btn).closest('tr');
    $('#WO_P').val(tr.children().eq(1).text().replace(new RegExp(',', 'g'), '')); //本金
    $('#N_INT_DATE').val(tr.children().eq(2).text()); //利息起算日
    $('#RATE').val(tr.children().eq(3).text().replace('%', '')); //利率
    $('#BASE_DATE').val(tr.children().eq(4).text()); //計算基準日
    $('#WO_FEE').val(tr.children().eq(5).text().replace(',', '')); //已結算費用
    $('#WO_I').val(tr.children().eq(6).text().replace(',', '')); //已結算利息
    //法務費(7)不列入
    $('#SOURCE_AP').val(tr.children().eq(8).text()); //資料來源
    $('#CREATEDDT').val(tr.children().eq(9).text()); //建立日期, display
    $('#SEQNO').val(tr.children().eq(10).text());
    $('#DOCGUID').val(tr.children().eq(11).text());
    $('#TABLENAME').val(tr.children().eq(12).text());
    $('#ACCTNMBR').val(tr.children().eq(13).text());
    $('#CUSTID').val(tr.children().eq(14).text());
    $('#CUSTNAME').val(tr.children().eq(15).text());
    $('#LOCATION').val(tr.children().eq(16).text());
    $('#BUSINESS').val(tr.children().eq(17).text());
    $('#WODATE').val(tr.children().eq(18).text());
    $('#LEGAL_FEE').val(tr.children().eq(19).text());
    $('#PROC_AMNT').val(tr.children().eq(20).text().replace(',', ''));
    $('#EXEC_AMNT').val(tr.children().eq(21).text().replace(',', ''));
    $('#SERV_CHRGE').val(tr.children().eq(22).text());
    $('#LATE_CHRGE').val(tr.children().eq(23).text());
    $('#MBRZP_FEE').val(tr.children().eq(24).text());
    $('#IF_RECORD').val(tr.children().eq(25).text());
    //$('#IF_XXWO').val(tr.children().eq(26).text());
    //$('#IF_PREWO').val(tr.children().eq(27).text());
    $('#REMARK').val(tr.children().eq(28).text());
    $('#IF_ECMS').val(tr.children().eq(29).text());
    $('#MAKER_ID').val(tr.children().eq(30).text());
    $('#MAKER_NAME').val(tr.children().eq(31).text() + '(' + tr.children().eq(30).text() + ')'); //display
    $('#CHECKER_ID').val(tr.children().eq(32).text());
    $('#CHECKER_NAME').val(tr.children().eq(33).text() + '(' + tr.children().eq(32).text() + ')'); //display
    $('#CHECK_DT').val(tr.children().eq(34).text()); //display
    $('#CREATEDBYID').val(tr.children().eq(35).text());
    $('#CREATEDBYNAME').val(tr.children().eq(36).text());
    $('#MAKE_DT').val(tr.children().eq(37).text());
    $('#LASTUPDATEDBYID').val(tr.children().eq(38).text());
    $('#LASTUPDATEDBYNAME').val(tr.children().eq(39).text());
    $('#LASTUPDATEDDT').val(tr.children().eq(40).text());
    $('#CLOSE_D').val(tr.children().eq(41).text());
    $('#SCREEN_D').val(tr.children().eq(42).text());
    $('#RCVRY_FEE').val(tr.children().eq(43).text());
    //CheckBox 另外處理
    $('#IF_XXWO').val(tr.children().eq(26).text());
    $('#IF_PREWO').val(tr.children().eq(27).text());
    //將隱藏欄位值轉至顯示
    $('td.dis1').empty().append(tr.children().eq(31).text() + '(' + tr.children().eq(30).text() + ')');
    $('td.dis2').empty().append(tr.children().eq(37).text());
    $('td.dis3').empty().append(tr.children().eq(33).text() + '(' + tr.children().eq(32).text() + ')');
    $('td.dis4').empty().append(tr.children().eq(34).text());
    //時間顯示
    //alert(tr.children().eq(37).text());
    //var strTime = tr.children().eq(37).text();
    //var cut_pos1 = strTime.indexOf(' '); //alert(cut_pos1);
    //var cut_pos2 = strTime.indexOf(' ', 1 + cut_pos1); //alert(cut_pos2);
    //var cut_date = strTime.substring(0, 0 + cut_pos1); alert(cut_date);
    //var cut_time = strTime.substring(0 + cut_pos2, strTime.length); alert(cut_time);
    //var dis_t = new Date(tr.children().eq(37).text());
    //alert(dis_t);
    //var dis2_t = dis_t.getFullYear() + '/'
    //    + (dis_t.getMonth() + 1 < 10 ? '0' + (dis_t.getMonth() + 1) : dis_t.getMonth() + 1) + '/'
    //    + (dis_t.getDate() < 10 ? '0' + dis_t.getDate() : dis_t.getDate()) + ' '
    //    + (dis_t.getHours() < 10 ? '0' + dis_t.getHours() : dis_t.getHours()) + ':'
    //    + (dis_t.getMinutes() < 10 ? '0' + dis_t.getMinutes() : dis_t.getMinutes()) + ':'
    //    + (dis_t.getSeconds() < 10 ? '0' + dis_t.getSeconds() : dis_t.getSeconds()); 
    //$('td.dis2').empty().append(dis2_t);

    var date = new Date();
    var now = date.getFullYear() + '/'
        + (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '/'
        + (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
    //$('#btnAdj').prop("disabled", "disabled");
    $('#CUT_DATE').val(now);
    $('#CUT_DATE').val("");

    //Checkbox 控制
    if (tr.children().eq(26).text() == 'Y') {
        $("input[name='IF_XXWO_CB']").prop('checked', true)
    } else {
        $("input[name='IF_XXWO_CB']").prop('checked', false)
    }
    if (tr.children().eq(27).text() == 'Y') {
        $("input[name='IF_PREWO_CB']").prop('checked', true)
    } else {
        $("input[name='IF_PREWO_CB']").prop('checked', false)
    }
    $('.TP').each(function (i, item) {
        //限制輸入長度
        // TextAreaLength(this, 14);

        //加千分位
        AdjustComma(this, 11);
    });
    if ($('#SOURCE_AP').val() == "DRP_ADJUST") {
        //alert("Please add Payment.");
        alert("請新增繳款紀錄或確認債金條件是否正確");
    }
}

//製作SelectCheckerDialog
function createDialog() {
    //製作視窗
    if ($("#CKS_Dialog").length == 0) {
        var modalDialog = $('<div/>').attr("id", "CKS_Dialog");
        modalDialog.appendTo($("body"));
    }

    //視窗內容
    strHtml = '<select id="checkers" class="checkers"></select>';

    //載入視窗
    $("#CKS_Dialog").html(strHtml);
    $("#CKS_Dialog").dialog({
        title: "請選擇Checker",
        autoOpen: false,
        width: 220,
        height: 200,
        modal: true,
        buttons: {
            "送出": function () {
                var c_soeid = $('#CKS_Dialog option:selected').val();
                var c_name = $('#CKS_Dialog option:selected').text();
                c_name = c_name.substring(0, c_name.indexOf('('));
                btnSet_fn(c_soeid, c_name);
                $(this).dialog("close");
            },
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });

    //取得清單並載入
    $.ajax({
        url: urlForGetCheckerList,
        type: "get",
        async: false,
        cache: false,
        success: function (lstItem) {
            if (lstItem !== null) {
                $.each(lstItem, function (i, item) {
                    $('#checkers').append($('<option>', {
                        value: item.Value,
                        text: item.Text,
                        selected: item.Selected
                    }));
                });
            }
        },
        error: function (xhr, status, text) {
            alert("Query Error : " + text);
        }
    });
}

//設定為日後債金計算條件
function btnSet_fn(checker_soeid, checker_name) {
    //todo..欄位防呆
    var blCheck = true;
    var msg = "";
    var acctnmbr_val = "" + $('#ACCTNMBR').val;

    if ($('#IS_FLOW').val() === "True") {
        alert("帳號/卡號:" + $('#ACCTNMBR').val() + "正在進行流程");
        blCheck = false;
    }
    else {
        if (acctnmbr_val.length == 0) {
            msg = "請輸入 帳號/卡號！\n";
            blCheck = false;
        }
        if ($('#N_INT_DATE').prop('value').length == 0 || $('#BASE_DATE').prop('value').length == 0) {
            msg += "日期欄位尚未指定日期！\n";
            blCheck = false;
        }
        if ($("#check option:selected").val() === '') {
            msg += "無Checker資料，無法送出！\n";
            blCheck = false;
        }
    }

    if (blCheck) {

        //將資料上傳至Controller
        var params = { NEW_CHECKER_ID: checker_soeid, NEW_CHECKER_NAME: checker_name };

        //remove comma
        $('.TP').each(function () {
            $(this).val(RemoveComma($(this).val()));
        });

        var obj = $('#DEBT102002 :input').serialize() + '&' + $.param(params);

        $.ajax({
            url: urlForSetDebtCondition,
            type: "post",
            data: obj,
            async: false,
            cache: false,
            success: function (data) {
                alert(data.Message);
                btnQuery_fn(); //更新畫面
            },
            error: function (xhr, status, text) {
                alert("Query Error : " + text);
            }
        });
    }
}

//調整繳款紀錄
function btnAdj_fn() {
    var winFeatures = "status:no;dialogHeight:768px; dialogWidth:1024px;";
    var obj = new Object();
    var ACCTNMBR = $('#F_ACCTNMBR').val()
    if (ACCTNMBR.indexOf(" ") < 0 && ACCTNMBR != "") {
        obj.name = ACCTNMBR
        var first = window.open("/DEBT/DEBT/DEBT103000" + '?ACCTNMBR=' + ACCTNMBR, 'DEBT', 'scrollbars=yes');
        first.focus();
        //        if (first.open) {
        //            window.close();
        //            var myWindow = window.open("/DEBT/DEBT/DEBT103003" + '?ACCTNMBR=' + ACCTNMBR, 'DEBT', 'scrollbars=yes');
        //            myWindow.focus();
        //        }

    }
    else {
        alert('卡號不能為空白和輸入空格!!!');
    }
}

//債金計算
function btnCalc_fn() {

    var blCheck = true;
    var ErrorMessage = "";

    if ($('#F_ACCTNMBR').val() === '') {
        blCheck = false;
        ErrorMessage ="請輸入 帳號/卡號";        
    }
    else {
        if ($('#N_INT_DATE').prop('value').length == 0 ) {
            blCheck = false;
            ErrorMessage +='利息起算日不正確！\n';
        }
        if ($('#BASE_DATE').prop('value').length == 0 ) {
            blCheck = false;
            ErrorMessage += '計算基準日不正確！\n';
        }
        if ($('#CUT_DATE').prop('value').length == 0 ) {
            blCheck = false;
            ErrorMessage += '債金計算截止日不正確！\n';
        }

        if (blCheck) {
//            if ($("input[name='IF_XXWO_CB']").prop('checked') == true) {
//                alert("ACCOUNT:" + $('#F_ACCTNMBR').val() + "是XXWO Account，不計算債金只輸出Payment List!");
//            }
            //將資料上傳至Controller
            var params = { CUT_DATE: $('#CUT_DATE').val() };
            //remove comma
            $('.TP').each(function () {
                $(this).val(RemoveComma($(this).val()));
            });
            var obj = $('#DEBT102002 :input').serialize() + '&' + $.param(params);

            $.ajax({
                url: urlForDebtCalculation,
                type: "post",
                data: obj,
                async: false,
                cache: false,
                success: function (data) {
                    if (typeof (data) != "string") {
                        if (data.Status) {
                            showFileMessage(data.Message, data.File);
                        }
                        else {
                            showSelfMessage(data.Message, "");
                        }
                    }
                    else {
                        showSelfMessage(data, "");
                    }
                },
                error: function (xhr, status, text) {
                    alert("Query Error : " + text);
                }
            });
        }
        else {
            alert(ErrorMessage);
        }
    }
}

//根據 ISFlow 決定功能的開放
function uiControl(IS_FLOW) {
    if (IS_FLOW === "True") {
        //alert("ui lock !!!")
        $('#btnSet').prop("disabled", "disabled");
        $('#btnAdj').prop("disabled", "disabled");
        $('#btnCalc').prop("disabled", "disabled");
    } else if (IS_FLOW === "False") {
        //alert("ui unlock !!!")
        $('#btnSet').prop("disabled", "");
        $('#btnAdj').prop("disabled", "");
        $('#btnCalc').prop("disabled", "");
    }
}

//介面資料清除
function uiClean() {
    $('#DEBT102002 input').val("");
    $('#DEBT102002 .zc').val("0");
    $('#DEBT102002 .rz').val("0");
    $('td.dis1').empty();
    $('td.dis2').empty();
    $('td.dis3').empty();
    $('td.dis4').empty();
    //CheckBox
    $("input:checkbox").prop('checked', false)
    //按鈕的字QwQ!!!
    $('#btnSet').val("設定為日後債金計算條件");
    $('#btnAdj').val("調整繳款紀錄");
    $('#btnCalc').val("債金計算");

}



