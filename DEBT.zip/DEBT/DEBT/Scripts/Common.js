﻿
if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.replace(/(^[\\s]*)|([\\s]*$)/g, "");
    }
}

if (!String.prototype.lTrim) {
    String.prototype.lTrim = function () {
        return this.replace(/(^[\\s]*)/g, "");
    }
}

if (!String.prototype.rTrim) {
    String.prototype.rTrim = function () {
        return this.replace(/([\\s]*$)/g, "");
    }
}

if (!String.prototype.startsWith) {
    String.prototype.startsWith = function (searchString, position) {
        return this.substr(position || 0, searchString.length) === searchString;
    };
}

Date.prototype.yyyymmdd = function (separation) {
    var mm = this.getMonth() + 1; // getMonth() is zero-based
    var dd = this.getDate();

    return [this.getFullYear(),
    (mm > 9 ? '' : '0') + mm,
    (dd > 9 ? '' : '0') + dd
    ].join(separation);
}

Date.prototype.addDays = function (days) {
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
}

if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (obj, start) {
        for (var i = (start || 0), j = this.length; i < j; i++) {
            if (this[i] === obj) { return i; }
        }
        return -1;
    }
}

function QueryString(name) {
    var AllVars = window.location.search.substring(1);
    var Vars = AllVars.split("&");
    for (var i = 0; i < Vars.length; i++) {
        var Var = Vars[i].split("=");
        if (Var[0] == name) return Var[1];
    }
    return "";
}

//檢查瀏覽器版本
function getInternetExplorerVersion() {
    var rv = -1;
    if (navigator.appName == 'Microsoft Internet Explorer') {
        var ua = navigator.userAgent;
        var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat(RegExp.$1);
    }
    else if (navigator.appName == 'Netscape') {
        var ua = navigator.userAgent;
        var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat(RegExp.$1);
    }
    return rv;
}

function showSelfMessage(message, targetUrl) {

    if ($("#divMsgDialog").length == 0) {
        var modalDialog = $('<div/>').attr("id", "divMsgDialog");
        modalDialog.appendTo($("body"));

    }
    $("#divMsgDialog").html(message);
    $("#divMsgDialog").dialog(
        {
            title: "訊息",
            width: 550,
            height: 350,
            modal: true,
            buttons: {
                "Ok": function () {
                    $(this).dialog("close");
                    if (typeof (targetUrl) !== "undefined" && targetUrl !== '') {
                        window.location.href = targetUrl;
                    } //if
                } //function
            } //buttons
        }
    );
}

function showFileMessage(message, file) {

    if ($("#divMsgDialog").length == 0) {
        var modalDialog = $('<div/>').attr("id", "divMsgDialog");
        modalDialog.appendTo($("body"));

    }

    $("#divMsgDialog").html("<span style=\"font-size:10pt\">" + message + "</span>");

    if (file != null && typeof (file) == "object") {
        for (var i = 0; i < file.length; i++) {
            var TagA = $("<a style=\"font-size:10pt\"></a>").attr("href", file[i].url).text(file[i].title);
            $("#divMsgDialog").append("<br/>").append(TagA);
        }
    }

    $("#divMsgDialog").dialog(
        {
            title: "檔案下載",
            width: 550,
            height: 350,
            modal: true,
            buttons: {
                "Ok": function () {
                    $(this).dialog("close");
                } //function
            } //buttons
        });
}

//若無提供檔案之需求，請直接使用Confirm...
function showFileMessageWithConfirm(message, file) {
    //於當前網頁置入DIV( id = 'divMsgDialog' )
    if ($("#divMsgDialog").length == 0) {
        var modalDialog = $('<div/>').attr("id", "divMsgDialog");
        modalDialog.appendTo($("body"));
    }

    //寫入詢問訊息
    $("#divMsgDialog").html("<span style=\"font-size:10pt\">" + message + "</span>");

    //寫入檔案鏈結
    if (file != null && typeof (file) == "object") {
        for (var i = 0; i < file.length; i++) {
            var TagA = $("<a style=\"font-size:10pt\"></a>").attr("href", file[i].url).text(file[i].title);
            $("#divMsgDialog").append("<br/>").append(TagA);
        }
    }

    //Dialog樣式
    $("#divMsgDialog").dialog(
        {
            title: "檔案下載",
            width: 550,
            height: 350,
            modal: true,
            buttons: {
                "YES": function () {
                    $(this).dialog("close");
                    return true;
                }, //function
                "NO": function () {
                    $(this).dialog("close");
                    return false;
                }
            } //buttons
        });
}

//新增開新的Dialog視窗
function OpenDlg(url) {
    var winFeatures = "status:no;dialogHeight:768px; dialogWidth:1024px;";
    //returnVal = window.showModalDialog(path + form.substring(0, 5) + '/' + form + '/' + SeqNO, self, winFeatures);
    returnVal = window.showModalDialog(url.replace('//', '/'), self, winFeatures);
    return returnVal;
}

function ExportFromIframe(_urlPost, _inputs, _message, _message1) {
    var $ifrm = $("<iframe style='display:none' />");

    if ($("#iFrameExport").length > 0) {
        $("#iFrameExport").remove();
    }

    var iframe = document.createElement("iframe");
    $(iframe).attr("id", "iFrameExport").hide();
    document.body.appendChild(iframe);

    var frame = iframe.contentWindow.document;
    frame.writeln("<form id='form1' action='" + _urlPost + "' method='post'>" + _inputs + "</form>");

    //if ($ifrm[0].addEventListener) {
    if (iframe.addEventListener) {
        //開啟匯出檔案loading
        $.blockUI({
            message: _message || "檔案產生中，請稍候",
            css: {
                border: 'none',
                padding: '15px',
                backgroundColor: '#000',
                '-webkit-border-radius': '10px',
                '-moz-border-radius': '10px',
                opacity: .5,
                color: '#fff'
            }
        });

        $(iframe.contentWindow.document).one("readystatechange", function () {
            if (document.readyState == "complete") {
                $.unblockUI(_message1);
            }
        });

        $(iframe).load(function () {
            //if the download link return a page
            //load event will be triggered

            $.unblockUI("No Data");
        });

    }
    frame.getElementById("form1").submit();
}

function unBlock(msg) {
    $.unblockUI();

    if (msg) {
        $.Message.Open(msg);
    }
}

function blockMessage(msg) {
    $.blockUI({
        message: msg,
        css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff'
        }
    });
}

function ExportMutipleFromAjax(_urlPost, _Action, _inputs, _message, _message1) {
    $.ajax({
        url: _urlPost,
        type: _Action,
        data: _inputs,
        async: true,
        chche: false,
        //datatype: 'html',
        //contentType: 'application/html;charset=utf-8',
        success: function (data) {

            if (data.Status) {
                showFileMessage(data.Message, data.File);
            } else {
                showSelfMessage(data.Message, "");
            }
        },
        error: function (xhr, status, text) {
            alert("Query Error : " + text);
        }
    });
}

function ExportFromAjax(_urlPost, _Action, _inputs, _message, _message1) {
    blockMessage(_message);
    $.ajax({
        url: _urlPost,
        type: _Action,
        data: _inputs,
        async: true,
        chche: false,
        //datatype: 'json',
        //contentType: 'application/html;charset=urf-8',
        success: function (data) {

            if (typeof (data) != "string") {
                if (data.Status) {
                    showFileMessage(data.Message, data.File);
                }
                else {
                    showSelfMessage(data.Message, "");
                }
            }
            else {
                showSelfMessage(data, "");
            }

        },
        error: function (xhr, status, text) {
            showSelfMessage("執行失敗：" + text);
        }
    });
    unBlock('');
}

function ExecuteMultipleResult(_urlPost, _action, _inputs, _message, _message1) {
    $.ajax({
        url: _urlPost,
        type: _action,
        data: _inputs,
        async: false,
        chche: false,
        datatype: 'html',
        contentType: 'application/html;charset=urf-8',
        success: function (data) {

            if (data.Status) {
                //showFileMessage(data.Message, data.File);  
                alert(data.Message);
                if (typeof (data.File) == "object" && data.File.length > 0)
                    window.location = data.File[0].url;
            }

        },
        error: function (xhr, status, text) {
            alert("Query Error : " + text);
        }

    });
}

//檢查統一編號
function Check_BID(taxId) {
    var invalidList = "00000000,11111111";
    if (/^\d{8}$/.test(taxId) == false || invalidList.indexOf(taxId) != -1) {
        return false;
    }

    var validateOperator = [1, 2, 1, 2, 1, 2, 4, 1],
        sum = 0,
        calculate = function (product) { // 個位數 + 十位數
            var ones = product % 10,
                tens = (product - ones) / 10;
            return ones + tens;
        };
    for (var i = 0; i < validateOperator.length; i++) {
        sum += calculate(taxId[i] * validateOperator[i]);
    }

    return sum % 10 == 0 || (taxId[6] == "7" && (sum + 1) % 10 == 0);
};

//檢查 Acctnmbr (公司產品號碼)
function Check_ACCT(acct) {
    var card_list = ['11', '25', '26', '22', '12', '13', '31', '32', '21', '01', '02', '03'
        , '04', '05', '06', '07', '08', '09', '00', '16', '17', '18', '19', '27', '28'];
    var re_chk = 1;      //正則檢查結果，1-> all num
    var re = /^[0-9]+$/; //正則：只能為0-9的數字
    acct = acct.trim();  //去掉頭尾空白
    var acct_chk = 0;    //對只有14碼的ACCT前兩碼檢查, 1-> in card_list
    var acct_len = parseInt(acct.length); //字串長度

    //長度正確的號碼才可進入檢查程序
    if ((acct_len == 14) || (acct_len == 16)) {
        //字串正則檢查        
        for (i = 0; i < (acct_len); i++) {
            //只能為數字
            if (!re.test(acct.substr(i, ((i + 1) == acct_len ? i : (i + 1))))) {
                re_chk = 0
            }
        }

        var CHKSUM = 0
        var CHK_CARDNO = 0
        switch (re_chk) {
            case 1://純數字的組合
                //alert('純數字組合')//ckp
                for (i = 0; i < (acct_len - 1); i++) {
                    var IND = 0
                    IND = parseInt(acct.substr(i, 1)) * (i % 2 == 1 ? 2 : 1)
                    CHKSUM = (CHKSUM + (IND >= 10 ? (Math.floor(IND / 10) + (IND % 10)) : IND))
                }

                //alert('sub_acct_len:' + (acct.substr((acct_len - 1), 1)) + '  CHKSUM:' + CHKSUM)//ckp
                if (parseInt(acct.substr((acct_len - 1), 1)) == (10 - ((CHKSUM % 10) == 0 ? 10 : (CHKSUM % 10)))) {
                    if (acct_len = 14) {
                        //&& DINERS
                        CHK_CARDNO = 0
                    } else {
                        //&& VISA / MASTER
                        CHK_CARDNO = 1
                    }
                } else {
                    //其它
                    //alert('純數字的其他組合')//ckp
                    CHK_CARDNO = -1
                }

                alert(CHK_CARDNO)
                break;

            case 0://有非數字的組合
                //alert('有非數字組合')//ckp
                CHK_CARDNO = -1
                break;
        }

        //ACCTNMBR前兩碼檢查
        for (i = 0; i < (card_list.length); i++) {
            if ((acct.substr(0, 2)) == card_list[i]) {
                acct_chk = 1
            }
            else if ((i == (card_list.length - 1)) && (acct_chk == 0)) {
                //如果前兩碼不在清單中，且Acctnmbr長度不為14，回傳false
                acct_chk = 0
            }
        }

        //Before Switch之後...(須將前兩碼檢查結果帶入)
        if ((CHK_CARDNO >= 0) || ((acct_chk == 1) && (acct_len == 14))) {
            if (CHK_CARDNO >= 0) {
                var obj = {
                    status: true,
                    message: '信用卡卡號正確，請繼續...'
                }
                //alert('信用卡卡號正確，請繼續...')
                return obj;
            } else {
                var obj = {
                    status: true,
                    message: '貸款號碼正確，請繼續...'
                }
                //alert('貸款號碼正確, 請繼續...')
                return obj;
            }

        } else {
            var obj = {
                status: false,
                message: '公司產品號碼不正確...'
            }
            //alert('公司產品號碼不正確...')
            return obj;
        }
    } else {
        var obj = {
            status: false,
            message: '公司產品號碼長度不正確...'
        }
        //alert('公司產品號碼長度不正確...')
        return obj;
    }
}
// Check CARD NO 
function CHK_CARDNO(cardno) {
    var CHK1 = 1;
    var CHK_CARDNO;

    cardno = cardno.toString().trim();

    for (var i = 0; i < cardno.length; i++) {
        if (cardno[i].charCodeAt() < 48 || cardno[i].charCodeAt() > 57) {
            CHK1 = 0;
            break;
        }
    }

    if (CHK1 === 1 && $.inArray(cardno.length, [14, 16]) >= 0) {
        var CHKSUM = 0;
        for (var i = 0; i < cardno.length - 1; i++) {
            var IND = 0;
            IND = parseInt(cardno[i]) * ((i + 1) % 2 === 1 ? 2 : 1);

            //console.log('idx : ' + i + ' , char : ' + cardno[i] +
            //    ' ind : ' + IND +
            //    ' 小計: ' + (IND >= 10 ? parseInt(IND / 10) + (IND % 10) : IND) +
            //    ' 總計: ' + (parseInt(CHKSUM) + parseInt((IND >= 10 ? parseInt(IND / 10) + (IND % 10) : IND)))
            //);

            CHKSUM += (IND >= 10 ? parseInt(IND / 10) + (IND % 10) : IND);

        }

        if (parseInt(cardno[cardno.length - 1]) === 10 - (CHKSUM % 10 === 0 ? 10 : CHKSUM % 10)) {
            if (cardno.length === 14) {
                //&& DINERS 
                CHK_CARDNO = 0;
            }
            else {
                //&& VISA/MASTER 
                CHK_CARDNO = 1;
            }
        }
        else {
            CHK_CARDNO = -1;
        }
    }
    else {
        CHK_CARDNO = -1;
    }

    return CHK_CARDNO;
}



//客製 DIS101130 輸出
function ExportFromAjax_DIS101130only(_urlPost, _Action, _inputs, _message, _message1) {
    blockMessage(_message);
    $.ajax({
        url: _urlPost,
        type: _Action,
        data: _inputs,
        async: false,
        chche: false,
        //datatype: 'json',
        //contentType: 'application/html;charset=urf-8',
        success: function (data) {
            if (data.Status) {
                if (data.Status) {
                    showFileMessageWithConfirm(data.Message, data.File);
                }
                else {
                    showSelfMessage(data.Message, "");
                }
            }
            else {
                showSelfMessage(data, "");
            }
        },
        error: function (xhr, status, text) {
            showSelfMessage("執行失敗：" + text);
        }
    });
    unBlock('');
}