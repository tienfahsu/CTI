﻿/***
* Grid.Mvc russian language (ru-RU) http://gridmvc.codeplex.com/
*/
window.GridMvc = window.GridMvc || {};
window.GridMvc.lang = window.GridMvc.lang || {};
GridMvc.lang.tw = {
    filterTypeLabel: "篩選: ",
    filterValueLabel: "值:",
    applyFilterButtonText: "提交",
    filterSelectTypes: {
        Equals: "等於",
        StartsWith: "開頭",
        Contains: "包含",
        EndsWith: "結尾",
        GreaterThan: "大於",
        LessThan: "小於"
    },
    code: 'tw',
    boolTrueLabel: "是",
    boolFalseLabel: "否",
    clearFilterLabel: "清除"
};